"""
Pydantic schemas for the amnezia-api REST responses.
These match the actual JSON structure from kyoresuas/amnezia-api.
"""
from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field, field_validator


class DeviceRecord(BaseModel):
    id: str
    name: Optional[str] = None
    allowedIps: Optional[list[str]] = None
    lastHandshake: Optional[int] = None
    traffic: Optional[dict[str, int]] = None
    online: Optional[bool] = None
    endpoint: Optional[str] = None
    expiresAt: Optional[int] = None
    protocol: Optional[str] = None


class AmneziaClientRecord(BaseModel):
    """One user (username) with one or more devices."""
    username: str
    devices: list[DeviceRecord] = Field(default_factory=list)


class CreateClientRequest(BaseModel):
    clientName: str
    # No default — the caller (billing) must always pass the protocol that
    # was actually resolved for this server (see
    # AmneziaClient.resolve_amneziawg_protocol / VpnServer.protocol). A
    # silent default here is exactly the hardcoded-version coupling this
    # schema used to have and that the project has since moved away from —
    # see billing/services/billing_service.py's provisioning flow and
    # models/models.py's VpnServer/VpnClient.protocol fields for where the
    # actual value comes from.
    protocol: str
    expiresAt: Optional[int] = None  # unix timestamp or null


class CreatedClient(BaseModel):
    id: str
    config: str   # vpn:// URL
    protocol: str


class CreateClientResponse(BaseModel):
    message: Optional[str] = None
    client: CreatedClient


class UpdateClientRequest(BaseModel):
    """PATCH /clients body (clientId/protocol added by AmneziaClient). status: "active" | "disabled"."""
    status: Optional[str] = None
    expiresAt: Optional[int] = None


class DeleteClientRequest(BaseModel):
    clientId: str
    # No default — see CreateClientRequest.protocol's docstring. The caller
    # must pass the specific client's own VpnClient.protocol (the value
    # amnezia-api actually returned when that client was created), not a
    # guessed or server-wide value.
    protocol: str


# ---------------------------------------------------------------------------
# Server metrics
# ---------------------------------------------------------------------------

class ServerInfo(BaseModel):
    """
    Response from GET /server. Matches the actual kyoresuas/amnezia-api
    response shape (verified directly against a running instance — see
    ARCHITECTURE.md's AmneziaWG protocol section for how this was
    confirmed): {id, region, weight, maxPeers, totalPeers, protocols}.
    `protocols` is the field this project's protocol-detection logic reads
    — see AmneziaClient.resolve_amneziawg_protocol.
    """
    id: Optional[str] = None
    region: Optional[str] = None
    weight: Optional[int] = None
    maxPeers: Optional[int] = None
    totalPeers: Optional[int] = None
    protocols: list[str] = Field(default_factory=list)

    @property
    def active_clients(self) -> int:
        """Best-effort client count from server info."""
        return self.totalPeers or 0
