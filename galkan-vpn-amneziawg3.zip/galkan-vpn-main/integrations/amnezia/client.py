"""
Thin HTTP adapter over the kyoresuas/amnezia-api REST API.

All business logic lives in billing/services, NOT here.
This module is a pure HTTP client — it maps Python calls to HTTP endpoints.

Endpoints (kyoresuas/amnezia-api, actual REST surface — see /docs on your instance):
  GET    /clients         — list clients
  POST   /clients         — create client
  DELETE /clients          — delete client (body: {clientId, protocol})
  PATCH  /clients          — update client (body: {clientId, protocol, status?, expiresAt?})
  GET    /server           — server status / metadata, including `protocols`
                              (list of AmneziaWG/Xray protocol strings enabled
                              on that server) — see resolve_amneziawg_protocol.
  GET    /healthz          — health check

Note: clientId and protocol are always passed in the request body, never in the
URL path — the API has no /clients/{id} route for mutations.

This client never defaults or guesses a protocol value — see
resolve_amneziawg_protocol() for the one place that decides which
AmneziaWG version to use, and CreateClientRequest/DeleteClientRequest's
docstrings (schemas.py) for why create_client/delete_client/update_client
require an explicit protocol argument instead.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from integrations.amnezia.errors import (
    AmneziaClientError,
    AmneziaConnectionError,
    AmneziaNotFoundError,
    AmneziaProtocolNotSupportedError,
    AmneziaServerError,
)
from integrations.amnezia.schemas import (
    AmneziaClientRecord,
    CreateClientRequest,
    CreateClientResponse,
    ServerInfo,
    UpdateClientRequest,
)

logger = logging.getLogger(__name__)

# The single AmneziaWG protocol version this project targets. Not a
# fallback and not a default passed anywhere automatically — this is only
# what resolve_amneziawg_protocol() checks for in a server's advertised
# `protocols` list. Bumping this one constant (e.g. to "amneziawg4" once
# that exists and amnezia-api supports it) is the entire migration; no
# other file in this project should ever hardcode a protocol version
# string. See PROJECT ТЗ: "переход на актуальный AmneziaWG и устранение
# hardcode версии протокола".
REQUIRED_AMNEZIAWG_PROTOCOL = "amneziawg3"


class AmneziaClient:
    """
    HTTP client for one amnezia-api server instance.
    Each VPN server in the DB gets its own AmneziaClient at call time.
    """

    DEFAULT_TIMEOUT = 15.0

    def __init__(self, base_url: str, api_key: str, timeout: float = DEFAULT_TIMEOUT):
        self._base_url = base_url.rstrip("/")
        self._headers = {
            "x-api-key": api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base_url,
            headers=self._headers,
            timeout=self._timeout,
        )

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code == 404:
            raise AmneziaNotFoundError(f"Resource not found: {resp.url}")
        if 400 <= resp.status_code < 500:
            body = _safe_json(resp)
            raise AmneziaClientError(
                f"Client error {resp.status_code}: {body.get('message', resp.text)}"
            )
        if resp.status_code >= 500:
            raise AmneziaServerError(
                f"Server error {resp.status_code}: {resp.text[:200]}"
            )

    # ------------------------------------------------------------------
    # Retry decorator factory
    # ------------------------------------------------------------------

    @staticmethod
    def _retryable(fn):
        return retry(
            retry=retry_if_exception_type((AmneziaServerError, AmneziaConnectionError)),
            wait=wait_exponential(multiplier=1, min=2, max=30),
            stop=stop_after_attempt(3),
            reraise=True,
        )(fn)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def healthcheck(self) -> bool:
        """Returns True if the server responds to /healthz."""
        try:
            async with self._make_client() as client:
                resp = await client.get("/healthz")
                return resp.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    @_retryable
    async def get_server_info(self) -> ServerInfo:
        """GET /server — returns CPU, RAM, uptime, client count, etc."""
        try:
            async with self._make_client() as client:
                resp = await client.get("/server")
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            raise AmneziaConnectionError(str(exc)) from exc
        self._raise_for_status(resp)
        data = resp.json()
        return ServerInfo.model_validate(data)

    async def resolve_amneziawg_protocol(self) -> str:
        """
        Determines the AmneziaWG protocol string to use for this server by
        calling GET /server and checking its `protocols` list — this is
        the ONLY place in the project that decides which protocol version
        to use going forward. Everywhere else (VpnServer.protocol,
        VpnClient.protocol, CreateClientRequest.protocol) just stores or
        forwards a value that was already resolved here or read back from
        amnezia-api's own response to a create-client call.

        Called once, when a server is added (see
        BillingService.add_server) — not on every provisioning request —
        so the resolved value is cached in VpnServer.protocol rather than
        adding a network round-trip to every purchase.

        Raises AmneziaProtocolNotSupportedError (not retryable — this is a
        "this server needs a protocol upgrade" condition, not a transient
        failure) if REQUIRED_AMNEZIAWG_PROTOCOL is not in the server's
        advertised protocols. Per the Amnezia docs, upgrading a server from
        AmneziaWG 2.0 to 3.1 requires reinstalling the server-side protocol
        and reissuing all client configs — this project deliberately does
        NOT attempt to silently keep using an older protocol as a
        fallback; see billing/services/billing_service.py's add_server for
        how this surfaces to the admin.
        """
        info = await self.get_server_info()
        if REQUIRED_AMNEZIAWG_PROTOCOL not in info.protocols:
            raise AmneziaProtocolNotSupportedError(
                f"Server does not support {REQUIRED_AMNEZIAWG_PROTOCOL} "
                f"(advertised protocols: {info.protocols or 'none'}). "
                f"Upgrade AmneziaWG on this server to 3.1 before adding it."
            )
        return REQUIRED_AMNEZIAWG_PROTOCOL

    @_retryable
    async def get_clients(
        self, skip: int = 0, limit: int = 100
    ) -> list[AmneziaClientRecord]:
        """GET /clients?skip=0&limit=100"""
        try:
            async with self._make_client() as client:
                resp = await client.get("/clients", params={"skip": skip, "limit": limit})
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            raise AmneziaConnectionError(str(exc)) from exc
        self._raise_for_status(resp)
        data = resp.json()
        items = data.get("items", data) if isinstance(data, dict) else data
        return [AmneziaClientRecord.model_validate(i) for i in items]

    @_retryable
    async def create_client(self, req: CreateClientRequest) -> CreateClientResponse:
        """POST /clients"""
        try:
            async with self._make_client() as client:
                resp = await client.post("/clients", json=req.model_dump(exclude_none=True))
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            raise AmneziaConnectionError(str(exc)) from exc
        self._raise_for_status(resp)
        return CreateClientResponse.model_validate(resp.json())

    @_retryable
    async def delete_client(self, client_id: str, protocol: str) -> None:
        """DELETE /clients  body: {clientId, protocol}. protocol has no
        default — the caller must pass this specific client's own
        VpnClient.protocol (the value amnezia-api returned when the client
        was created), not a guessed or server-wide value. See
        integrations/amnezia/schemas.py's CreateClientRequest.protocol
        docstring for why this project no longer defaults protocol
        anywhere."""
        try:
            async with self._make_client() as client:
                resp = await client.request(
                    "DELETE",
                    "/clients",
                    json={"clientId": client_id, "protocol": protocol},
                )
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            raise AmneziaConnectionError(str(exc)) from exc
        self._raise_for_status(resp)

    @_retryable
    async def update_client(
        self, client_id: str, req: UpdateClientRequest, protocol: str
    ) -> None:
        """
        PATCH /clients   body: {clientId, protocol, status?, expiresAt?}
        Used to enable/disable a client (status: "active" | "disabled").
        Note: clientId/protocol travel in the body — there is no /clients/{id} route.
        protocol has no default — see delete_client's docstring.
        """
        try:
            async with self._make_client() as client:
                payload = {"clientId": client_id, "protocol": protocol}
                payload.update(req.model_dump(exclude_none=True))
                resp = await client.patch("/clients", json=payload)
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            raise AmneziaConnectionError(str(exc)) from exc
        # 404 on update might mean this client/protocol pair doesn't exist upstream
        if resp.status_code == 404:
            logger.warning(
                "PATCH /clients (clientId=%s, protocol=%s) returned 404 — "
                "client may not exist on this server",
                client_id,
                protocol,
            )
            return
        self._raise_for_status(resp)

    async def disable_client(self, client_id: str, protocol: str) -> None:
        await self.update_client(client_id, UpdateClientRequest(status="disabled"), protocol=protocol)

    async def enable_client(self, client_id: str, protocol: str) -> None:
        await self.update_client(client_id, UpdateClientRequest(status="active"), protocol=protocol)

    async def get_client(self, client_id: str) -> Optional[AmneziaClientRecord]:
        """Fetch a single client by scanning the list. amnezia-api has no GET /clients/{id}."""
        clients = await self.get_clients(limit=1000)
        for c in clients:
            for device in c.devices:
                if device.id == client_id:
                    # Wrap single device back into record shape for convenience
                    return c
        return None


# ------------------------------------------------------------------
# Helper
# ------------------------------------------------------------------

def _safe_json(resp: httpx.Response) -> dict[str, Any]:
    try:
        return resp.json()
    except Exception:
        return {}
