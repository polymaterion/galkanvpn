class AmneziaError(Exception):
    """Base exception for all amnezia-api errors."""


class AmneziaConnectionError(AmneziaError):
    """Network timeout or connection refused."""


class AmneziaClientError(AmneziaError):
    """4xx response from amnezia-api (bad request, conflict, etc.)."""


class AmneziaNotFoundError(AmneziaClientError):
    """404 — client or resource not found."""


class AmneziaServerError(AmneziaError):
    """5xx response — retryable."""


class AmneziaProtocolNotSupportedError(AmneziaError):
    """
    Raised by AmneziaClient.resolve_amneziawg_protocol() when a server's
    GET /server response does not list the AmneziaWG protocol this project
    requires (see billing/services/billing_service.py's REQUIRED_AMNEZIAWG_PROTOCOL).
    Not retryable — this means the VPN server itself needs a protocol
    upgrade (see Amnezia's own docs on upgrading AmneziaWG 2.0 -> 3.1),
    not a transient network/server issue like AmneziaServerError. Distinct
    from AmneziaConnectionError/AmneziaServerError so callers (admin API,
    /add_server) can show "this server needs updating" rather than "try
    again later".
    """
