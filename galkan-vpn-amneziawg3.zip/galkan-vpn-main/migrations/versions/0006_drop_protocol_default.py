"""Remove the hardcoded server_default="amneziawg2" from vpn_servers.protocol.

Part of the move away from a hardcoded AmneziaWG protocol version: the
protocol column must always be populated explicitly, with whatever value
AmneziaClient.resolve_amneziawg_protocol() actually confirmed for that
server (see BillingService.add_server) — never a silent DB-level fallback
to an old protocol string. This migration does not touch any existing row's
data, only the column's default for future inserts that don't specify it.

Revision ID: 0006_drop_protocol_default
Revises: 0005_manat_agent_queue
Create Date: 2026-09-16
"""
from alembic import op
import sqlalchemy as sa

revision = "0006_drop_protocol_default"
down_revision = "0005_manat_agent_queue"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column(
        "vpn_servers",
        "protocol",
        server_default=None,
    )


def downgrade() -> None:
    op.alter_column(
        "vpn_servers",
        "protocol",
        server_default="amneziawg2",
    )
