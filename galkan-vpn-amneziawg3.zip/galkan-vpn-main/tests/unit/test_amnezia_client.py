"""
Tests for the AmneziaWG protocol-detection logic added to
integrations/amnezia/client.py — see ТЗ "переход на актуальный AmneziaWG и
устранение hardcode версии протокола". These exercise AmneziaClient
directly against a mocked HTTP layer (respx), not through BillingService,
so they're testing the exact contract resolve_amneziawg_protocol has with
amnezia-api's real GET /server response shape (verified against a live
instance: {id, region, weight, maxPeers, totalPeers, protocols}).
"""
import pytest
import respx
import httpx

from integrations.amnezia.client import AmneziaClient, REQUIRED_AMNEZIAWG_PROTOCOL
from integrations.amnezia.errors import (
    AmneziaConnectionError,
    AmneziaProtocolNotSupportedError,
)


BASE_URL = "http://test-amnezia:4001"


def _client() -> AmneziaClient:
    return AmneziaClient(base_url=BASE_URL, api_key="test-key")


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_returns_required_when_supported():
    """The exact shape confirmed against a real kyoresuas/amnezia-api
    instance: {id, region, weight, maxPeers, totalPeers, protocols}."""
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").respond(
            200,
            json={
                "id": "4b90100e-f40f-4ef8-a0c0-8c0cdd08556e",
                "region": "Server-1",
                "weight": 100,
                "maxPeers": 200,
                "totalPeers": 5,
                "protocols": ["amneziawg3"],
            },
        )
        protocol = await _client().resolve_amneziawg_protocol()
    assert protocol == REQUIRED_AMNEZIAWG_PROTOCOL
    assert protocol == "amneziawg3"


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_multiple_protocols_still_finds_required():
    """A server advertising several protocols (e.g. legacy amneziawg
    alongside the new one, or xray) must still resolve correctly as long
    as the required one is present — order/extra entries don't matter."""
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").respond(
            200,
            json={"protocols": ["amneziawg", "xray", "amneziawg3"]},
        )
        protocol = await _client().resolve_amneziawg_protocol()
    assert protocol == "amneziawg3"


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_raises_when_only_legacy_available():
    """A server still on AmneziaWG 2.0 (or any set that doesn't include the
    required protocol) must raise — NEVER silently fall back to an older
    protocol. This is the core guarantee of ТЗ point 3."""
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").respond(200, json={"protocols": ["amneziawg"]})
        with pytest.raises(AmneziaProtocolNotSupportedError):
            await _client().resolve_amneziawg_protocol()


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_raises_when_protocols_empty():
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").respond(200, json={"protocols": []})
        with pytest.raises(AmneziaProtocolNotSupportedError):
            await _client().resolve_amneziawg_protocol()


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_raises_when_protocols_field_missing():
    """A malformed/older response missing `protocols` entirely must also
    be treated as "not supported", not crash or silently default."""
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").respond(200, json={"id": "x", "region": "EU"})
        with pytest.raises(AmneziaProtocolNotSupportedError):
            await _client().resolve_amneziawg_protocol()


@pytest.mark.asyncio
async def test_resolve_amneziawg_protocol_connection_error_is_not_swallowed():
    """A genuinely unreachable server (network error) must surface as
    AmneziaConnectionError — distinct from "reachable but wrong protocol"
    (AmneziaProtocolNotSupportedError) so callers can tell the two apart
    (see BillingService.add_server's except clauses)."""
    with respx.mock(base_url=BASE_URL) as mock:
        mock.get("/server").mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(AmneziaConnectionError):
            await _client().resolve_amneziawg_protocol()


@pytest.mark.asyncio
async def test_delete_client_requires_explicit_protocol():
    """delete_client must send exactly the protocol passed in — no
    default is substituted if the caller passes one explicitly (this also
    guards against a regression reintroducing a default parameter)."""
    with respx.mock(base_url=BASE_URL) as mock:
        route = mock.delete("/clients").respond(200, json={})
        await _client().delete_client("client-123", protocol="amneziawg3")
    sent_body = route.calls.last.request.content
    import json
    assert json.loads(sent_body) == {"clientId": "client-123", "protocol": "amneziawg3"}


@pytest.mark.asyncio
async def test_delete_client_has_no_default_protocol_argument():
    """Calling without a protocol at all must be a TypeError (missing
    required positional/keyword argument), not silently succeed with a
    hardcoded default — this is the exact regression ТЗ point 5 guards
    against ("убрать defaults: protocol='amneziawg2' из delete_client")."""
    with pytest.raises(TypeError):
        await _client().delete_client("client-123")  # type: ignore[call-arg]


@pytest.mark.asyncio
async def test_enable_disable_client_require_explicit_protocol():
    with pytest.raises(TypeError):
        await _client().enable_client("client-123")  # type: ignore[call-arg]
    with pytest.raises(TypeError):
        await _client().disable_client("client-123")  # type: ignore[call-arg]


def test_create_client_request_has_no_default_protocol():
    """Regression guard for ТЗ point 5: CreateClientRequest.protocol must
    be a required field, not defaulted to any hardcoded version string."""
    from integrations.amnezia.schemas import CreateClientRequest
    import pydantic

    with pytest.raises(pydantic.ValidationError):
        CreateClientRequest(clientName="test")  # type: ignore[call-arg]

    # Passing it explicitly still works as before.
    req = CreateClientRequest(clientName="test", protocol="amneziawg3")
    assert req.protocol == "amneziawg3"


def test_delete_client_request_has_no_default_protocol():
    from integrations.amnezia.schemas import DeleteClientRequest
    import pydantic

    with pytest.raises(pydantic.ValidationError):
        DeleteClientRequest(clientId="x")  # type: ignore[call-arg]

    req = DeleteClientRequest(clientId="x", protocol="amneziawg3")
    assert req.protocol == "amneziawg3"
