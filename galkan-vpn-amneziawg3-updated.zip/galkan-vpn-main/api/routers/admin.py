"""
Admin router — used by Telegram admin commands and (optionally) a web UI.
Protected by internal billing key.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.dependencies import verify_internal_key
from billing.database import get_db
from billing.repositories.other_repos import (
    AgentRepository,
    ManatRequestRepository,
    PaymentRepository,
    PlanRepository,
    VpnClientRepository,
)
from billing.repositories.server_repo import VpnServerRepository
from billing.repositories.subscription_repo import SubscriptionRepository
from billing.repositories.user_repo import UserRepository
from billing.services.billing_service import (
    BillingService,
    ManatRequestAlreadyResolvedError,
    ManatRequestNotAssignedToAgentError,
    ServerUnreachableError,
    TrialAlreadyUsedError,
)
from billing.redis_lock import LockTimeoutError
from integrations.amnezia.client import AmneziaClient
from integrations.amnezia.errors import AmneziaError, AmneziaProtocolNotSupportedError
from models.models import ManatRequestStatus, VpnServerStatus

router = APIRouter(dependencies=[Depends(verify_internal_key)])
_svc = BillingService()


# ---- Users ----

@router.get("/users")
async def list_users(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = UserRepository(session)
    users = await repo.get_all(offset=offset, limit=limit)
    total = await repo.count()
    return {
        "total": total,
        "items": [
            {
                "id": u.id,
                "telegram_id": u.telegram_id,
                "username": u.username,
                "first_name": u.first_name,
                "is_banned": u.is_banned,
                "created_at": u.created_at.isoformat(),
            }
            for u in users
        ],
    }


@router.get("/broadcast/recipients")
async def broadcast_recipients(session=Depends(get_db)):
    """All telegram_id for non-banned users — used by /broadcast to reach
    every user who has ever started the bot, not just new signups. No
    pagination: the bot needs the full list to send to, not a page."""
    repo = UserRepository(session)
    ids = await repo.get_all_telegram_ids()
    return {"telegram_ids": ids}


# ---- Subscriptions ----

@router.get("/subscriptions")
async def list_subscriptions(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = SubscriptionRepository(session)
    subs = await repo.get_all(offset=offset, limit=limit)
    return {
        "items": [
            {
                "id": s.id,
                "user_id": s.user_id,
                "status": s.status.value,
                "expires_at": s.expires_at.isoformat() if s.expires_at else None,
                "plan": s.plan.name if s.plan else None,
            }
            for s in subs
        ]
    }


class ExtendRequest(BaseModel):
    days: int = 30


@router.post("/subscriptions/{sub_id}/extend")
async def extend_subscription(sub_id: int, req: ExtendRequest, session=Depends(get_db)):
    await _svc.admin_extend_subscription(session, sub_id, req.days)
    return {"ok": True}


@router.post("/subscriptions/{sub_id}/disable")
async def disable_subscription(sub_id: int, session=Depends(get_db)):
    await _svc.admin_disable_subscription(session, sub_id)
    return {"ok": True}


@router.post("/subscriptions/{sub_id}/reissue")
async def reissue_device(sub_id: int, session=Depends(get_db)):
    """
    Re-provision a subscription's VPN client from scratch (bot command:
    /reissue_device). Use when a client's config_url looks valid but never
    connects — the old client is best-effort deleted from its VPN server
    (it may already be missing there) and a brand new one is created.
    """
    try:
        config_url = await _svc.admin_reissue_device(session, sub_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except (AmneziaError, LockTimeoutError) as e:
        # admin_reissue_device already updated the subscription/vpn_client
        # rows to reflect the partial failure (pending_provisioning,
        # retry_count, vc marked deleted, old server's count decremented) —
        # but those changes live only in this session's pending transaction
        # until committed. get_db() commits only on a clean return; since
        # the HTTPException raised below propagates straight through it,
        # get_db() would instead roll back everything admin_reissue_device
        # just did, silently discarding that bookkeeping. Commit explicitly
        # here, before raising, so the next retry cycle actually sees it.
        await session.commit()
        raise HTTPException(
            status_code=503,
            detail=f"VPN server unavailable, try again shortly: {e}",
        )
    return {"ok": True, "config_url": config_url}


class GrantTrialRequest(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None


@router.post("/trial")
async def grant_trial(req: GrantTrialRequest, session=Depends(get_db)):
    """Grants the one-time free trial device to this telegram_id. Used by
    the bot both for new users (auto-granted on first /start) and existing
    users (via the trial deep-link, /start=trial)."""
    try:
        sub = await _svc.grant_trial(
            session,
            telegram_id=req.telegram_id,
            username=req.username,
            first_name=req.first_name,
            last_name=req.last_name,
        )
    except TrialAlreadyUsedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "subscription_id": sub.id}


class ManatAgentActionRequest(BaseModel):
    agent_id: int  # the agent's telegram_id, not the Agent.id primary key


@router.post("/manat/{request_id}/accept")
async def accept_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the currently-assigned agent taps "Принять
    заявку" within the 5-minute window. Moves the request to
    awaiting_payment and starts the 15-minute payment-window clock."""
    try:
        request = await _svc.accept_manat_request(
            session, request_id=request_id, agent_id=req.agent_id
        )
    except ManatRequestNotAssignedToAgentError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(request.user_id)
    return {
        "ok": True,
        "telegram_id": user.telegram_id if user else None,
        "amount_manat": float(request.amount_manat),
        "agent_phone_shown": request.agent_phone_shown,
    }


@router.post("/manat/{request_id}/decline")
async def decline_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the currently-assigned agent taps "Не могу
    принять" within the 5-minute window — immediately re-assigns to the
    next agent in the queue rather than waiting out the rest of the
    timeout."""
    try:
        await _svc.decline_manat_request(session, request_id=request_id, agent_id=req.agent_id)
    except ManatRequestNotAssignedToAgentError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    request = await ManatRequestRepository(session).get_by_id(request_id)
    if not request:
        return {"ok": True, "reassigned": False}

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(request.user_id)
    agent_repo = AgentRepository(session)
    new_agent = (
        await agent_repo.get_by_id(request.assigned_agent_id)
        if request.assigned_agent_id
        else None
    )
    return {
        "ok": True,
        "reassigned": new_agent is not None,
        "telegram_id": user.telegram_id if user else None,
        "new_agent_telegram_id": new_agent.telegram_id if new_agent else None,
        "amount_manat": float(request.amount_manat),
        "agent_phone_shown": request.agent_phone_shown,
        "status": request.status.value,
    }


class ManatReportPaymentRequest(BaseModel):
    agent_id: int  # the agent's telegram_id, not the Agent.id primary key
    received: bool  # True = "Деньги получены", False = "Деньги не получены"


@router.post("/manat/{request_id}/report")
async def report_manat_payment(
    request_id: int, req: ManatReportPaymentRequest, session=Depends(get_db)
):
    """
    Called by the bot when the assigned agent taps "Деньги получены" /
    "Деньги не получены". This is ONLY a claim (ТЗ p.5/p.7) — it moves the
    request into the main admin's review queue (received=True) or hands it
    to the next agent (received=False). It NEVER creates a Payment, Order,
    Subscription, or triggers provisioning — see
    BillingService.report_manat_payment / approve_manat_request.
    """
    try:
        request = await _svc.report_manat_payment(
            session, request_id=request_id, agent_id=req.agent_id, received=req.received
        )
    except ManatRequestAlreadyResolvedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(request.user_id)
    return {
        "ok": True,
        "telegram_id": user.telegram_id if user else None,
        "amount_manat": float(request.amount_manat),
        "status": request.status.value,
    }


class ManatAdminActionRequest(BaseModel):
    admin_telegram_id: int
    reason: Optional[str] = None  # only meaningful for reject


@router.get("/manat/queue")
async def get_manat_admin_queue(
    status: Optional[str] = None, offset: int = 0, limit: int = 50, session=Depends(get_db)
):
    """
    The main admin's review queue (ТЗ p.6/p.11 — 'Оплаты манатами на
    проверке'). Defaults to admin_review (awaiting decision); pass
    ?status= to view another tab of ТЗ p.11's 'Waiting / Payment reported
    / Admin review / Approved / Rejected / Expired'. Multiple statuses can
    be passed comma-separated (e.g. ?status=awaiting_agent,assigned for
    the combined "Waiting" tab).
    """
    statuses = None
    if status:
        try:
            statuses = [ManatRequestStatus(s.strip()) for s in status.split(",") if s.strip()]
        except ValueError as e:
            raise HTTPException(status_code=400, detail=f"Invalid status value: {e}")

    req_repo = ManatRequestRepository(session)
    user_repo = UserRepository(session)
    agent_repo = AgentRepository(session)
    requests = await req_repo.get_admin_queue(statuses=statuses, offset=offset, limit=limit)
    total = await req_repo.count_admin_queue(statuses=statuses)

    items = []
    for r in requests:
        payer = await user_repo.get_by_id(r.user_id)
        agent = await agent_repo.get_by_id(r.assigned_agent_id) if r.assigned_agent_id else None
        items.append({
            "id": r.id,
            "status": r.status.value,
            "user_id": r.user_id,
            "payer_telegram_id": payer.telegram_id if payer else None,
            "payer_username": payer.username if payer else None,
            "plan_id": r.plan_id,
            "amount_manat": float(r.amount_manat),
            "agent_id": r.assigned_agent_id,
            "agent_telegram_id": agent.telegram_id if agent else None,
            "agent_display_name": agent.display_name if agent else None,
            "agent_phone_shown": r.agent_phone_shown,
            "created_at": r.created_at.isoformat(),
            "reported_at": r.reported_at.isoformat() if r.reported_at else None,
            "resolved_by_admin_id": r.resolved_by_admin_id,
            "resolved_at": r.resolved_at.isoformat() if r.resolved_at else None,
            "rejection_reason": r.rejection_reason,
            "reassignment_history": r.reassignment_history,
        })
    return {"total": total, "items": items}


@router.post("/manat/{request_id}/approve")
async def approve_manat_request(
    request_id: int, req: ManatAdminActionRequest, session=Depends(get_db)
):
    """
    THE ONLY endpoint that creates the Payment/Order/Subscription and
    triggers VPN provisioning for a manat request (ТЗ p.6/p.14). Only the
    main admin should be able to reach this — bot-side access control is
    the caller's responsibility (see bot/handlers/admin_handlers.py's
    admin-only filters), same as every other endpoint in this router.
    409 means another admin (or a retried tap) already resolved it first —
    this is expected under concurrent approval, not an error to alarm the
    admin about (ТЗ p.8/p.13: a second approve must never double-provision).
    """
    try:
        sub = await _svc.approve_manat_request(
            session, request_id=request_id, admin_telegram_id=req.admin_telegram_id
        )
    except ManatRequestAlreadyResolvedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(sub.user_id)
    vc_repo = VpnClientRepository(session)
    vc = await vc_repo.get_by_subscription(sub.id)
    return {
        "ok": True,
        "subscription_id": sub.id,
        "telegram_id": user.telegram_id if user else None,
        "status": sub.status.value,
        "expires_at": sub.expires_at.isoformat() if sub.expires_at else None,
        "config_url": vc.config_url if vc else None,
    }


@router.post("/manat/{request_id}/reject")
async def reject_manat_request(
    request_id: int, req: ManatAdminActionRequest, session=Depends(get_db)
):
    """Called when the main admin taps "Отклонить оплату" on a reported
    payment. Same double-resolution guard as approve (ТЗ p.8/p.13)."""
    try:
        await _svc.reject_manat_request(
            session,
            request_id=request_id,
            admin_telegram_id=req.admin_telegram_id,
            reason=req.reason,
        )
    except ManatRequestAlreadyResolvedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}


# ---- Manat agents ----

class AgentCreateRequest(BaseModel):
    telegram_id: int
    display_name: Optional[str] = None
    timezone: str = "Asia/Ashgabat"
    # Comma-separated ISO weekday numbers, 1 (Mon) - 7 (Sun); None/omitted
    # means "every day".
    work_days: Optional[str] = None
    work_start_time: Optional[str] = None  # "HH:MM", agent's local time
    work_end_time: Optional[str] = None    # "HH:MM", agent's local time


@router.post("/agents")
async def create_agent(req: AgentCreateRequest, session=Depends(get_db)):
    """Register a new manat payment agent (admin-only — bot command:
    /add_agent). The agent starts with zero phone numbers; add one with
    POST /agents/{agent_id}/phones before they can receive assignments.
    Schedule fields are optional (ТЗ p.2) — omit work_days/start/end for an
    agent who should be available at any time whenever active."""
    repo = AgentRepository(session)
    existing = await repo.get_by_telegram_id(req.telegram_id)
    if existing:
        raise HTTPException(status_code=409, detail="Agent already exists for this telegram_id")
    agent = await repo.create(
        telegram_id=req.telegram_id,
        display_name=req.display_name,
        timezone_name=req.timezone,
        work_days=req.work_days,
        work_start_time=req.work_start_time,
        work_end_time=req.work_end_time,
    )
    return {"ok": True, "id": agent.id, "telegram_id": agent.telegram_id}


@router.get("/agents")
async def list_agents(session=Depends(get_db)):
    repo = AgentRepository(session)
    agents = await repo.get_all()
    result = []
    for agent in agents:
        since = datetime.now(timezone.utc) - timedelta(hours=24)
        phones = await repo.get_phones_for_agent(agent.id)
        phone_info = []
        for phone in phones:
            received = await repo.get_phone_received_since(phone.id, since)
            reserved = await repo.get_phone_reserved_open_total(phone.id)
            phone_info.append({
                "id": phone.id,
                "phone_number": phone.phone_number,
                "is_enabled": phone.is_enabled,
                "daily_limit_manat": (
                    float(phone.daily_limit_manat) if phone.daily_limit_manat is not None else None
                ),
                "received_last_24h": received,
                "reserved_open": reserved,
            })
        result.append({
            "id": agent.id,
            "telegram_id": agent.telegram_id,
            "display_name": agent.display_name,
            "is_active": agent.is_active,
            "manually_disabled": agent.manually_disabled,
            "timezone": agent.timezone,
            "work_days": agent.work_days,
            "work_start_time": agent.work_start_time,
            "work_end_time": agent.work_end_time,
            "on_shift_now": _svc._agent_is_on_shift(agent),
            "phones": phone_info,
        })
    return {"items": result}


class AgentActiveUpdate(BaseModel):
    is_active: bool


@router.patch("/agents/{agent_id}")
async def update_agent_active(agent_id: int, req: AgentActiveUpdate, session=Depends(get_db)):
    """Admin-only: enable/disable an agent entirely (removes them from the
    assignment queue regardless of their phones' state)."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    await repo.set_active(agent_id, req.is_active)
    return {"ok": True}


class AgentManualDisableUpdate(BaseModel):
    manually_disabled: bool


@router.patch("/agents/{agent_id}/manual-disable")
async def update_agent_manual_disable(
    agent_id: int, req: AgentManualDisableUpdate, session=Depends(get_db)
):
    """Admin-only kill switch, independent of the agent's work schedule
    (ТЗ p.2/p.10). An agent inside their shift window is still skipped by
    assignment while this is True."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    await repo.set_manually_disabled(agent_id, req.manually_disabled)
    return {"ok": True}


class AgentScheduleUpdate(BaseModel):
    timezone: Optional[str] = None
    work_days: Optional[str] = None       # comma-separated 1-7, or null for every day
    work_start_time: Optional[str] = None  # "HH:MM"
    work_end_time: Optional[str] = None    # "HH:MM"


@router.patch("/agents/{agent_id}/schedule")
async def update_agent_schedule(
    agent_id: int, req: AgentScheduleUpdate, session=Depends(get_db)
):
    """Admin-only: configure an agent's work schedule (ТЗ p.2/p.10). Pass
    null/omit work_days/work_start_time/work_end_time to clear the
    schedule (agent available whenever active + not manually disabled)."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    await repo.set_schedule(
        agent_id,
        timezone_name=req.timezone,
        work_days=req.work_days,
        work_start_time=req.work_start_time,
        work_end_time=req.work_end_time,
    )
    return {"ok": True}


class AgentPhoneCreateRequest(BaseModel):
    phone_number: str
    daily_limit_manat: Optional[float] = 350


@router.post("/agents/{agent_id}/phones")
async def add_agent_phone(agent_id: int, req: AgentPhoneCreateRequest, session=Depends(get_db)):
    """Admin-only: add a phone number to an agent (bot command:
    /add_agent_phone). New numbers start enabled. daily_limit_manat is a
    per-phone business setting (ТЗ p.9); pass null for unlimited."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    phone = await repo.add_phone(agent_id, req.phone_number, daily_limit_manat=req.daily_limit_manat)
    return {"ok": True, "id": phone.id, "phone_number": phone.phone_number}


@router.delete("/agents/phones/{phone_id}")
async def remove_agent_phone(phone_id: int, session=Depends(get_db)):
    """Admin-only: permanently remove a phone number from an agent (bot
    command: /remove_agent_phone). Use PATCH .../enabled to temporarily
    take a number out of rotation instead of deleting it."""
    repo = AgentRepository(session)
    phone = await repo.get_phone_by_id(phone_id)
    if not phone:
        raise HTTPException(status_code=404, detail="Phone not found")
    await repo.remove_phone(phone_id)
    return {"ok": True}


class AgentPhoneEnabledUpdate(BaseModel):
    is_enabled: bool


@router.patch("/agents/phones/{phone_id}/enabled")
async def set_agent_phone_enabled(
    phone_id: int, req: AgentPhoneEnabledUpdate, session=Depends(get_db)
):
    """Toggled by the agent themselves from the bot (not admin-only) —
    temporarily taking a number in or out of rotation, e.g. while it's
    low on balance or unavailable, without losing its 24h history."""
    repo = AgentRepository(session)
    phone = await repo.get_phone_by_id(phone_id)
    if not phone:
        raise HTTPException(status_code=404, detail="Phone not found")
    await repo.set_phone_enabled(phone_id, req.is_enabled)
    return {"ok": True}


class AgentPhoneLimitUpdate(BaseModel):
    daily_limit_manat: Optional[float]  # null = unlimited


@router.patch("/agents/phones/{phone_id}/limit")
async def set_agent_phone_limit(
    phone_id: int, req: AgentPhoneLimitUpdate, session=Depends(get_db)
):
    """Admin-only: set this phone's daily receiving limit in TMT (ТЗ p.9).
    Pass null for unlimited."""
    repo = AgentRepository(session)
    phone = await repo.get_phone_by_id(phone_id)
    if not phone:
        raise HTTPException(status_code=404, detail="Phone not found")
    await repo.set_phone_limit(phone_id, req.daily_limit_manat)
    return {"ok": True}


@router.get("/agents/by-telegram/{telegram_id}")
async def get_agent_by_telegram_id(telegram_id: int, session=Depends(get_db)):
    """Used by the bot's /my_numbers command to look up the calling agent
    (identified by their own telegram_id) and show their phones + trailing
    24h usage."""
    repo = AgentRepository(session)
    agent = await repo.get_by_telegram_id(telegram_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Not a registered agent")
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    phones = await repo.get_phones_for_agent(agent.id)
    phone_info = []
    for phone in phones:
        received = await repo.get_phone_received_since(phone.id, since)
        reserved = await repo.get_phone_reserved_open_total(phone.id)
        phone_info.append({
            "id": phone.id,
            "phone_number": phone.phone_number,
            "is_enabled": phone.is_enabled,
            "daily_limit_manat": (
                float(phone.daily_limit_manat) if phone.daily_limit_manat is not None else None
            ),
            "received_last_24h": received,
            "reserved_open": reserved,
        })
    return {
        "id": agent.id,
        "telegram_id": agent.telegram_id,
        "display_name": agent.display_name,
        "is_active": agent.is_active,
        "manually_disabled": agent.manually_disabled,
        "timezone": agent.timezone,
        "work_days": agent.work_days,
        "work_start_time": agent.work_start_time,
        "work_end_time": agent.work_end_time,
        "on_shift_now": _svc._agent_is_on_shift(agent),
        "phones": phone_info,
    }


# ---- Payments ----

@router.get("/payments")
async def list_payments(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = PaymentRepository(session)
    payments = await repo.get_all(offset=offset, limit=limit)
    return {
        "items": [
            {
                "id": p.id,
                "user_id": p.user_id,
                "provider": p.provider.value,
                "amount": float(p.amount),
                "currency": p.currency,
                "status": p.status.value,
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            }
            for p in payments
        ]
    }


# ---- Servers ----

@router.get("/servers")
async def list_servers(session=Depends(get_db)):
    repo = VpnServerRepository(session)
    servers = await repo.get_all()
    result = []
    for s in servers:
        load_info: dict[str, Any] = {}
        try:
            amnezia = AmneziaClient(base_url=s.base_url, api_key=s.api_key)
            info = await amnezia.get_server_info()
            load_info = {"cpu": info.cpu, "memory": info.memory, "uptime": info.uptime}
        except Exception:
            load_info = {"error": "unreachable"}
        result.append(
            {
                "id": s.id,
                "name": s.name,
                "region": s.region,
                "status": s.status.value,
                "weight": s.weight,
                "protocol": s.protocol,
                "current_clients": s.current_clients,
                "max_clients": s.max_clients,
                "load": load_info,
            }
        )
    return {"items": result}


class ServerStatusUpdate(BaseModel):
    status: str  # "active" | "disabled"


@router.patch("/servers/{server_id}")
async def update_server_status(
    server_id: int, req: ServerStatusUpdate, session=Depends(get_db)
):
    repo = VpnServerRepository(session)
    server = await repo.get_by_id(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    try:
        server.status = VpnServerStatus(req.status)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid status: {req.status}")
    return {"ok": True, "new_status": server.status.value}


class ServerCreateRequest(BaseModel):
    name: str
    base_url: str
    api_key: str
    region: Optional[str] = "EU"
    weight: int = 100
    max_clients: int = 200
    # No protocol field — it is determined automatically from the server's
    # own amnezia-api instance (GET /server -> protocols) rather than
    # accepted from the admin. See BillingService.add_server.


@router.post("/servers")
async def create_server(req: ServerCreateRequest, session=Depends(get_db)):
    """
    Add a new VPN server. Use this to add servers after the initial deploy —
    the seed script only runs once, so this is the normal way to grow the
    server pool later (bot command: /add_server).

    The AmneziaWG protocol is determined automatically by querying the
    server's own amnezia-api instance (see BillingService.add_server) —
    never accepted as input here. If the server doesn't support the
    required protocol version, no server row is created and a 422 is
    returned so the admin knows to upgrade AmneziaWG on that server first;
    if the server can't be reached at all, a 503 is returned instead.
    """
    try:
        server = await _svc.add_server(
            session,
            name=req.name,
            base_url=req.base_url,
            api_key=req.api_key,
            region=req.region,
            weight=req.weight,
            max_clients=req.max_clients,
        )
    except AmneziaProtocolNotSupportedError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except ServerUnreachableError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return {"ok": True, "id": server.id, "name": server.name, "protocol": server.protocol}


@router.delete("/servers/{server_id}")
async def delete_server(server_id: int, session=Depends(get_db)):
    """
    Remove a server that has no clients on it. Servers with existing clients
    should be disabled (PATCH status=disabled) instead of deleted, since
    vpn_clients/subscriptions reference server_id via foreign key.
    """
    repo = VpnServerRepository(session)
    server = await repo.get_by_id(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.current_clients > 0:
        raise HTTPException(
            status_code=400,
            detail="Server has active clients — disable it instead of deleting",
        )
    await repo.delete(server_id)
    return {"ok": True}


# ---- Plan price ----

class PlanUpdate(BaseModel):
    price_stars: Optional[int] = None
    price_usdt: Optional[float] = None


@router.patch("/plans/{plan_id}")
async def update_plan(plan_id: int, req: PlanUpdate, session=Depends(get_db)):
    repo = PlanRepository(session)
    plan = await repo.get_by_id(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    if req.price_stars is not None:
        plan.price_stars = req.price_stars
    if req.price_usdt is not None:
        plan.price_usdt = req.price_usdt
    return {"ok": True}
