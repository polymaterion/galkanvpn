"""
Admin Telegram commands.
Only accessible to users in ADMIN_IDS.

Navigation is deliberately kept separate from the customer-facing flow:
every admin screen's "back" button returns to the admin panel (callback
"adm_menu", handled here), never to the customer main menu ("start", handled
in main_handlers.py). Mixing the two meant an admin browsing e.g. Users and
tapping "back" would land in the "buy a device" screen instead of back in
the admin panel — confusing and easy to mis-tap through by accident.

The admin panel respects the admin's own selected language (same `lang`
middleware-injected value as the rest of the bot) rather than being
hardcoded to Russian — every string lives in bot/locales/{ru,tk}.py under
the "adm_" prefix.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

import httpx
from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from bot import navigation
from bot.billing_client import billing_client
from bot.config import settings
from bot.keyboards.keyboards import admin_back_keyboard, admin_menu
from bot.locales import t

logger = logging.getLogger(__name__)
router = Router()


def _is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids_list


_ALLOWED_URL_SCHEMES = ("http://", "https://", "tg://")


@dataclass
class ButtonParseError(Exception):
    line_num: int
    line: str


def _parse_broadcast_buttons(text: str) -> InlineKeyboardMarkup | None:
    """
    Parses /broadcast's argument text into an inline keyboard.
    One input line = one keyboard row. Buttons within a row are separated
    by " | ". Each button is "label - url", split on the LAST " - " (so a
    label that happens to contain " - " itself doesn't break the split —
    URLs never contain a literal " - " with spaces on both sides, since
    spaces in URLs must be percent-encoded).

    Returns None for empty/whitespace-only input (no buttons requested —
    a perfectly normal case, not an error). Raises ButtonParseError with
    enough context (1-indexed line number and the offending line) for the
    caller to show the admin exactly what to fix.
    """
    text = text.strip()
    if not text:
        return None

    rows: list[list[InlineKeyboardButton]] = []
    for line_num, line in enumerate(text.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        row: list[InlineKeyboardButton] = []
        for button_spec in line.split("|"):
            button_spec = button_spec.strip()
            if " - " not in button_spec:
                raise ButtonParseError(line_num=line_num, line=line)
            label, url = button_spec.rsplit(" - ", 1)
            label, url = label.strip(), url.strip()
            if not label or not url.lower().startswith(_ALLOWED_URL_SCHEMES):
                raise ButtonParseError(line_num=line_num, line=line)
            row.append(InlineKeyboardButton(text=label, url=url))
        if row:
            rows.append(row)

    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


# --- Admin panel entry / navigation ---

@router.message(Command("admin"))
async def cmd_admin(msg: Message, state: FSMContext, lang: str):
    if not _is_admin(msg.from_user.id):
        await msg.answer(t("adm_access_denied", lang))
        return
    # Admin panel is a branch below the global main screen, so it participates
    # in the same stack and its own sub-screens can return exactly one level.
    await navigation.reset(state, "main")
    await navigation.push(state, "admin_menu")
    panel = await msg.answer(t("adm_panel_title", lang), reply_markup=admin_menu(lang))
    await navigation.set_ui_message(state, panel.message_id)


@router.callback_query(F.data == "adm_menu")
async def cb_adm_menu(cb: CallbackQuery, state: FSMContext, lang: str):
    """Back button target for every admin sub-screen — stays within the
    admin panel, never falls through to the customer menu."""
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.reset(state, "main")
    await navigation.push(state, "admin_menu")
    await navigation.set_ui_message(state, cb.message.message_id)
    await cb.message.edit_text(t("adm_panel_title", lang), reply_markup=admin_menu(lang))
    await cb.answer()


# --- Users ---
@router.callback_query(F.data == "nav:admin:users")
async def adm_users(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_users")
    try:
        data = await billing_client.admin_list_users()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    total = data.get("total", 0)
    users = data.get("items", [])
    lines = [t("adm_users_title", lang, total=total)]
    for u in users[:15]:
        uname = f"@{u['username']}" if u.get("username") else u.get("first_name", "—")
        lines.append(f"• <code>{u['telegram_id']}</code> {uname}")

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Subscriptions ---
@router.callback_query(F.data == "nav:admin:subs")
async def adm_subs(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_subs")
    try:
        data = await billing_client.admin_list_subscriptions()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    subs = data.get("items", [])
    lines = [t("adm_subs_title", lang)]
    for s in subs[:15]:
        exp = (s.get("expires_at") or "")[:10]
        lines.append(f"• #{s['id']} user={s['user_id']} [{s['status']}] до {exp}")

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Payments ---
@router.callback_query(F.data == "nav:admin:payments")
async def adm_payments(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_payments")
    try:
        data = await billing_client.admin_list_payments()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    items = data.get("items", [])
    lines = [t("adm_payments_title", lang)]
    for p in items[:15]:
        lines.append(
            f"• #{p['id']} {p['provider']} {p['amount']} {p['currency']} [{p['status']}]"
        )

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Servers ---
@router.callback_query(F.data == "nav:admin:servers")
async def adm_servers(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_servers")
    try:
        data = await billing_client.admin_list_servers()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    items = data.get("items", [])
    lines = [t("adm_servers_title", lang)]
    for s in items:
        load = s.get("load", {})
        cpu = load.get("cpu", "?")
        lines.append(
            f"• #{s['id']} {s['name']} [{s['status']}] protocol={s.get('protocol', '?')} "
            f"{s['current_clients']}/{s['max_clients']} клиентов CPU={cpu}"
        )

    await cb.message.edit_text(
        "\n".join(lines) if items else t("adm_no_servers", lang),
        reply_markup=admin_back_keyboard(lang),
    )
    await cb.answer()


# --- Text commands for admin actions ---

@router.message(Command("extend"))
async def cmd_extend(msg: Message, lang: str):
    """Usage: /extend <sub_id> [days]"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_extend_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        days = int(parts[2]) if len(parts) > 2 else 30
        await billing_client.admin_extend_subscription(sub_id, days)
        await msg.answer(t("adm_extend_success", lang, sub_id=sub_id, days=days))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("disable_sub"))
async def cmd_disable_sub(msg: Message, lang: str):
    """Usage: /disable_sub <sub_id>"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_disable_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        await billing_client.admin_disable_subscription(sub_id)
        await msg.answer(t("adm_disable_success", lang, sub_id=sub_id))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("reissue_device"))
async def cmd_reissue_device(msg: Message, lang: str):
    """
    Usage: /reissue_device <sub_id>

    (Re-)provisions the VPN client for a subscription. Covers two cases:
    - The subscription has a VpnClient but it's broken (key looks valid but
      never connects) — the old client is best-effort deleted and a new one
      created in its place.
    - The subscription has NO VpnClient at all — e.g. the purchase went
      through but provisioning failed before any client was created (a
      common cause: no VPN server was configured in the DB yet). A fresh
      client is created for it.
    Use this any time a customer paid but doesn't have a working key.
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_reissue_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        await billing_client.admin_reissue_device(sub_id)
        await msg.answer(t("adm_reissue_success", lang, sub_id=sub_id))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("server_status"))
async def cmd_server_status(msg: Message, lang: str):
    """Usage: /server_status <server_id> <active|disabled>"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 3:
        await msg.answer(t("adm_server_status_usage", lang))
        return
    try:
        server_id = int(parts[1])
        status = parts[2]
        await billing_client.admin_set_server_status(server_id, status)
        await msg.answer(t("adm_server_status_success", lang, server_id=server_id, status=status))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("add_server"))
async def cmd_add_server(msg: Message, lang: str):
    """
    Usage: /add_server <name> <base_url> <api_key> [region] [weight] [max_clients]

    Example:
      /add_server Server-DE http://45.10.20.30 8f2a1c... DE 100 200

    base_url should point at the amnezia-api instance on that VPN server
    (port 80 through its nginx proxy — not 4001). api_key is the
    FASTIFY_API_KEY that amnezia-api's setup.sh printed on that server.

    The AmneziaWG protocol is no longer a manual argument — the bot asks
    that server's own amnezia-api instance which protocols it supports
    (GET /server) and uses whichever one this project requires. If that
    server doesn't support it yet, the server is NOT added and the reply
    explains it needs an AmneziaWG upgrade first.
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 4:
        await msg.answer(t("adm_add_server_usage", lang))
        return
    try:
        name = parts[1]
        base_url = parts[2]
        api_key = parts[3]
        region = parts[4] if len(parts) > 4 else "EU"
        weight = int(parts[5]) if len(parts) > 5 else 100
        max_clients = int(parts[6]) if len(parts) > 6 else 200
        result = await billing_client.admin_add_server(
            name=name,
            base_url=base_url,
            api_key=api_key,
            region=region,
            weight=weight,
            max_clients=max_clients,
        )
        await msg.answer(
            t(
                "adm_add_server_success",
                lang,
                id=result["id"],
                name=result["name"],
                protocol=result["protocol"],
            )
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 422:
            await msg.answer(t("adm_add_server_protocol_unsupported", lang, error=e.response.text))
        elif e.response.status_code == 503:
            await msg.answer(t("adm_add_server_unreachable", lang, error=e.response.text))
        else:
            await msg.answer(t("adm_generic_error", lang, error=e))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("add_agent"))
async def cmd_add_agent(msg: Message, lang: str):
    """
    Usage: /add_agent <telegram_id> [display name]

    Registers a manat-payment agent. The agent starts with zero phone
    numbers and is skipped by the assignment queue until at least one is
    added via /add_agent_phone.
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split(maxsplit=2)
    if len(parts) < 2:
        await msg.answer(t("admin_agent_usage", lang))
        return
    try:
        telegram_id = int(parts[1])
        display_name = parts[2] if len(parts) > 2 else None
        await billing_client.admin_create_agent(telegram_id, display_name)
        await msg.answer(t("admin_agent_added", lang, telegram_id=telegram_id))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 409:
            await msg.answer(t("admin_agent_exists", lang))
        else:
            await msg.answer(t("adm_generic_error", lang, error=e))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("add_agent_phone"))
async def cmd_add_agent_phone(msg: Message, lang: str):
    """Usage: /add_agent_phone <telegram_id> <phone_number> [daily_limit]

    Adds a phone number to an already-registered agent (see /add_agent).
    New numbers start enabled and immediately become eligible for
    assignment (subject to the agent being active, on-shift, and the
    number's own trailing-24h limit — ТЗ p.9). daily_limit is optional,
    in TMT, defaults to 350; pass 0 for unlimited."""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 3:
        await msg.answer(t("admin_agent_phone_usage", lang))
        return
    try:
        telegram_id = int(parts[1])
        phone_number = parts[2]
        daily_limit: float | None = 350
        if len(parts) > 3:
            raw_limit = float(parts[3])
            daily_limit = None if raw_limit <= 0 else raw_limit
        agent = await billing_client.get_agent_by_telegram_id(telegram_id)
        await billing_client.admin_add_agent_phone(agent["id"], phone_number, daily_limit_manat=daily_limit)
        await msg.answer(
            t("admin_agent_phone_added", lang, phone=phone_number, telegram_id=telegram_id)
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            await msg.answer(t("admin_agent_not_found", lang))
        else:
            await msg.answer(t("adm_generic_error", lang, error=e))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("toggle_agent"))
async def cmd_toggle_agent(msg: Message, lang: str):
    """
    Usage: /toggle_agent <telegram_id>

    Admin-only kill switch, independent of the agent's work schedule (ТЗ
    p.2/p.10 — "Администратор должен иметь возможность вручную
    включить/выключить агента независимо от расписания"). Flips
    manually_disabled; an agent inside their shift window is still skipped
    by assignment while disabled this way.
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("admin_agent_manual_toggle_usage", lang))
        return
    try:
        telegram_id = int(parts[1])
        agent = await billing_client.get_agent_by_telegram_id(telegram_id)
        new_state = not agent.get("manually_disabled", False)
        await billing_client.admin_set_agent_manual_disable(agent["id"], new_state)
        if new_state:
            await msg.answer(t("admin_agent_disabled", lang, telegram_id=telegram_id))
        else:
            await msg.answer(t("admin_agent_enabled", lang, telegram_id=telegram_id))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            await msg.answer(t("admin_agent_not_found", lang))
        else:
            await msg.answer(t("adm_generic_error", lang, error=e))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("agent_schedule"))
async def cmd_agent_schedule(msg: Message, lang: str):
    """
    Usage: /agent_schedule <telegram_id> <days> <start> <end> [timezone]

    Configures an agent's work schedule (ТЗ p.2/p.10). <days> is a
    comma-separated list of ISO weekday numbers (1=Mon..7=Sun) or "all";
    <start>/<end> are HH:MM in the agent's own timezone (defaults to
    Asia/Ashgabat, or pass a 5th argument to override, e.g. Asia/Ashgabat).
    Example: /agent_schedule 123456789 1,2,3,4,5 09:00 18:00
    Pass "clear" as <days> to remove the schedule entirely (agent then
    available at any time whenever active and not manually disabled).
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("admin_agent_schedule_usage", lang))
        return
    try:
        telegram_id = int(parts[1])
        agent = await billing_client.get_agent_by_telegram_id(telegram_id)

        if len(parts) > 2 and parts[2].lower() == "clear":
            await billing_client.admin_set_agent_schedule(
                agent["id"], work_days=None, work_start_time=None, work_end_time=None
            )
            await msg.answer(t("admin_agent_schedule_cleared", lang, telegram_id=telegram_id))
            return

        if len(parts) < 5:
            await msg.answer(t("admin_agent_schedule_usage", lang))
            return

        days_raw = parts[2]
        work_days = None if days_raw.lower() == "all" else days_raw
        start_time = parts[3]
        end_time = parts[4]
        timezone_name = parts[5] if len(parts) > 5 else agent.get("timezone", "Asia/Ashgabat")

        await billing_client.admin_set_agent_schedule(
            agent["id"],
            timezone=timezone_name,
            work_days=work_days,
            work_start_time=start_time,
            work_end_time=end_time,
        )
        await msg.answer(
            t(
                "admin_agent_schedule_set",
                lang,
                telegram_id=telegram_id,
                days=days_raw,
                start=start_time,
                end=end_time,
                timezone=timezone_name,
            )
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            await msg.answer(t("admin_agent_not_found", lang))
        else:
            await msg.answer(t("adm_generic_error", lang, error=e))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("manat_queue"))
async def cmd_manat_queue(msg: Message, lang: str):
    """
    Usage: /manat_queue

    Shows the main admin's review queue — "Оплаты манатами на проверке"
    (ТЗ p.6/p.11): requests where an agent reported receipt and the final
    admin decision is still pending. Each item includes an
    approve/reject keyboard.
    """
    if not _is_admin(msg.from_user.id):
        return
    try:
        result = await billing_client.admin_get_manat_queue()
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))
        return

    items = result.get("items", [])
    if not items:
        await msg.answer(t("admin_manat_queue_empty", lang))
        return

    await msg.answer(t("admin_manat_queue_header", lang, count=len(items)))
    for item in items:
        payer = f"@{item['payer_username']}" if item.get("payer_username") else str(item.get("payer_telegram_id") or "?")
        agent_label = item.get("agent_display_name") or str(item.get("agent_telegram_id") or "?")
        created_at = (item.get("created_at") or "")[:16].replace("T", " ")
        text = t(
            "admin_manat_queue_item",
            lang,
            id=item["id"],
            amount=item["amount_manat"],
            payer=payer,
            agent=agent_label,
            created_at=created_at,
        )
        builder = InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(
                    text=t("manat_admin_approve_btn", lang),
                    callback_data=f"manat_admin_approve:{item['id']}",
                ),
                InlineKeyboardButton(
                    text=t("manat_admin_reject_btn", lang),
                    callback_data=f"manat_admin_reject:{item['id']}",
                ),
            ]]
        )
        await msg.answer(text, reply_markup=builder)


# --- Broadcast --------------------------------------------------------------

@dataclass
class _PendingBroadcast:
    from_chat_id: int
    message_id: int
    reply_markup: InlineKeyboardMarkup | None
    recipient_count: int


# In-memory, not FSM state: the parsed button list can be long enough that
# stuffing it into FSMContext (which round-trips through storage on every
# get/update) is wasteful, and this only ever needs to survive between two
# messages from the same admin a few seconds apart — MemoryStorage-level
# durability is more than enough. Keyed by admin telegram_id so multiple
# admins can each have their own pending broadcast without clobbering each
# other's.
_pending_broadcasts: dict[int, _PendingBroadcast] = {}


async def _run_broadcast(bot: Bot, admin_chat_id: int, lang: str, pending: _PendingBroadcast, recipient_ids: list[int]) -> None:
    """
    Sends the copy to every recipient, respecting Telegram's ~30 msg/sec
    global rate limit with a small per-send sleep, treating
    TelegramForbiddenError (blocked the bot / deleted account — routine and
    expected at this scale, not a reason to stop) as a normal failure to
    count rather than log loudly, and honoring TelegramRetryAfter's
    requested wait instead of hammering straight into the next flood-control
    rejection. Runs as a background task (see cb_broadcast_confirm) so the
    bot's event loop keeps handling other users' updates while this is in
    flight instead of freezing on it.
    """
    sent, failed = 0, 0
    for telegram_id in recipient_ids:
        for attempt in range(2):  # one retry after a RetryAfter wait, then give up on that recipient
            try:
                await bot.copy_message(
                    chat_id=telegram_id,
                    from_chat_id=pending.from_chat_id,
                    message_id=pending.message_id,
                    reply_markup=pending.reply_markup,
                )
                sent += 1
                break
            except TelegramRetryAfter as exc:
                logger.info("Broadcast flood-controlled, waiting %ss", exc.retry_after)
                await asyncio.sleep(exc.retry_after)
                continue
            except TelegramForbiddenError:
                # Blocked the bot, deleted their account, etc. — expected
                # and routine at any real scale, not worth an error log per
                # occurrence.
                failed += 1
                break
            except Exception as exc:
                logger.warning("Broadcast to %s failed: %s", telegram_id, exc)
                failed += 1
                break
        await asyncio.sleep(0.05)  # ~20/sec, comfortably under Telegram's ~30/sec global cap

    await bot.send_message(admin_chat_id, t("adm_broadcast_done", lang, sent=sent, failed=failed))


@router.message(Command("broadcast"))
async def cmd_broadcast(msg: Message, command: CommandObject, lang: str):
    """
    Usage: reply to the message you want broadcast with /broadcast, adding
    button lines as the command's argument text if you want link buttons.
    See adm_broadcast_usage for the exact button syntax.

    This only parses and previews — nothing is sent until the admin taps
    the confirm button on the preview (see cb_broadcast_confirm). A typo'd
    /broadcast on the wrong message must not be able to reach 50 real users.
    """
    if not _is_admin(msg.from_user.id):
        return
    if not msg.reply_to_message:
        await msg.answer(t("adm_broadcast_no_reply", lang) + "\n\n" + t("adm_broadcast_usage", lang))
        return

    try:
        reply_markup = _parse_broadcast_buttons(command.args or "")
    except ButtonParseError as e:
        await msg.answer(t("adm_broadcast_bad_button", lang, line_num=e.line_num, line=e.line))
        return

    try:
        recipient_ids = await billing_client.admin_broadcast_recipients()
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))
        return

    _pending_broadcasts[msg.from_user.id] = _PendingBroadcast(
        from_chat_id=msg.chat.id,
        message_id=msg.reply_to_message.message_id,
        reply_markup=reply_markup,
        recipient_count=len(recipient_ids),
    )

    confirm_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t("adm_broadcast_confirm_btn", lang), callback_data="broadcast_confirm"),
                InlineKeyboardButton(text=t("adm_broadcast_cancel_btn", lang), callback_data="broadcast_cancel"),
            ]
        ]
    )
    await msg.answer(
        t("adm_broadcast_confirm", lang, count=len(recipient_ids)),
        reply_markup=confirm_kb,
    )


@router.callback_query(F.data == "broadcast_confirm")
async def cb_broadcast_confirm(cb: CallbackQuery, bot: Bot, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    pending = _pending_broadcasts.pop(cb.from_user.id, None)
    if not pending:
        # Stale button (bot restarted, or this admin already confirmed/
        # cancelled it and is tapping a leftover message) — MemoryStorage
        # doesn't survive a restart, so this is the honest way to say
        # "start over" rather than silently doing nothing.
        await cb.answer(t("adm_broadcast_expired", lang), show_alert=True)
        return

    await cb.message.edit_text(t("adm_broadcast_started", lang, count=pending.recipient_count))
    await cb.answer()

    try:
        recipient_ids = await billing_client.admin_broadcast_recipients()
    except Exception as e:
        await bot.send_message(cb.from_user.id, t("adm_generic_error", lang, error=e))
        return

    # Fire-and-forget: the admin already got the "started" confirmation
    # above, and 50+ sequential Telegram API calls must not block this
    # handler (and therefore the bot's single event loop) from processing
    # anyone else's updates in the meantime.
    asyncio.create_task(_run_broadcast(bot, cb.from_user.id, lang, pending, recipient_ids))


@router.callback_query(F.data == "broadcast_cancel")
async def cb_broadcast_cancel(cb: CallbackQuery, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    _pending_broadcasts.pop(cb.from_user.id, None)
    await cb.message.edit_text(t("adm_broadcast_cancelled", lang))
    await cb.answer()


# --- Trial link ---------------------------------------------------------

@router.message(Command("trial_link"))
async def cmd_trial_link(msg: Message, bot: Bot, lang: str):
    """Usage: /trial_link (no arguments) — posts the deep-link that grants
    the free trial, for sharing with users who already started the bot
    before this feature existed (new users get the trial automatically)."""
    if not _is_admin(msg.from_user.id):
        return
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start=trial"
    await msg.answer(t("adm_trial_link_message", lang, link=link))
