"""Inline keyboards for the screen-based bot UI."""
from __future__ import annotations

from typing import Optional

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.locales import t


def language_picker(lang: str = "ru", include_back: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=t("btn_lang_ru", lang), callback_data="lang:ru"),
        InlineKeyboardButton(text=t("btn_lang_tk", lang), callback_data="lang:tk"),
    )
    if include_back:
        builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def main_menu(lang: str, support_link: str) -> InlineKeyboardMarkup:
    """The only screen without a back button: it is the navigation root.
    Support is a direct URL button (opens the support chat immediately)
    rather than routing through an intermediate "nav:support" screen with
    a link inside its text — one tap instead of two."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_my_subscriptions", lang), callback_data="nav:devices"))
    builder.row(InlineKeyboardButton(text=t("btn_buy_new", lang), callback_data="nav:buy_new"))
    builder.row(
        InlineKeyboardButton(text=t("btn_download_vpn", lang), callback_data="nav:download_vpn"),
        InlineKeyboardButton(text=t("btn_support", lang), url=support_link),
    )
    builder.row(
        InlineKeyboardButton(text=t("btn_info", lang), callback_data="nav:info"),
        InlineKeyboardButton(text=t("btn_language", lang), callback_data="nav:language"),
    )
    return builder.as_markup()


def back_keyboard(lang: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def devices_keyboard(lang: str, devices: list[dict]) -> InlineKeyboardMarkup:
    """List screen. Each device opens its own card screen."""
    builder = InlineKeyboardBuilder()
    for i, d in enumerate(devices, start=1):
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_open", lang, n=i), callback_data=f"nav:device:{d['id']}"
            )
        )
    builder.row(InlineKeyboardButton(text=t("btn_buy_new", lang), callback_data="nav:buy_new"))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def device_card_keyboard(lang: str, device: dict, number: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if device.get("config_url") and device.get("status") == "active":
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_connect", lang, n=number), callback_data=f"show_key:{device['id']}"
            )
        )
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_qr", lang, n=number), callback_data=f"show_qr:{device['id']}"
            )
        )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_device_renew", lang, n=number),
            callback_data=f"nav:renew:{device['id']}",
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def tariff_select_keyboard(
    lang: str, plans: list[dict], mode: str, target_id: Optional[int]
) -> InlineKeyboardMarkup:
    """Screen shown after "Buy subscription" / "Renew" — one button per
    active plan (1/3/6 months), showing only the duration. Prices move to
    the payment-method screen (see payment_method_menu), where each
    currency's own button shows its own price — repeating a single
    currency's price here added noise without helping the actual decision
    at this step, which is just how long."""
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    for plan in plans:
        builder.row(
            InlineKeyboardButton(
                text=t("btn_tariff_option", lang, duration_days=plan["duration_days"]),
                callback_data=f"nav:tariff:{plan['id']}:{mode}:{target}",
            )
        )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def payment_method_menu(
    lang: str, plan: dict, mode: str, target_id: Optional[int]
) -> InlineKeyboardMarkup:
    """Each button shows that payment method's own price inline (Stars,
    USDT, TMT) — the person picks a currency and sees its cost in one tap
    rather than needing the plan card text to spell out three prices
    first. Manat stays shown even for non-1-month plans (tapping it then
    explains it's 1-month-only) rather than disappearing, since a plan
    with a hidden option can read as a plan with fewer choices."""
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_stars", lang, price_stars=plan["price_stars"]),
            callback_data=f"pay_stars:{mode}:{target}:{plan['id']}",
        )
    )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_usdt", lang, price_usdt=int(round(plan["price_usdt"]))),
            callback_data=f"pay_usdt:{mode}:{target}:{plan['id']}",
        )
    )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_manat", lang, price_manat=int(round(plan["price_manat"]))),
            callback_data=f"pay_manat:{mode}:{target}:{plan['id']}",
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def invoice_keyboard(lang: str, price_stars: int) -> InlineKeyboardMarkup:
    """
    reply_markup for send_invoice: Telegram requires the first button to be
    a `pay=True` button when reply_markup is provided at all (otherwise
    Telegram auto-generates one with English "Pay {price}" text, which is
    what we're overriding here for tk/ru). '⭐' in the button text is
    rendered by Telegram as its native Star icon, not a literal emoji.
    A second row with a normal callback button (nav:back) is allowed by the
    API as long as the Pay button stays first.
    """
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_invoice_pay", lang, price=price_stars), pay=True))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def check_usdt_payment(
    lang: str, invoice_id: str, mode: str, target_id: Optional[int], pay_url: str
) -> InlineKeyboardMarkup:
    """pay_url is a real Telegram URL button (not a link inside the message
    text) — Telegram renders URL buttons as a tappable "open" action, which
    is both clearer and safer than a bare link the person has to
    long-press/copy manually."""
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_usdt_pay_link", lang), url=pay_url))
    builder.row(
        InlineKeyboardButton(
            text=t("btn_i_paid", lang), callback_data=f"check_usdt:{invoice_id}:{mode}:{target}"
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def config_ready_keyboard(lang: str, has_config: bool, subscription_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_config:
        builder.row(
            InlineKeyboardButton(text=t("btn_connect_amnezia", lang), callback_data=f"show_key:{subscription_id}")
        )
        builder.row(
            InlineKeyboardButton(text=t("btn_show_qr", lang), callback_data=f"show_qr:{subscription_id}")
        )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def download_vpn_keyboard(
    lang: str, google_play_url: str, app_store_url: str, apk_url: str
) -> InlineKeyboardMarkup:
    """Three separate download sources rather than one generic link — each
    platform goes straight to its own store/file. apk_url is expected to
    be a GitHub "latest release" redirect URL (see settings.ANDROID_APK_LINK)
    so it always resolves to Amnezia's most recent Android build."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_download_android", lang), url=google_play_url))
    builder.row(InlineKeyboardButton(text=t("btn_download_ios", lang), url=app_store_url))
    builder.row(InlineKeyboardButton(text=t("btn_download_apk", lang), url=apk_url))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def info_keyboard(
    lang: str, privacy_url: str, terms_url: str, channel_url: str
) -> InlineKeyboardMarkup:
    """All three are real Telegram URL buttons (open externally), sourced
    from settings.* env vars — see bot/config.py — so an admin can update
    any of them without a code change."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_privacy_policy", lang), url=privacy_url))
    builder.row(InlineKeyboardButton(text=t("btn_terms_of_service", lang), url=terms_url))
    builder.row(InlineKeyboardButton(text=t("btn_our_channel", lang), url=channel_url))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def admin_menu(lang: str, show_back: bool = True) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("adm_btn_users", lang), callback_data="nav:admin:users"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_subs", lang), callback_data="nav:admin:subs"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_payments", lang), callback_data="nav:admin:payments"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_servers", lang), callback_data="nav:admin:servers"))
    if show_back:
        builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="start"))
    return builder.as_markup()


def admin_back_keyboard(lang: str) -> InlineKeyboardMarkup:
    return back_keyboard(lang)


# --- Manat (manual bank transfer via agent queue) ---

def manat_agent_accept_keyboard(lang: str, request_id: int) -> InlineKeyboardMarkup:
    """Shown to the assigned agent during the 5-minute acceptance window."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("manat_agent_ready_btn", lang), callback_data=f"manat_ready:{request_id}"
        ),
        InlineKeyboardButton(
            text=t("manat_agent_not_ready_btn", lang), callback_data=f"manat_notready:{request_id}"
        ),
    )
    return builder.as_markup()


def manat_payer_paid_keyboard(lang: str, request_id: int, amount: float) -> InlineKeyboardMarkup:
    """Shown to the payer during the 15-minute payment window — "I paid"
    only; there is no self-service "cancel", matching the product flow."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("manat_i_paid_btn", lang, amount=amount),
            callback_data=f"manat_paid:{request_id}",
        )
    )
    return builder.as_markup()


def manat_agent_confirm_keyboard(lang: str, request_id: int) -> InlineKeyboardMarkup:
    """Shown to the agent after the payer taps "I paid" — the agent can
    only REPORT receipt (ТЗ p.5/p.7: this is a claim, not a confirmation).
    Tapping "money received" hands the request to the main admin's review
    queue; it does NOT create a subscription."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("manat_agent_money_received_btn", lang), callback_data=f"manat_report_yes:{request_id}"
        ),
        InlineKeyboardButton(
            text=t("manat_agent_money_not_received_btn", lang), callback_data=f"manat_report_no:{request_id}"
        ),
    )
    return builder.as_markup()


def manat_admin_review_keyboard(lang: str, request_id: int) -> InlineKeyboardMarkup:
    """Shown to the main admin in the "Оплаты манатами на проверке" queue
    (ТЗ p.6). Only this admin action can approve/reject — no agent-facing
    keyboard offers these callbacks."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("manat_admin_approve_btn", lang), callback_data=f"manat_admin_approve:{request_id}"
        ),
        InlineKeyboardButton(
            text=t("manat_admin_reject_btn", lang), callback_data=f"manat_admin_reject:{request_id}"
        ),
    )
    return builder.as_markup()


def agent_phones_keyboard(lang: str, phones: list[dict]) -> InlineKeyboardMarkup:
    """One row per phone with a toggle button — used by /my_numbers. Each
    phone dict needs at least {"id", "phone_number", "is_enabled"}."""
    builder = InlineKeyboardBuilder()
    for phone in phones:
        if phone["is_enabled"]:
            label = t("agent_phone_disable_btn", lang, phone=phone["phone_number"])
        else:
            label = t("agent_phone_enable_btn", lang, phone=phone["phone_number"])
        builder.row(
            InlineKeyboardButton(text=label, callback_data=f"agentphone_toggle:{phone['id']}")
        )
    return builder.as_markup()
