"""
Telegram bot entry point.
Uses aiogram 3 in polling mode (no webhook needed for MVP).
"""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import ErrorEvent

from bot.config import settings
from bot.handlers.admin_handlers import router as admin_router
from bot.handlers.main_handlers import router as main_router
from bot.middlewares.language import LanguageMiddleware

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("bot")


async def main():
    bot = Bot(
        token=settings.TELEGRAM_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    @dp.errors()
    async def on_unhandled_error(event: ErrorEvent):
        """
        Without this, any exception a handler doesn't explicitly catch is
        only logged and silently swallowed by aiogram — the user sees no
        reply at all (indistinguishable from the bot being broken/down).
        This logs the full traceback (so real bugs are visible in the
        service logs instead of vanishing) and, where possible, tells the
        whoever triggered it that something went wrong rather than leaving
        them staring at silence.
        """
        logger.exception(
            "Unhandled exception while processing update %s: %s",
            event.update.update_id if event.update else "?",
            event.exception,
        )
        update = event.update
        chat_id = None
        if update.message:
            chat_id = update.message.chat.id
        elif update.callback_query and update.callback_query.message:
            chat_id = update.callback_query.message.chat.id
        if chat_id is not None:
            try:
                await bot.send_message(
                    chat_id,
                    "⚠️ Произошла внутренняя ошибка. Попробуйте ещё раз или обратитесь в поддержку.",
                )
            except Exception:
                pass
        return True

    lang_mw = LanguageMiddleware()
    dp.message.middleware(lang_mw)
    dp.callback_query.middleware(lang_mw)

    dp.include_router(main_router)
    dp.include_router(admin_router)

    logger.info("Bot starting (polling mode)...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
