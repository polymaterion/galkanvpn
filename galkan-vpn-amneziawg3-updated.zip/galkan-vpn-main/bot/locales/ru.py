"""
Russian strings. This is the fallback language — if a key is missing from
another locale, or the value fails to format, this is what gets shown.
"""

STRINGS: dict[str, str] = {
    # --- Language picker (shown once, on first /start) ---
    "language_prompt": "🌐 Выберите язык / Diliňizi saýlaň:",
    "btn_lang_ru": "🇷🇺 Русский",
    "btn_lang_tk": "🇹🇲 Türkmençe",
    "language_saved": "Язык сохранён: Русский ✅",

    # --- Welcome / main menu ---
    "welcome": (
        "👋 Добро пожаловать в <b>Galkan VPN</b>!\n\n"
        "🛡 Безопасный VPN на основе AmneziaWG — обходит блокировки без следов.\n\n"
        "Выберите действие:"
    ),
    "btn_my_subscriptions": "📱 Мои подписки",
    "btn_buy_new": "➕ Купить подписку",
    "btn_download_vpn": "⬇️ Скачать VPN",
    "btn_support": "💬 Поддержка",
    "btn_info": "ℹ️ Информация",
    "btn_language": "🌐 Язык",
    "btn_back": "◀️ Назад",
    "btn_back_to_menu": "◀️ В главное меню",

    # --- Devices list ---
    "devices_title": "📱 <b>Ваши подписки</b>",
    "devices_empty": (
        "У вас пока нет подписок.\n\n"
        "Каждая подписка — это отдельный VPN-ключ, который можно "
        "использовать на одном телефоне/компьютере."
    ),
    "device_line": "{emoji} Подписка {n}",
    "btn_device_connect": "🔑 Подключить",
    "btn_device_open": "📄 Подписка {n}",
    "btn_device_qr": "📱 QR-код",
    "btn_device_renew": "🔄 Продлить",
    "status_active": "✅ Активно",
    "status_expired": "❌ Истекло",
    "status_pending_provisioning": "⏳ Создаётся",
    "status_error": "⚠️ Ошибка",
    "status_disabled": "🔒 Отключено",
    "status_pending_payment": "💳 Ожидает оплаты",
    "unknown_expiry": "неизвестно",
    "device_card": (
        "📄 <b>Подписка {n}</b>\n\n"
        "Статус: {status}\n"
        "Действует до: {expires}\n\n"
        "Выберите действие:"
    ),

    # --- Buy flow: tariff selection ---
    "tariff_select_title": "💎 <b>Выберите срок подписки:</b>",
    "btn_tariff_option": "{duration_days} дней",

    "plan_name_text": "VPN — {duration_days} дней",
    "plan_description_text": "Безлимитный VPN на {duration_days} дней. Протокол AmneziaWG.",
    "plan_card": "💎 <b>{name}</b>\n\nВыберите способ оплаты:",
    "renew_card": (
        "🔄 <b>Продление подписки {n}</b>\n"
        "⏱ Ещё {duration_days} дней\n\n"
        "Выберите способ оплаты:"
    ),
    "btn_pay_stars": "⭐ Telegram Stars {price_stars}",
    "btn_pay_usdt": "💎 Криптовалюта ${price_usdt}",
    "btn_pay_manat": "🇹🇲 TM CELL перевод {price_manat}TMT",
    "btn_invoice_pay": "Оплатить ⭐{price}",
    "plan_unavailable": "Тарифы временно недоступны.",
    "plan_load_error": "Ошибка загрузки тарифа.",

    # --- Payment processing ---
    "payment_processing": "⏳ Оплата получена! {action}",
    "payment_processing_new": "Создаём ваш новый VPN-ключ...",
    "payment_processing_renew": "Продлеваем устройство...",
    "payment_error": (
        "❗ Оплата прошла, но возникла ошибка при создании VPN-доступа.\n"
        "Обратитесь в поддержку — мы всё исправим!"
    ),
    "provisioning_pending": (
        "⏳ VPN-доступ создаётся, это займёт несколько минут.\n"
        "Вы получите уведомление, как только он будет готов — загляните в "
        "«Мои устройства»."
    ),

    # --- Config ready (post-payment / resend) ---
    "config_ready": (
        "✅ <b>Устройство готово!</b>\n"
        "⏳ Действует до: <b>{expires}</b>\n\n"
        "Ключ доступен в любое время по кнопке ниже."
    ),
    "btn_connect_amnezia": "🔑 Показать ключ",
    "btn_show_qr": "📱 Показать QR-код",
    "qr_caption": "📷 Отсканируйте этот QR-код в приложении AmneziaVPN",
    "qr_unavailable": "Конфигурация недоступна. Попробуйте позже.",
    "config_key_message": (
        "🔑 Ваш ключ подключения:\n"
        "<pre>{config_url}</pre>\n\n"
        "Нажмите «Copy Code» на блоке выше, затем вставьте его в приложение AmneziaVPN "
        "через «Добавить конфигурацию» → «Из буфера обмена»."
    ),

    # --- USDT flow ---
    "usdt_unavailable": "USDT оплата временно недоступна. Попробуйте Telegram Stars.",
    "usdt_invoice_error": "Ошибка создания инвойса. Попробуйте позже.",
    "usdt_invoice_card": (
        "💎 <b>Оплата USDT</b>\n\n"
        "Сумма: <b>${amount} USDT</b>\n\n"
        "Нажмите «Перейти к оплате», затем подтвердите оплату кнопкой ✅"
    ),
    "btn_usdt_pay_link": "👉 Перейти к оплате",
    "btn_i_paid": "✅ Я оплатил",
    "btn_cancel": "❌ Отмена",
    "usdt_check_error": "Ошибка проверки оплаты. Попробуйте позже.",
    "usdt_not_paid_yet": "Оплата ещё не поступила. Попробуйте через минуту.",
    "usdt_confirmed": "⏳ Оплата подтверждена! {action}",
    "usdt_activation_error": "❗ Ошибка при активации. Обратитесь в поддержку.",

    # --- Support ---
    "support_text": "💬 <b>Поддержка</b>\n\nПо любым вопросам: {support_link}",

    # --- Download VPN ---
    "download_vpn_text": "⬇️ <b>Скачать AmneziaVPN</b>\n\nВыберите вашу платформу:",
    "btn_download_android": "🤖 Android (Google Play)",
    "btn_download_ios": "🍏 iOS (App Store)",
    "btn_download_apk": "⬇️ Скачать APK",

    # --- Info ---
    "info_text": "ℹ️ <b>Информация</b>",
    "btn_privacy_policy": "🔒 Политика конфиденциальности",
    "btn_terms_of_service": "📜 Пользовательское соглашение",
    "btn_our_channel": "📢 Наш канал",

    # --- Misc errors ---
    "no_active_device": "Устройство не найдено.",

    # --- Admin panel (respects the admin's own selected language, same as
    # the rest of the bot — see admin_handlers.py) ---
    "adm_access_denied": "⛔ Доступ запрещён.",
    "adm_no_access": "⛔ Нет доступа.",
    "adm_panel_title": "🔧 <b>Панель администратора</b>",
    "adm_btn_users": "👥 Пользователи",
    "adm_btn_subs": "📋 Подписки",
    "adm_btn_payments": "💰 Платежи",
    "adm_btn_servers": "🖥 Серверы",
    "adm_btn_back": "◀️ В панель администратора",
    "adm_users_title": "👥 <b>Пользователи</b> (всего: {total})\n",
    "adm_subs_title": "📋 <b>Подписки</b>\n",
    "adm_payments_title": "💰 <b>Платежи</b>\n",
    "adm_servers_title": "🖥 <b>Серверы VPN</b>\n",
    "adm_no_servers": "Нет серверов",
    "adm_error": "Ошибка: {error}",
    "adm_extend_usage": "Usage: /extend <sub_id> [days=30]",
    "adm_extend_success": "✅ Подписка #{sub_id} продлена на {days} дней.",
    "adm_disable_usage": "Usage: /disable_sub <sub_id>",
    "adm_disable_success": "✅ Подписка #{sub_id} отключена.",
    "adm_reissue_usage": "Usage: /reissue_device <sub_id>",
    "adm_reissue_success": (
        "✅ Устройство подписки #{sub_id} переиздано. Старый ключ больше не "
        "действует — новый уже доступен пользователю через «Показать ключ»."
    ),
    "adm_server_status_usage": "Usage: /server_status <server_id> <active|disabled>",
    "adm_server_status_success": "✅ Сервер #{server_id} → {status}",
    "adm_add_server_usage": (
        "Usage: /add_server <name> <base_url> <api_key> [region] [weight] [max_clients]\n"
        "Example: /add_server Server-DE http://1.2.3.4 <FASTIFY_API_KEY> DE 100 200\n"
        "Протокол определяется автоматически через amnezia-api этого сервера."
    ),
    "adm_add_server_success": "✅ Сервер #{id} «{name}» добавлен и активен (протокол: {protocol}).",
    "adm_add_server_protocol_unsupported": (
        "❌ Сервер не поддерживает требуемую версию AmneziaWG.\n"
        "Обновите AmneziaWG на этом сервере до актуальной версии и попробуйте снова.\n{error}"
    ),
    "adm_add_server_unreachable": (
        "❌ Не удалось подключиться к amnezia-api на этом сервере. "
        "Проверьте адрес и доступность сервера.\n{error}"
    ),
    "adm_generic_error": "❌ Ошибка: {error}",

    # --- Trial (user-facing) ---
    "trial_granted": (
        "🎁 Вам выдан пробный период на {days} дн.!\n\n"
        "Откройте «Мои устройства», чтобы получить ключ подключения."
    ),
    "trial_already_used": "Пробный период уже был использован на этом аккаунте.",
    "trial_error": "Не удалось выдать пробный период. Попробуйте позже или обратитесь в поддержку.",

    # --- Admin: trial link ---
    "adm_trial_link_message": (
        "🔗 Ссылка для подключения пробного периода:\n{link}\n\n"
        "Работает и для тех, кто уже запускал бота раньше."
    ),

    # --- Admin: broadcast ---
    "adm_broadcast_usage": (
        "Usage: ответьте командой /broadcast на сообщение, которое нужно разослать "
        "(текст, фото/видео с подписью — что угодно).\n\n"
        "Чтобы добавить кнопки-ссылки, добавьте после команды по одной кнопке на строке:\n"
        "/broadcast\n"
        "Текст кнопки - https://example.com\n"
        "Ещё кнопка - https://example.com\n\n"
        "Кнопки в одну строку через « | » окажутся рядом:\n"
        "Кнопка A - https://a.com | Кнопка B - https://b.com"
    ),
    "adm_broadcast_no_reply": "Ответьте этой командой на сообщение, которое нужно разослать.",
    "adm_broadcast_bad_button": (
        "❌ Не удалось разобрать кнопку в строке {line_num}: «{line}»\n"
        "Формат: Текст - https://ссылка"
    ),
    "adm_broadcast_confirm": "📢 Разослать это сообщение {count} пользователям?",
    "adm_broadcast_confirm_btn": "✅ Разослать",
    "adm_broadcast_cancel_btn": "❌ Отмена",
    "adm_broadcast_cancelled": "Рассылка отменена.",
    "adm_broadcast_expired": (
        "⚠️ Это подтверждение больше не действует (например, бот перезапускался). "
        "Начните заново командой /broadcast."
    ),
    "adm_broadcast_started": "⏳ Рассылка запущена ({count} получателей)...",
    "adm_broadcast_done": (
        "✅ Рассылка завершена.\n"
        "Доставлено: {sent}\n"
        "Не доставлено (заблокировали бота и т.п.): {failed}"
    ),

    # --- Manat (manual bank transfer via agent queue) ---
    "manat_unavailable": "Оплата манатом временно недоступна. Попробуйте другой способ оплаты.",
    "manat_only_one_month": (
        "💰 Оплата манатом доступна только для тарифа <b>1 месяц — 40 TMT</b>.\n"
        "Для этого тарифа выберите другой способ оплаты."
    ),
    "manat_request_error": "Не удалось создать заявку на оплату. Попробуйте позже.",
    "manat_no_agent_available": (
        "Сейчас нет доступных операторов для приёма оплаты манатом. "
        "Попробуйте позже или выберите другой способ оплаты."
    ),
    "manat_awaiting_agent": (
        "💳 Заявка на оплату создана.\n"
        "⏱ Ожидаем подтверждения оператора (до 5 минут)..."
    ),
    "manat_request_created": (
        "💳 Оператор готов принять оплату.\n\n"
        "Переведите <b>{amount} TMT</b> на номер:\n"
        "<code>{phone}</code>\n\n"
        "⏱ На оплату: 15 минут.\n"
        "После перевода нажмите «✅ Я перевёл {amount} TMT»."
    ),
    "manat_i_paid_btn": "✅ Я перевёл {amount} TMT",
    "manat_i_paid_notice": (
        "Оператор уведомлён. Дождитесь подтверждения получения перевода."
    ),
    "manat_reassigned_to_payer": (
        "⏱ Оператор не ответил вовремя — заявка передана другому оператору.\n"
        "⏳ Ожидайте подтверждения (до 5 минут)..."
    ),
    "manat_expired_no_agent": (
        "❌ Не удалось найти доступного оператора для вашей заявки. "
        "Попробуйте позже или выберите другой способ оплаты."
    ),
    "manat_expired_payment_window": (
        "❌ Время на оплату (15 минут) истекло, заявка закрыта. "
        "Если вы уже перевели деньги — обратитесь в поддержку."
    ),
    "manat_action_error": "Ошибка при обработке заявки. Попробуйте ещё раз.",
    "manat_already_resolved": "⚠️ Эта заявка больше не закреплена за вами или уже обработана.",
    "manat_not_an_agent": "У вас нет прав для этого действия.",
    "manat_reported_by_you": (
        "📨 Вы сообщили о получении денег по заявке #{request_id}. "
        "Ожидайте подтверждения от главного администратора."
    ),
    "manat_payment_under_review": (
        "💳 Оператор подтвердил получение перевода. Заявка передана "
        "администратору на финальную проверку."
    ),
    "manat_money_not_received_notice": (
        "⏱ Оператор не увидел перевод — заявка передана другому оператору."
    ),
    "manat_rejected_by_you": "❌ Заявка #{request_id} отклонена вами (деньги не получены).",
    "manat_declined_by_you": "Заявка #{request_id} передана следующему оператору.",
    "manat_agent_new_request": (
        "💳 <b>Новая заявка на оплату</b>\n\n"
        "Заявка: #{request_id}\n"
        "От: {payer}\n"
        "Сумма: {amount} TMT\n\n"
        "⏱ Подтвердите готовность принять оплату в течение 5 минут."
    ),
    "manat_agent_ready_btn": "✅ Готов принять",
    "manat_agent_not_ready_btn": "❌ Не могу принять",
    "manat_agent_awaiting_payment": (
        "💳 <b>Заявка #{request_id}</b>\n\n"
        "От: {payer}\n"
        "Сумма: {amount} TMT\n"
        "Ваш номер показан плательщику: {phone}\n\n"
        "Ожидаем, когда плательщик подтвердит перевод."
    ),
    "manat_agent_payer_paid": (
        "💳 Плательщик по заявке #{request_id} сообщил о переводе {amount} TMT.\n\n"
        "Проверьте поступление денег на ваш номер и сообщите результат. "
        "Это не подтверждает оплату — окончательное решение за администратором."
    ),
    "manat_agent_money_received_btn": "✅ Деньги получены",
    "manat_agent_money_not_received_btn": "❌ Деньги не получены",

    # --- Manat: main admin review queue ---
    "manat_admin_review_notice": (
        "🔔 <b>Оплата манатом на проверке</b>\n\n"
        "Заявка: #{request_id}\n"
        "Плательщик: {payer}\n"
        "Сумма: {amount} TMT\n\n"
        "Оператор сообщил о получении денег. Подтвердите или отклоните оплату."
    ),
    "manat_admin_approve_btn": "✅ Подтвердить оплату",
    "manat_admin_reject_btn": "❌ Отклонить оплату",
    "manat_admin_approved_by_you": (
        "✅ Заявка #{request_id} подтверждена. Подписка активируется."
    ),
    "manat_admin_rejected_by_you": "❌ Заявка #{request_id} отклонена.",
    "manat_admin_rejected_notice": (
        "❌ Оплата не подтверждена администратором. Обратитесь в поддержку, "
        "если вы уверены, что перевод был выполнен."
    ),

    # --- Manat agent management ---
    "agent_not_registered": "Вы не зарегистрированы как оператор оплаты манатом.",
    "agent_my_numbers_header": "📱 Ваши номера для приёма манатов:",
    "agent_phone_line": (
        "{status_icon} {phone} — использовано за 24ч: {received}/{limit} TMT"
    ),
    "agent_limit_unlimited": "без лимита",
    "agent_phone_enable_btn": "🟢 Включить {phone}",
    "agent_phone_disable_btn": "🔴 Выключить {phone}",
    "agent_phone_toggled": "Статус номера обновлён.",
    "admin_agent_added": "Оператор {telegram_id} добавлен.",
    "admin_agent_exists": "Оператор с таким telegram_id уже существует.",
    "admin_agent_phone_added": "Номер {phone} добавлен оператору {telegram_id}.",
    "admin_agent_phone_removed": "Номер удалён.",
    "admin_agent_not_found": "Оператор не найден.",
    "admin_agent_usage": "Использование: /add_agent <telegram_id> [имя]",
    "admin_agent_phone_usage": "Использование: /add_agent_phone <telegram_id> <номер>",
    "admin_agent_disabled": "Оператор {telegram_id} отключён вручную.",
    "admin_agent_enabled": "Оператор {telegram_id} снова доступен для назначений.",
    "admin_agent_manual_toggle_usage": "Использование: /toggle_agent <telegram_id>",
    "admin_agent_schedule_usage": (
        "Использование: /agent_schedule <telegram_id> <дни> <начало> <конец> [часовой пояс]\n"
        "Дни — числа 1-7 через запятую (1=Пн..7=Вс) или «all».\n"
        "Пример: /agent_schedule 123456789 1,2,3,4,5 09:00 18:00\n"
        "Чтобы убрать расписание: /agent_schedule 123456789 clear"
    ),
    "admin_agent_schedule_cleared": "Расписание оператора {telegram_id} очищено — доступен всегда.",
    "admin_agent_schedule_set": (
        "Расписание оператора {telegram_id} обновлено: {days}, {start}–{end} ({timezone})."
    ),
    "admin_manat_queue_empty": "Нет заявок на проверке.",
    "admin_manat_queue_header": "🔔 Оплаты манатами на проверке ({count}):",
    "admin_manat_queue_item": (
        "#{id} · {amount} TMT · {payer} · оператор {agent} · создана {created_at}"
    ),
}
