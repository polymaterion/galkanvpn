"""
Turkmen (Türkmençe) strings.

NOTE: this translation was produced by Claude without a native-speaker
review. Standard modern Turkmen (Latin script) vocabulary was used
throughout, but for a real customer-facing product we'd recommend having a
native Turkmen speaker proofread this file before relying on it at scale —
especially the payment/legal-sensitive strings. Any key missing here (or
that fails to .format()) automatically falls back to the Russian string, so
a typo here never breaks the bot, just shows Russian for that one line.
"""

STRINGS: dict[str, str] = {
    "language_prompt": "🌐 Diliňizi saýlaň / Выберите язык:",
    "btn_lang_ru": "🇷🇺 Русский",
    "btn_lang_tk": "🇹🇲 Türkmençe",
    "language_saved": "Dil saklandy: Türkmençe ✅",

    "welcome": (
        "👋 <b>Galkan VPN</b>-a hoş geldiňiz!\n\n"
        "🛡 AmneziaWG esasynda howpsuz VPN — päsgelçilikleri yzsyz aşýar.\n\n"
        "Hereketi saýlaň:"
    ),
    "btn_my_subscriptions": "📱 Meniň abunalarym",
    "btn_buy_new": "➕ Abuna satyn almak",
    "btn_download_vpn": "⬇️ VPN ýüklemek",
    "btn_support": "💬 Goldaw",
    "btn_info": "ℹ️ Maglumat",
    "btn_language": "🌐 Dil",
    "btn_back": "◀️ Yza",
    "btn_back_to_menu": "◀️ Baş menýu",

    "devices_title": "📱 <b>Siziň abunalaryňyz</b>",
    "devices_empty": (
        "Siziň entek abunaňyz ýok.\n\n"
        "Her abuna — bir telefonda/kompýuterde ulanyp boljak aýratyn VPN açary."
    ),
    "device_line": "{emoji} Abuna {n}",
    "btn_device_connect": "🔑 Birikdirmek",
    "btn_device_open": "📄 Abuna {n}",
    "btn_device_qr": "📱 QR-kod",
    "btn_device_renew": "🔄 Uzaltmak",
    "status_active": "✅ Işjeň",
    "status_expired": "❌ Möhleti geçen",
    "status_pending_provisioning": "⏳ Döredilýär",
    "status_error": "⚠️ Ýalňyşlyk",
    "status_disabled": "🔒 Öçürilen",
    "status_pending_payment": "💳 Töleg garaşylýar",
    "unknown_expiry": "näbelli",
    "device_card": (
        "📄 <b>Abuna {n}</b>\n\n"
        "Ýagdaýy: {status}\n"
        "Şu senä çenli hereket edýär: {expires}\n\n"
        "Hereketi saýlaň:"
    ),

    "tariff_select_title": "💎 <b>Abunanyň möhletini saýlaň:</b>",
    "btn_tariff_option": "{duration_days} gün",

    "plan_name_text": "VPN — {duration_days} gün",
    "plan_description_text": "AmneziaWG protokoly esasynda {duration_days} günlük çäksiz VPN.",
    "plan_card": "💎 <b>{name}</b>\n\nTöleg usulyny saýlaň:",
    "renew_card": (
        "🔄 <b>{n} abunany uzaltmak</b>\n"
        "⏱ Ýene {duration_days} gün\n\n"
        "Töleg usulyny saýlaň:"
    ),
    "btn_pay_stars": "⭐ Telegram Stars {price_stars}",
    "btn_pay_usdt": "💎 Kriptowalýuta ${price_usdt}",
    "btn_pay_manat": "🇹🇲 TM CELL geçirimi {price_manat}TMT",
    "btn_invoice_pay": "Tölemek ⭐{price}",
    "plan_unavailable": "Tarifler wagtlaýyn elýeterli däl.",
    "plan_load_error": "Tarifi ýüklemekde ýalňyşlyk.",

    "payment_processing": "⏳ Töleg kabul edildi! {action}",
    "payment_processing_new": "Täze VPN açaryňyz döredilýär...",
    "payment_processing_renew": "Enjam uzaldylýar...",
    "payment_error": (
        "❗ Töleg geçdi, ýöne VPN elýeterliligini döretmekde ýalňyşlyk ýüze çykdy.\n"
        "Goldawa ýüz tutuň — hemme zady düzederis!"
    ),
    "provisioning_pending": (
        "⏳ VPN elýeterliligi döredilýär, bu birnäçe minut wagt alar.\n"
        "Taýyn bolanda habar alarsyňyz — «Meniň enjamlarym» bölümine serediň."
    ),

    "config_ready": (
        "✅ <b>Enjam taýyn!</b>\n"
        "⏳ Şu senä çenli hereket edýär: <b>{expires}</b>\n\n"
        "Açar aşakdaky düwme arkaly islendik wagt elýeterli."
    ),
    "btn_connect_amnezia": "🔑 Açary görkezmek",
    "btn_show_qr": "📱 QR-kody görkezmek",
    "qr_caption": "📷 Bu QR-kody AmneziaVPN programmasynda skanirläň",
    "qr_unavailable": "Konfigurasiýa elýeterli däl. Soňra synanyşyň.",
    "config_key_message": (
        "🔑 Birikdirmek üçin açaryňyz:\n"
        "<pre>{config_url}</pre>\n\n"
        "Ýokardaky blokda «Copy Code» basyň, soňra AmneziaVPN programmasynda "
        "«Konfigurasiýa goşmak» → «Buferden» arkaly ýerleşdiriň."
    ),

    "usdt_unavailable": "USDT tölegi wagtlaýyn elýeterli däl. Telegram Stars-y synanyşyň.",
    "usdt_invoice_error": "Hasap-faktura döretmekde ýalňyşlyk. Soňra synanyşyň.",
    "usdt_invoice_card": (
        "💎 <b>USDT tölegi</b>\n\n"
        "Möçberi: <b>${amount} USDT</b>\n\n"
        "«Tölege geçmek» düwmesine basyň, soňra ✅ bilen tassyklaň"
    ),
    "btn_usdt_pay_link": "👉 Tölege geçmek",
    "btn_i_paid": "✅ Men töledim",
    "btn_cancel": "❌ Ýatyr",
    "usdt_check_error": "Tölegi barlamakda ýalňyşlyk. Soňra synanyşyň.",
    "usdt_not_paid_yet": "Töleg entek gelip gowuşmady. Bir minutdan soň synanyşyň.",
    "usdt_confirmed": "⏳ Töleg tassyklandy! {action}",
    "usdt_activation_error": "❗ Işjeňleşdirmekde ýalňyşlyk. Goldawa ýüz tutuň.",

    "support_text": "💬 <b>Goldaw</b>\n\nIslendik sorag boýunça: {support_link}",

    "download_vpn_text": "⬇️ <b>AmneziaVPN ýüklemek</b>\n\nPlatformaňyzy saýlaň:",
    "btn_download_android": "🤖 Android (Google Play)",
    "btn_download_ios": "🍏 iOS (App Store)",
    "btn_download_apk": "⬇️ APK ýüklemek",

    "info_text": "ℹ️ <b>Maglumat</b>",
    "btn_privacy_policy": "🔒 Gizlinlik syýasaty",
    "btn_terms_of_service": "📜 Ulanyjy ylalaşygy",
    "btn_our_channel": "📢 Bizin kanalymyz",

    "no_active_device": "Işjeň enjam tapylmady.",

    # --- Admin panel ---
    "adm_access_denied": "⛔ Girmek gadagan.",
    "adm_no_access": "⛔ Elýeterlilik ýok.",
    "adm_panel_title": "🔧 <b>Administrator paneli</b>",
    "adm_btn_users": "👥 Ulanyjylar",
    "adm_btn_subs": "📋 Abunalar",
    "adm_btn_payments": "💰 Tölegler",
    "adm_btn_servers": "🖥 Serwerler",
    "adm_btn_back": "◀️ Administrator paneline",
    "adm_users_title": "👥 <b>Ulanyjylar</b> (jemi: {total})\n",
    "adm_subs_title": "📋 <b>Abunalar</b>\n",
    "adm_payments_title": "💰 <b>Tölegler</b>\n",
    "adm_servers_title": "🖥 <b>VPN serwerleri</b>\n",
    "adm_no_servers": "Serwer ýok",
    "adm_error": "Ýalňyşlyk: {error}",
    "adm_extend_usage": "Usage: /extend <sub_id> [days=30]",
    "adm_extend_success": "✅ #{sub_id} abunasy {days} güne uzaldyldy.",
    "adm_disable_usage": "Usage: /disable_sub <sub_id>",
    "adm_disable_success": "✅ #{sub_id} abunasy öçürildi.",
    "adm_reissue_usage": "Usage: /reissue_device <sub_id>",
    "adm_reissue_success": (
        "✅ #{sub_id} abunasynyň enjamy täzeden döredildi. Köne açar indi "
        "işlemeýär — täzesi ulanyjy üçin «Açary görkezmek» arkaly elýeterli."
    ),
    "adm_server_status_usage": "Usage: /server_status <server_id> <active|disabled>",
    "adm_server_status_success": "✅ #{server_id} serwer → {status}",
    "adm_add_server_usage": (
        "Usage: /add_server <name> <base_url> <api_key> [region] [weight] [max_clients]\n"
        "Example: /add_server Server-DE http://1.2.3.4 <FASTIFY_API_KEY> DE 100 200\n"
        "Protokol şol serweriň amnezia-api-si arkaly awtomatiki kesgitlenýär."
    ),
    "adm_add_server_success": "✅ #{id} «{name}» serweri goşuldy we işjeň (protokol: {protocol}).",
    "adm_add_server_protocol_unsupported": (
        "❌ Serwer talap edilýän AmneziaWG wersiýasyny goldamaýar.\n"
        "Bu serwerde AmneziaWG-ni täzeläň we ýene synanyşyň.\n{error}"
    ),
    "adm_add_server_unreachable": (
        "❌ Bu serwerdäki amnezia-api-e birikmek başartmady. "
        "Salgyny we serweriň elýeterliligini barlaň.\n{error}"
    ),
    "adm_generic_error": "❌ Ýalňyşlyk: {error}",

    # --- Trial (user-facing) ---
    "trial_granted": (
        "🎁 Size {days} günlük synag döwri berildi!\n\n"
        "Birikme açaryny almak üçin «Meniň enjamlarym» bölümini açyň."
    ),
    "trial_already_used": "Bu hasapda synag döwri eýýäm ulanyldy.",
    "trial_error": "Synag döwrüni bermek başartmady. Soňra synanyşyň ýa-da goldawa ýüz tutuň.",

    # --- Admin: trial link ---
    "adm_trial_link_message": (
        "🔗 Synag döwrüni birikdirmek üçin salgy:\n{link}\n\n"
        "Öň botu işledenler üçin hem işleýär."
    ),

    # --- Admin: broadcast ---
    "adm_broadcast_usage": (
        "Usage: ibermeli habara jogap hökmünde /broadcast ibersin "
        "(tekst, surat/wideo — islendik görnüşi).\n\n"
        "Baglanyşyk düwmeleri goşmak üçin komandadan soň her setirde bir düwme ýazyň:\n"
        "/broadcast\n"
        "Düwme teksti - https://example.com\n"
        "Ýene bir düwme - https://example.com\n\n"
        "Bir setirde birnäçe düwme « | » bilen aýrylýar:\n"
        "Düwme A - https://a.com | Düwme B - https://b.com"
    ),
    "adm_broadcast_no_reply": "Ibermeli habara jogap hökmünde bu komandany ibersin.",
    "adm_broadcast_bad_button": (
        "❌ {line_num}-nji setirdäki düwme dogry däl: «{line}»\n"
        "Format: Tekst - https://salgy"
    ),
    "adm_broadcast_confirm": "📢 Bu habar {count} ulanyja iberilsinmi?",
    "adm_broadcast_confirm_btn": "✅ Ibermek",
    "adm_broadcast_cancel_btn": "❌ Ýatyrmak",
    "adm_broadcast_cancelled": "Ibermek ýatyryldy.",
    "adm_broadcast_expired": (
        "⚠️ Bu tassyklama indi hakyky däl (mysal üçin, bot täzeden işledildi). "
        "/broadcast komandasy bilen täzeden başlaň."
    ),
    "adm_broadcast_started": "⏳ Ibermek başlady ({count} alyjy)...",
    "adm_broadcast_done": (
        "✅ Ibermek tamamlandy.\n"
        "Iberildi: {sent}\n"
        "Iberilmedi (boty petiklän ýaly): {failed}"
    ),

    # --- Manat (manual bank transfer via agent queue) ---
    "manat_unavailable": "Manat bilen töleg wagtlaýyn elýeterli däl. Başga töleg usulyny synanyşyň.",
    "manat_only_one_month": (
        "💰 Manat bilen töleg diňe <b>1 aý — 40 TMT</b> tarify üçin elýeterli.\n"
        "Bu tarif üçin başga töleg usulyny saýlaň."
    ),
    "manat_request_error": "Töleg üçin haýyş döretmek başartmady. Soňra synanyşyň.",
    "manat_no_agent_available": (
        "Häzir manat bilen tölegi kabul etjek operator ýok. "
        "Soňra synanyşyň ýa-da başga töleg usulyny saýlaň."
    ),
    "manat_awaiting_agent": (
        "💳 Töleg üçin haýyş döredildi.\n"
        "⏱ Operatoryň tassyklamasyna garaşylýar (5 minuda çenli)..."
    ),
    "manat_request_created": (
        "💳 Operator tölegi kabul etmäge taýyn.\n\n"
        "<b>{amount} TMT</b> möçberi şu belgä geçiriň:\n"
        "<code>{phone}</code>\n\n"
        "⏱ Töleg üçin: 15 minut.\n"
        "Geçirimden soň «✅ {amount} TMT geçirdim» düwmesine basyň."
    ),
    "manat_i_paid_btn": "✅ {amount} TMT geçirdim",
    "manat_i_paid_notice": (
        "Operatora habar berildi. Geçirimiň tassyklanmagyna garaşyň."
    ),
    "manat_reassigned_to_payer": (
        "⏱ Operator wagtynda jogap bermedi — haýyş başga operatora geçirildi.\n"
        "⏳ Tassyklama garaşylýar (5 minuda çenli)..."
    ),
    "manat_expired_no_agent": (
        "❌ Haýyşyňyz üçin elýeterli operator tapylmady. "
        "Soňra synanyşyň ýa-da başga töleg usulyny saýlaň."
    ),
    "manat_expired_payment_window": (
        "❌ Töleg üçin wagt (15 minut) gutardy, haýyş ýapyldy. "
        "Eger eýýäm pul geçiren bolsaňyz — goldawa ýüz tutuň."
    ),
    "manat_action_error": "Haýyşy işlemekde ýalňyşlyk. Ýene synanyşyň.",
    "manat_already_resolved": "⚠️ Bu haýyş indi size berkidilmedik ýa-da eýýäm işlenildi.",
    "manat_not_an_agent": "Bu hereket üçin ygtyýaryňyz ýok.",
    "manat_reported_by_you": (
        "📨 #{request_id} haýyşy boýunça pul gelendigini habar berdiňiz. "
        "Baş administratoryň tassyklamagyna garaşyň."
    ),
    "manat_payment_under_review": (
        "💳 Operator geçirimiň gelendigini tassyklady. Haýyş "
        "administratoryň soňky barlagyna geçirildi."
    ),
    "manat_money_not_received_notice": (
        "⏱ Operator geçirimi görmedi — haýyş başga operatora geçirildi."
    ),
    "manat_rejected_by_you": "❌ #{request_id} haýyşy siz tarapyňyzdan ret edildi (pul gelmedi).",
    "manat_declined_by_you": "#{request_id} haýyşy indiki operatora geçirildi.",
    "manat_agent_new_request": (
        "💳 <b>Täze töleg haýyşy</b>\n\n"
        "Haýyş: #{request_id}\n"
        "Kimden: {payer}\n"
        "Möçberi: {amount} TMT\n\n"
        "⏱ 5 minudyň dowamynda tölegi kabul etmäge taýynlygyňyzy tassyklaň."
    ),
    "manat_agent_ready_btn": "✅ Taýyn",
    "manat_agent_not_ready_btn": "❌ Kabul edip bilmerin",
    "manat_agent_awaiting_payment": (
        "💳 <b>Haýyş #{request_id}</b>\n\n"
        "Kimden: {payer}\n"
        "Möçberi: {amount} TMT\n"
        "Töleg edijä görkezilen belgiňiz: {phone}\n\n"
        "Töleg edijiniň geçirimi tassyklamagyna garaşylýar."
    ),
    "manat_agent_payer_paid": (
        "💳 #{request_id} haýyşy boýunça töleg edji {amount} TMT geçirendigini habar berdi.\n\n"
        "Belgiňize geleni barlaň we netijäni habar beriň. "
        "Bu tölegi tassyklamaýar — soňky karar administratoryňky."
    ),
    "manat_agent_money_received_btn": "✅ Pul geldi",
    "manat_agent_money_not_received_btn": "❌ Pul gelmedi",

    # --- Manat: main admin review queue ---
    "manat_admin_review_notice": (
        "🔔 <b>Manat tölegi barlagda</b>\n\n"
        "Haýyş: #{request_id}\n"
        "Töleg eden: {payer}\n"
        "Möçberi: {amount} TMT\n\n"
        "Operator pul gelendigini habar berdi. Tölegi tassyklaň ýa-da ret ediň."
    ),
    "manat_admin_approve_btn": "✅ Tölegi tassyklamak",
    "manat_admin_reject_btn": "❌ Tölegi ret etmek",
    "manat_admin_approved_by_you": (
        "✅ #{request_id} haýyşy tassyklandy. Abuna işjeňleşdirilýär."
    ),
    "manat_admin_rejected_by_you": "❌ #{request_id} haýyşy ret edildi.",
    "manat_admin_rejected_notice": (
        "❌ Töleg administrator tarapyndan tassyklanmady. Eger geçirimi "
        "ýerine ýetiren bolsaňyz — goldawa ýüz tutuň."
    ),

    # --- Manat agent management ---
    "agent_not_registered": "Siz manat tölegi operatory hökmünde bellige alynmansyňyz.",
    "agent_my_numbers_header": "📱 Manat kabul etmek üçin belgileriňiz:",
    "agent_phone_line": (
        "{status_icon} {phone} — 24 sagatda ulanyldy: {received}/{limit} TMT"
    ),
    "agent_limit_unlimited": "çäksiz",
    "agent_phone_enable_btn": "🟢 {phone} işjeňleşdirmek",
    "agent_phone_disable_btn": "🔴 {phone} öçürmek",
    "agent_phone_toggled": "Belginiň statusy täzelendi.",
    "admin_agent_added": "{telegram_id} operator goşuldy.",
    "admin_agent_exists": "Bu telegram_id bilen operator eýýäm bar.",
    "admin_agent_phone_added": "{phone} belgisi {telegram_id} operatoryna goşuldy.",
    "admin_agent_phone_removed": "Belgi aýryldy.",
    "admin_agent_not_found": "Operator tapylmady.",
    "admin_agent_usage": "Ulanylyşy: /add_agent <telegram_id> [ady]",
    "admin_agent_phone_usage": "Ulanylyşy: /add_agent_phone <telegram_id> <belgi>",
    "admin_agent_disabled": "{telegram_id} operatory elle öçürildi.",
    "admin_agent_enabled": "{telegram_id} operatory täzeden bellenip bilner.",
    "admin_agent_manual_toggle_usage": "Ulanylyşy: /toggle_agent <telegram_id>",
    "admin_agent_schedule_usage": (
        "Ulanylyşy: /agent_schedule <telegram_id> <günler> <başlangyç> <ahyr> [wagt zolagy]\n"
        "Günler — 1-7 sanlary vergul bilen (1=Duş..7=Ýek) ýa-da «all».\n"
        "Mysal: /agent_schedule 123456789 1,2,3,4,5 09:00 18:00\n"
        "Tertibi aýyrmak üçin: /agent_schedule 123456789 clear"
    ),
    "admin_agent_schedule_cleared": "{telegram_id} operatorynyň tertibi arassalandy — hemişe elýeterli.",
    "admin_agent_schedule_set": (
        "{telegram_id} operatorynyň tertibi täzelendi: {days}, {start}–{end} ({timezone})."
    ),
    "admin_manat_queue_empty": "Barlagda haýyş ýok.",
    "admin_manat_queue_header": "🔔 Barlagdaky manat töleg haýyşlary ({count}):",
    "admin_manat_queue_item": (
        "#{id} · {amount} TMT · {payer} · operator {agent} · döredildi {created_at}"
    ),
}
