"""
BillingService — core business logic.

This is the single source of truth for:
  - processing payments (idempotent)
  - creating / extending / disabling subscriptions
  - provisioning VPN access via amnezia-api
  - retrying failed provisioning
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from billing.database import AsyncSessionLocal
from billing.redis_lock import redis_lock, LockTimeoutError
from billing.repositories.other_repos import (
    AgentRepository,
    AuditRepository,
    ManatRequestRepository,
    OrderRepository,
    PaymentRepository,
    ProcessedEventRepository,
    VpnClientRepository,
)
from billing.repositories.server_repo import VpnServerRepository
from billing.repositories.subscription_repo import SubscriptionRepository
from billing.repositories.user_repo import UserRepository
from integrations.amnezia.client import AmneziaClient
from integrations.amnezia.errors import (
    AmneziaConnectionError,
    AmneziaError,
    AmneziaProtocolNotSupportedError,
)
from integrations.amnezia.schemas import CreateClientRequest
from models.models import (
    Agent,
    AgentPhone,
    AuditAction,
    ManatPaymentRequest,
    ManatRequestStatus,
    OrderStatus,
    PaymentProvider,
    Subscription,
    SubscriptionStatus,
    VpnClientStatus,
    VpnServer,
)

# How long an agent has to tap "Принять заявку" before the request is
# escalated to the next agent in the queue.
MANAT_AGENT_ACCEPT_WINDOW = timedelta(minutes=5)
# How long the payer has to transfer money and have the agent report
# receipt before the request expires outright (no further escalation).
# Note: the per-agent-phone daily receiving limit (ТЗ p.9) is no longer a
# module-level constant — it's AgentPhone.daily_limit_manat, a configurable
# business setting per phone (default 350, see models.models.AgentPhone).
MANAT_PAYMENT_WINDOW = timedelta(minutes=15)

logger = logging.getLogger(__name__)


class TrialAlreadyUsedError(ValueError):
    """Raised by grant_trial() when this telegram_id already has a trial
    payment on record. Subclasses ValueError so it's still caught by any
    existing `except ValueError` handling elsewhere, but lets callers that
    care (the API route) distinguish it from other ValueErrors without
    string-matching the message."""


class ManatRequestAlreadyResolvedError(ValueError):
    """Raised by approve_manat_request()/reject_manat_request() when this
    request was already resolved (approved or rejected) by another admin,
    or report_manat_payment()/accept/decline when it's no longer held by
    this agent — the expected outcome of losing a race, not a bug.
    Subclasses ValueError for the same reason as TrialAlreadyUsedError
    above."""


class ManatRequestNotAssignedToAgentError(ValueError):
    """Raised by accept_manat_request()/decline_manat_request() when the
    calling agent no longer holds this request — it was already accepted,
    declined, or re-assigned elsewhere (e.g. the 5-minute timeout sweep won
    the race). Subclasses ValueError for the same reason as the above."""


class NoAgentAvailableError(ValueError):
    """Raised by create_manat_request() when no active, on-shift agent
    currently has a usable phone (enabled and under its trailing-24h
    limit) to assign the request to. The bot must tell the payer there is
    no operator available right now and offer to retry later (ТЗ p.2) —
    never fall back to assigning a random/unavailable agent."""


class ManatPlanNotEligibleError(ValueError):
    """Raised by create_manat_request() when the requested plan is not the
    one manat payments are offered for (currently: the 1-month / 30-day
    plan only). The bot tells the payer to use another payment method for
    other plans rather than silently substituting or rejecting generically."""


class ServerUnreachableError(ValueError):
    """Raised by add_server() when the new server's amnezia-api instance
    could not be reached at all (wrong base_url, firewall, service down)
    — distinct from AmneziaProtocolNotSupportedError (reachable, but the
    required protocol isn't enabled there) so the admin gets "check the
    URL/network" rather than "upgrade AmneziaWG" for the wrong problem."""


def _as_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _extended_expiry(current_expiry: Optional[datetime], duration: timedelta) -> datetime:
    now = datetime.now(timezone.utc)
    base = _as_utc(current_expiry) if current_expiry else now
    if base < now:
        base = now
    return base + duration


class BillingService:
    """
    All methods accept an AsyncSession and are designed to be called
    from FastAPI route handlers (session-per-request) or from the worker.
    """

    # -----------------------------------------------------------------
    # Payment processing
    # -----------------------------------------------------------------

    async def _find_subscription_for_duplicate_event(
        self,
        session: AsyncSession,
        *,
        provider: PaymentProvider,
        external_id: str,
        telegram_id: int,
    ) -> Optional[Subscription]:
        """
        Look up the subscription that a duplicate payment event should
        resolve to. Shared by both duplicate-detection paths in
        handle_payment(): the cheap exists()-based shortcut and the
        IntegrityError handler that catches a genuine concurrent race.
        """
        pay_repo = PaymentRepository(session)
        payment = await pay_repo.get_by_external_id(provider, external_id)
        if payment and payment.subscription_id:
            sub_repo = SubscriptionRepository(session)
            sub = await sub_repo.get_by_id(payment.subscription_id)
            if sub:
                return sub
        # Fallback heuristic (shouldn't normally be reached)
        user_repo = UserRepository(session)
        user = await user_repo.get_by_telegram_id(telegram_id)
        if user:
            sub_repo = SubscriptionRepository(session)
            sub = await sub_repo.get_latest_for_user(user.id)
            if sub:
                return sub
        return None

    async def grant_trial(
        self,
        session: AsyncSession,
        *,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
    ) -> Subscription:
        """
        Grants the one-time free trial device. Modeled as a zero-amount
        "payment" through the exact same handle_payment() path as a real
        purchase (provider=stars, amount=0) rather than a separate
        provisioning path — this gets idempotency, provisioning, retry, and
        audit logging for free instead of a second implementation to keep in
        sync with the first.

        external_id is deterministic (f"trial:{telegram_id}") so the
        Payment(provider, external_id) unique constraint is the actual,
        DB-enforced guarantee against granting a second trial to the same
        user even under a race — the exists-check below is only there to
        fail with a clear ValueError instead of a raw IntegrityError for the
        overwhelmingly common case (a user who deliberately tries the
        trial-link twice).
        """
        external_id = f"trial:{telegram_id}"
        pay_repo = PaymentRepository(session)
        if await pay_repo.get_by_external_id(PaymentProvider.stars, external_id):
            raise TrialAlreadyUsedError("Trial already used for this account")

        plan_repo = billing_plan_repo(session)
        trial_plan = await plan_repo.get_trial_plan()
        if not trial_plan:
            # Operator error (trial plan not seeded), not a user-facing
            # situation — surfaced to the admin/logs, not swallowed.
            raise ValueError("No trial plan configured — run seeds/seed.py or insert one manually")

        return await self.handle_payment(
            session,
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            provider=PaymentProvider.stars,
            external_id=external_id,
            amount=0,
            currency="XTR",
            plan_id=trial_plan.id,
            mode="new",
        )

    async def _phone_reserved_and_confirmed_total(
        self, session: AsyncSession, phone: AgentPhone, *, now: Optional[datetime] = None
    ) -> float:
        """Trailing-24h confirmed total PLUS everything currently reserved
        (open, unresolved requests) against this phone — the full basis for
        the daily limit check (ТЗ p.9: 'Лимит должен учитывать...
        подтверждённые платежи... уже зарезервированные активные заявки').
        Combining both in one read, immediately followed by writing the new
        reservation (the ManatPaymentRequest row itself) inside the SAME
        transaction, is what makes the limit check-and-reserve atomic:
        two concurrent create_manat_request calls each re-read this sum
        inside their own transaction and neither can observe a state where
        the other's reservation is invisible yet already committed."""
        if not phone.is_enabled:
            return float("inf")  # disabled phone never has capacity; short-circuits to 0 below
        now = now or datetime.now(timezone.utc)
        agent_repo = AgentRepository(session)
        confirmed = await agent_repo.get_phone_received_since(phone.id, now - timedelta(hours=24))
        reserved = await agent_repo.get_phone_reserved_open_total(phone.id)
        return confirmed + reserved

    async def _phone_available_capacity(
        self, session: AsyncSession, phone: AgentPhone, *, now: Optional[datetime] = None
    ) -> float:
        """How many more TMT this phone can currently receive: its
        configured daily_limit_manat (ТЗ p.9 — a per-phone business
        setting, not a hardcoded constant) minus confirmed-plus-reserved
        totals over the trailing 24h. A disabled phone, or one with no
        limit configured but also no numeric limit (None means unlimited;
        0 means blocked), is handled explicitly. Unlimited phones report a
        very large capacity so they never block assignment."""
        if not phone.is_enabled:
            return 0.0
        limit = phone.daily_limit_manat
        if limit is None:
            return float("inf")
        limit = float(limit)
        used = await self._phone_reserved_and_confirmed_total(session, phone, now=now)
        return max(0.0, limit - used)

    @staticmethod
    def _agent_is_on_shift(agent: Agent, *, now_utc: Optional[datetime] = None) -> bool:
        """
        ТЗ p.2/p.10: an agent may only be assigned NEW requests while
        inside their configured work schedule, converted to their own
        timezone (default Asia/Ashgabat). An agent with no schedule
        configured at all (work_days, work_start_time, work_end_time all
        None) is treated as always available, so existing/simple
        deployments that don't need shifts keep working unchanged.
        Supports a shift that crosses midnight (e.g. 18:00-23:00 is a
        same-day shift; 22:00-02:00 would cross midnight and is also
        handled). manually_disabled and is_active are NOT checked here —
        those are checked by the caller (get_active_candidates already
        filters is_active/manually_disabled; this method is only about the
        time-of-day/day-of-week part of availability).
        """
        import zoneinfo

        if not agent.work_start_time and not agent.work_end_time and not agent.work_days:
            return True

        now_utc = now_utc or datetime.now(timezone.utc)
        try:
            tz = zoneinfo.ZoneInfo(agent.timezone or "Asia/Ashgabat")
        except Exception:
            tz = zoneinfo.ZoneInfo("Asia/Ashgabat")
        local_now = now_utc.astimezone(tz)

        if agent.work_days:
            allowed_days = {
                int(d) for d in agent.work_days.split(",") if d.strip().isdigit()
            }
            # ISO weekday: Monday=1 .. Sunday=7
            if allowed_days and local_now.isoweekday() not in allowed_days:
                return False

        if not agent.work_start_time or not agent.work_end_time:
            return True

        try:
            start_h, start_m = (int(x) for x in agent.work_start_time.split(":"))
            end_h, end_m = (int(x) for x in agent.work_end_time.split(":"))
        except (ValueError, AttributeError):
            return True  # malformed schedule fails open rather than hiding the agent entirely

        start_minutes = start_h * 60 + start_m
        end_minutes = end_h * 60 + end_m
        now_minutes = local_now.hour * 60 + local_now.minute

        if start_minutes == end_minutes:
            return True  # 00:00-00:00 style "all day" configuration
        if start_minutes < end_minutes:
            return start_minutes <= now_minutes < end_minutes
        # Shift crosses midnight, e.g. 22:00 -> 02:00
        return now_minutes >= start_minutes or now_minutes < end_minutes

    async def _pick_agent_and_phone(
        self, session: AsyncSession, *, amount: float, exclude_agent_id: Optional[int] = None
    ) -> Optional[tuple[Agent, AgentPhone]]:
        """
        Round-robin candidate selection for a new or re-assigned manat
        request. Walks agents that are active, not manually disabled, AND
        currently inside their work schedule (see _agent_is_on_shift),
        ordered by least-recently-assigned (see
        AgentRepository.get_active_candidates). For each candidate, picks
        their first enabled phone with enough remaining
        confirmed-plus-reserved capacity for `amount` (see
        _phone_available_capacity). An agent who is off-shift, or has no
        such phone, is skipped entirely rather than assigned with nothing
        to show the payer. Returns None if no agent/phone combination is
        currently usable — the caller (create_manat_request /
        decline_manat_request / sweep_manat_timeouts) is responsible for
        telling the payer "no operator available right now, try again
        later" (ТЗ p.2) rather than assigning to a random agent.
        """
        agent_repo = AgentRepository(session)
        candidates = await agent_repo.get_active_candidates(exclude_agent_id=exclude_agent_id)
        now = datetime.now(timezone.utc)
        for agent in candidates:
            if not self._agent_is_on_shift(agent, now_utc=now):
                continue
            phones = await agent_repo.get_phones_for_agent(agent.id)
            for phone in phones:
                capacity = await self._phone_available_capacity(session, phone, now=now)
                if capacity >= amount:
                    return agent, phone
        return None

    async def create_manat_request(
        self,
        session: AsyncSession,
        *,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        plan_id: int,
        mode: str = "new",
        target_subscription_id: Optional[int] = None,
    ) -> ManatPaymentRequest:
        """
        Creates a manat payment request and immediately assigns it to the
        next available agent (round-robin, on-shift, under their phone's
        limit — see _pick_agent_and_phone). Deliberately does NOT touch
        Payment/Order/Subscription — those only get created once the MAIN
        ADMIN approves (see approve_manat_request); no agent action can
        ever trigger that (ТЗ p.6/p.14). Raises ManatPlanNotEligibleError
        if the plan isn't the 30-day plan manat payments are restricted
        to, and NoAgentAvailableError if no agent currently has capacity —
        both are checked before any row is written, so a request that
        can't be fulfilled is never created in the first place. The caller
        (bot handler) must show the payer only the assigned agent's phone
        number — never a list of agents (ТЗ p.1).
        """
        user_repo = UserRepository(session)
        user, _ = await user_repo.get_or_create(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
        )

        plan_repo = billing_plan_repo(session)
        plan = await plan_repo.get_by_id(plan_id)
        if not plan:
            raise ValueError("Plan not found")
        if plan.duration_days != 30:
            raise ManatPlanNotEligibleError(
                "Manat payment is only available for the 1-month plan"
            )

        if mode == "renew":
            if not target_subscription_id:
                raise ValueError("target_subscription_id is required when mode='renew'")
            sub_repo = SubscriptionRepository(session)
            target_sub = await sub_repo.get_by_id(target_subscription_id)
            if not target_sub or target_sub.user_id != user.id:
                raise ValueError("Subscription to renew not found or does not belong to this user")

        amount = float(plan.price_manat)
        picked = await self._pick_agent_and_phone(session, amount=amount)
        if not picked:
            raise NoAgentAvailableError("No agent is currently available to accept this payment")
        agent, phone = picked

        req_repo = ManatRequestRepository(session)
        request = await req_repo.create(
            user_id=user.id,
            plan_id=plan.id,
            mode=mode,
            amount_manat=amount,
            agent_phone_shown=phone.phone_number,
            assigned_agent_id=agent.id,
            assigned_phone_id=phone.id,
            target_subscription_id=target_subscription_id,
        )
        # create() already sets status=awaiting_agent; move straight to
        # `assigned` since an agent was found synchronously above (ТЗ p.3
        # state machine has an awaiting_agent -> assigned step even when
        # assignment is immediate).
        await req_repo.try_set_status(request.id, ManatRequestStatus.awaiting_agent, ManatRequestStatus.assigned)
        request.status = ManatRequestStatus.assigned

        agent_repo = AgentRepository(session)
        await agent_repo.mark_assigned(agent.id)

        return request

    async def accept_manat_request(
        self, session: AsyncSession, *, request_id: int, agent_id: int
    ) -> ManatPaymentRequest:
        """
        Called when the currently-assigned agent taps "Принять заявку"
        within the 5-minute acceptance window. Moves the request to
        awaiting_payment, starting the 15-minute payment-window clock. If
        this agent no longer holds the request (already timed out and
        re-assigned, or already declined by this same agent), raises
        ManatRequestNotAssignedToAgentError.
        """
        agent_repo = AgentRepository(session)
        agent = await agent_repo.get_by_telegram_id(agent_id)
        if not agent:
            raise ValueError("Not a registered agent")

        req_repo = ManatRequestRepository(session)
        request = await req_repo.get_by_id(request_id)
        if not request:
            raise ValueError("Manat request not found")

        won = await req_repo.try_accept(request_id, agent.id)
        if not won:
            raise ManatRequestNotAssignedToAgentError(
                "This request is no longer assigned to you"
            )
        return request

    async def decline_manat_request(
        self, session: AsyncSession, *, request_id: int, agent_id: int
    ) -> None:
        """
        Called when the currently-assigned agent taps "Не могу принять"
        within the 5-minute window — immediately re-assigns to the next
        agent in the queue rather than waiting out the rest of the
        timeout, so a prompt decline doesn't cost the payer the unused
        portion of that window. Notifying the payer of the hand-off and
        notifying the next agent are the caller's (API route's / bot
        handler's) responsibility, same division as create_manat_request.
        """
        agent_repo = AgentRepository(session)
        agent = await agent_repo.get_by_telegram_id(agent_id)
        if not agent:
            raise ValueError("Not a registered agent")

        req_repo = ManatRequestRepository(session)
        request = await req_repo.get_by_id(request_id)
        if not request:
            raise ValueError("Manat request not found")

        won = await req_repo.try_decline(request_id, agent.id)
        if not won:
            raise ManatRequestNotAssignedToAgentError(
                "This request is no longer assigned to you"
            )

        picked = await self._pick_agent_and_phone(session, amount=float(request.amount_manat), exclude_agent_id=agent.id)
        if not picked:
            await req_repo.try_expire(request_id, ManatRequestStatus.awaiting_agent)
            return
        next_agent, next_phone = picked
        await req_repo.reassign(request_id, next_agent.id, next_phone.id, next_phone.phone_number)
        await agent_repo.mark_assigned(next_agent.id)

    async def report_manat_payment(
        self, session: AsyncSession, *, request_id: int, agent_id: int, received: bool
    ) -> ManatPaymentRequest:
        """
        Called when the assigned agent taps "Деньги получены" / "Деньги не
        получены" after the payer claims to have transferred funds. THIS
        IS ONLY A CLAIM (ТЗ p.5/p.7 "agent says: money received" ≠
        confirmed). It NEVER creates a Payment, Order, Subscription, or
        triggers VPN provisioning — it only moves the request into the
        main admin's review queue (received=True: awaiting_payment ->
        admin_review) or hands it back to the next agent (received=False:
        same re-queue as decline_manat_request). Only the agent currently
        holding this request (in awaiting_payment) can report on it — see
        ManatRequestRepository.try_report_payment for the race guard
        against the 15-minute payment-window timeout sweep. An audit entry
        is written either way so the admin queue shows who reported what,
        when (ТЗ p.6 'история действий агента').
        """
        req_repo = ManatRequestRepository(session)
        request = await req_repo.get_by_id(request_id)
        if not request:
            raise ValueError("Manat request not found")

        agent_repo = AgentRepository(session)
        agent = await agent_repo.get_by_telegram_id(agent_id)
        if not agent:
            raise ValueError("Not a registered agent")

        won = await req_repo.try_report_payment(request_id, agent.id, received)
        if not won:
            raise ManatRequestAlreadyResolvedError(
                "This request is no longer assigned to you or was already resolved"
            )

        if received:
            audit_repo = AuditRepository(session)
            await audit_repo.log(
                action=AuditAction.manat_agent_reported_payment,
                user_id=request.user_id,
                entity_type="manat_payment_request",
                entity_id=request.id,
                details=json.dumps({
                    "agent_id": agent.id,
                    "agent_telegram_id": agent.telegram_id,
                    "amount_manat": float(request.amount_manat),
                    "plan_id": request.plan_id,
                }),
            )
        else:
            # Re-queue to next agent, mirroring decline_manat_request.
            picked = await self._pick_agent_and_phone(
                session, amount=float(request.amount_manat), exclude_agent_id=agent.id
            )
            if not picked:
                await req_repo.try_expire(request_id, ManatRequestStatus.awaiting_agent)
            else:
                next_agent, next_phone = picked
                await req_repo.reassign(request_id, next_agent.id, next_phone.id, next_phone.phone_number)
                await agent_repo.mark_assigned(next_agent.id)

        return request

    async def approve_manat_request(
        self, session: AsyncSession, *, request_id: int, admin_telegram_id: int
    ) -> Subscription:
        """
        THE ONLY path that turns a reported manat payment into an active
        subscription (ТЗ p.6/p.14 — 'Ни один пользовательский или
        агентский callback не должен напрямую создавать активную
        подписку'). Only callable while the request is in admin_review;
        ManatRequestRepository.try_admin_resolve's atomic conditional
        UPDATE makes a double-approve (two admins, or one admin
        double-tapping) a no-op for the loser rather than a double
        provisioning (ТЗ p.8/p.13). Records the amount against the
        reporting agent's phone for the trailing-24h limit, writes an
        audit log entry (who/when/which request/amount/plan — ТЗ p.7),
        then reuses handle_payment() exactly as the CryptoPay webhook path
        does, so idempotency, provisioning, and further audit logging are
        shared with every other payment provider rather than
        re-implemented here.
        """
        req_repo = ManatRequestRepository(session)
        request = await req_repo.get_by_id(request_id)
        if not request:
            raise ValueError("Manat request not found")

        won = await req_repo.try_admin_resolve(request_id, admin_telegram_id, approve=True)
        if not won:
            raise ManatRequestAlreadyResolvedError(
                "This request is no longer awaiting admin review — it was already resolved"
            )

        if request.assigned_phone_id:
            agent_repo = AgentRepository(session)
            await agent_repo.record_transaction(
                agent_phone_id=request.assigned_phone_id,
                manat_request_id=request.id,
                amount_manat=float(request.amount_manat),
            )

        audit_repo = AuditRepository(session)
        await audit_repo.log(
            action=AuditAction.manat_admin_approved,
            user_id=request.user_id,
            entity_type="manat_payment_request",
            entity_id=request.id,
            details=json.dumps({
                "admin_telegram_id": admin_telegram_id,
                "amount_manat": float(request.amount_manat),
                "plan_id": request.plan_id,
                "agent_id": request.assigned_agent_id,
            }),
        )

        user_repo = UserRepository(session)
        user = await user_repo.get_by_id(request.user_id)

        await req_repo.try_set_status(request.id, ManatRequestStatus.approved, ManatRequestStatus.provisioning)

        try:
            # external_id is deterministic per request, so a duplicate
            # approve_manat_request call for the same request_id (e.g. a
            # retried API/bot request, or the loser of the try_admin_resolve
            # race somehow still calling through) is caught by
            # handle_payment()'s own Payment(provider, external_id)
            # uniqueness rather than double-provisioning.
            sub = await self.handle_payment(
                session,
                telegram_id=user.telegram_id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                provider=PaymentProvider.manat,
                external_id=f"manat_request:{request.id}",
                amount=float(request.amount_manat),
                currency="TMT",
                plan_id=request.plan_id,
                mode=request.mode,
                target_subscription_id=request.target_subscription_id,
            )
        except Exception:
            await req_repo.try_set_status(
                request.id, ManatRequestStatus.provisioning, ManatRequestStatus.provisioning_failed
            )
            raise

        await req_repo.try_set_status(request.id, ManatRequestStatus.provisioning, ManatRequestStatus.completed)

        payment_repo = PaymentRepository(session)
        payment = await payment_repo.get_by_external_id(
            PaymentProvider.manat, f"manat_request:{request.id}"
        )
        if payment:
            await req_repo.link_payment(request, payment.id)

        return sub

    async def reject_manat_request(
        self,
        session: AsyncSession,
        *,
        request_id: int,
        admin_telegram_id: int,
        reason: Optional[str] = None,
    ) -> None:
        """
        Called when the main admin taps "Отклонить оплату" on a reported
        payment — no transfer actually seen, wrong amount, suspected fraud,
        etc. Same atomic race protection as approve_manat_request; only
        succeeds while the request is still admin_review. Writes an audit
        log entry same as approval, for symmetry and traceability (ТЗ p.7).
        """
        req_repo = ManatRequestRepository(session)
        request = await req_repo.get_by_id(request_id)
        if not request:
            raise ValueError("Manat request not found")

        won = await req_repo.try_admin_resolve(
            request_id, admin_telegram_id, approve=False, reason=reason
        )
        if not won:
            raise ManatRequestAlreadyResolvedError(
                "This request is no longer awaiting admin review — it was already resolved"
            )

        audit_repo = AuditRepository(session)
        await audit_repo.log(
            action=AuditAction.manat_admin_rejected,
            user_id=request.user_id,
            entity_type="manat_payment_request",
            entity_id=request.id,
            details=json.dumps({
                "admin_telegram_id": admin_telegram_id,
                "amount_manat": float(request.amount_manat),
                "plan_id": request.plan_id,
                "agent_id": request.assigned_agent_id,
                "reason": reason,
            }),
        )

    async def sweep_manat_timeouts(self, session: AsyncSession) -> list[dict]:
        """
        Called periodically by the worker (see billing/workers/scheduler.py)
        to enforce both timeout windows:
          - `assigned` requests whose 5-minute acceptance window has
            elapsed are re-assigned to the next available agent (clock
            resets), or expired outright if no agent is currently usable.
          - awaiting_payment requests whose 15-minute payment window has
            elapsed are expired unconditionally — the payer, not an agent,
            missed the window, so there is no one else to hand off to.
        payment_reported/admin_review requests are NOT touched here — once
        an agent has reported receipt, the request waits on the main admin,
        not on a timer (ТЗ has no auto-expiry for admin review).

        Returns a list of event dicts describing what happened to each
        affected request, since the worker needs the payer/agent telegram
        IDs to notify them — this method only touches the DB and has no
        bot instance to send messages with. Each event is one of:
          {"type": "reassigned", "request_id", "payer_telegram_id",
           "new_agent_telegram_id", "phone_number", "amount_manat"}
          {"type": "expired_no_agent", "request_id", "payer_telegram_id"}
          {"type": "expired_payment_window", "request_id",
           "payer_telegram_id", "agent_telegram_id"}
        """
        now = datetime.now(timezone.utc)
        req_repo = ManatRequestRepository(session)
        agent_repo = AgentRepository(session)
        user_repo = UserRepository(session)

        events: list[dict] = []

        stale_agent_wait = await req_repo.get_stale_awaiting_agent(now - MANAT_AGENT_ACCEPT_WINDOW)
        for request in stale_agent_wait:
            payer = await user_repo.get_by_id(request.user_id)
            payer_telegram_id = payer.telegram_id if payer else None

            picked = await self._pick_agent_and_phone(
                session,
                amount=float(request.amount_manat),
                exclude_agent_id=request.assigned_agent_id,
            )
            if not picked:
                if await req_repo.try_expire(request.id, ManatRequestStatus.assigned):
                    events.append({
                        "type": "expired_no_agent",
                        "request_id": request.id,
                        "payer_telegram_id": payer_telegram_id,
                    })
                continue
            next_agent, next_phone = picked
            await req_repo.reassign(request.id, next_agent.id, next_phone.id, next_phone.phone_number)
            await agent_repo.mark_assigned(next_agent.id)
            events.append({
                "type": "reassigned",
                "request_id": request.id,
                "payer_telegram_id": payer_telegram_id,
                "new_agent_telegram_id": next_agent.telegram_id,
                "phone_number": next_phone.phone_number,
                "amount_manat": float(request.amount_manat),
            })

        stale_payment_wait = await req_repo.get_stale_awaiting_payment(now - MANAT_PAYMENT_WINDOW)
        for request in stale_payment_wait:
            payer = await user_repo.get_by_id(request.user_id)
            payer_telegram_id = payer.telegram_id if payer else None
            agent = (
                await agent_repo.get_by_id(request.assigned_agent_id)
                if request.assigned_agent_id
                else None
            )
            if await req_repo.try_expire(request.id, ManatRequestStatus.awaiting_payment):
                events.append({
                    "type": "expired_payment_window",
                    "request_id": request.id,
                    "payer_telegram_id": payer_telegram_id,
                    "agent_telegram_id": agent.telegram_id if agent else None,
                })

        return events

    async def sweep_manat_timeouts_job(self) -> list[dict]:
        """Worker-facing wrapper around sweep_manat_timeouts() that opens
        and commits its own session, matching the pattern of
        disable_expired_subscriptions()/retry_pending_provisioning() above
        — the scheduler calls this directly rather than sweep_manat_timeouts
        itself, which expects a caller-provided session (used that way by
        tests and by anything already inside a request-scoped session)."""
        async with AsyncSessionLocal() as session:
            events = await self.sweep_manat_timeouts(session)
            await session.commit()
            return events

    async def handle_payment(
        self,
        session: AsyncSession,
        *,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        provider: PaymentProvider,
        external_id: str,    # unique payment ID from provider
        amount: float,
        currency: str,
        plan_id: Optional[int] = None,
        mode: str = "new",   # "new" = always provision a brand-new device;
                             # "renew" = extend one specific existing device
        target_subscription_id: Optional[int] = None,  # required if mode="renew"
    ) -> Subscription:
        """
        Idempotent payment handler.
        - Creates user if not exists.
        - Creates order + payment if not already processed.
        - Marks payment as paid.
        - mode="new" (default): ALWAYS provisions a brand-new VPN device/subscription.
          One payment = one device, hard rule — even if the user already has other
          active devices on the same Telegram account, this never extends them.
        - mode="renew": extends the expiry of one specific existing subscription
          (target_subscription_id), which must belong to this user. Use this for
          "renew my existing device" rather than "buy me a new one".
        Returns the resulting Subscription.
        """
        evt_repo = ProcessedEventRepository(session)
        event_key = f"{provider.value}:{external_id}"

        # --- Idempotency check (fast path) ---
        # This exists() check is a TOCTOU race by itself — two near-simultaneous
        # retries of the same webhook can both see False here before either one
        # commits. It's kept only as a cheap shortcut to skip the work below on
        # the common case (a real retry, arriving after the first one already
        # completed). The actual guarantee against double-processing is the DB
        # unique constraint on ProcessedEvent.event_id / Payment(provider,
        # external_id), enforced below via the IntegrityError handler.
        if await evt_repo.exists(event_key):
            logger.info("Duplicate event %s ignored", event_key)
            existing = await self._find_subscription_for_duplicate_event(
                session, provider=provider, external_id=external_id, telegram_id=telegram_id
            )
            if existing:
                return existing
            raise ValueError("Duplicate event but no subscription found — investigate")

        # --- Ensure user exists ---
        user_repo = UserRepository(session)
        user, _ = await user_repo.get_or_create(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
        )

        # --- Resolve plan ---
        plan_repo = billing_plan_repo(session)
        plan = await plan_repo.get_by_id(plan_id) if plan_id else await plan_repo.get_active_plan()
        if not plan:
            raise ValueError("No active plan found")

        # --- Validate renew target BEFORE recording the payment ---
        sub_repo = SubscriptionRepository(session)
        target_sub: Optional[Subscription] = None
        if mode == "renew":
            if not target_subscription_id:
                raise ValueError("target_subscription_id is required when mode='renew'")
            target_sub = await sub_repo.get_by_id(target_subscription_id)
            if not target_sub or target_sub.user_id != user.id:
                raise ValueError("Subscription to renew not found or does not belong to this user")

        # --- Create order + payment + idempotency marker, atomically ---
        # These three inserts are wrapped in one SAVEPOINT so a concurrent
        # duplicate (another retry of the same webhook, racing past the
        # exists() shortcut above) is caught by the DB unique constraints
        # (ProcessedEvent.event_id, Payment(provider, external_id)) instead
        # of silently double-provisioning. On conflict we roll back just this
        # savepoint and fall through to the same "return the existing
        # subscription" path used by the fast-path duplicate check.
        order_repo = OrderRepository(session)
        pay_repo = PaymentRepository(session)
        try:
            async with session.begin_nested():
                order = await order_repo.create(user_id=user.id, plan_id=plan.id)
                payment = await pay_repo.create(
                    user_id=user.id,
                    order_id=order.id,
                    provider=provider,
                    external_id=external_id,
                    amount=amount,
                    currency=currency,
                )
                await pay_repo.mark_paid(payment)
                order.status = OrderStatus.completed
                await evt_repo.mark(event_key)
        except IntegrityError:
            logger.info("Concurrent duplicate event %s caught at insert time", event_key)
            existing = await self._find_subscription_for_duplicate_event(
                session, provider=provider, external_id=external_id, telegram_id=telegram_id
            )
            if existing:
                return existing
            raise ValueError("Duplicate event (race) but no subscription found — investigate")

        audit = AuditRepository(session)
        await audit.log(
            AuditAction.payment_received,
            user_id=user.id,
            entity_type="payment",
            entity_id=payment.id,
            details=json.dumps({"provider": provider.value, "external_id": external_id, "mode": mode}),
        )

        # --- Create a brand-new device, or renew one specific existing device ---
        if mode == "renew":
            sub = await self._renew_subscription(session, target_sub, plan)
        else:
            sub = await self._create_new_subscription(session, user_id=user.id, plan=plan)

        await pay_repo.link_subscription(payment, sub.id)
        await session.flush()

        # --- Provision VPN (may fail; worker will retry) ---
        await self._provision_subscription(session, sub)

        return sub

    # -----------------------------------------------------------------
    # Subscription lifecycle
    # -----------------------------------------------------------------

    async def _create_new_subscription(
        self,
        session: AsyncSession,
        *,
        user_id: int,
        plan,
    ) -> Subscription:
        """Always creates a brand-new subscription — i.e. a new device slot.
        Never looks at or touches any existing subscription for this user."""
        sub_repo = SubscriptionRepository(session)
        audit = AuditRepository(session)

        now = datetime.now(timezone.utc)
        duration = timedelta(days=plan.duration_days)

        sub = await sub_repo.create(
            user_id=user_id,
            plan_id=plan.id,
            status=SubscriptionStatus.pending_provisioning,
            starts_at=now,
            expires_at=now + duration,
        )
        await audit.log(
            AuditAction.subscription_created,
            user_id=user_id,
            entity_type="subscription",
            entity_id=sub.id,
        )
        return sub

    async def _renew_subscription(
        self,
        session: AsyncSession,
        existing: Subscription,
        plan,
    ) -> Subscription:
        """Extends one specific, already-identified subscription. Same device, same key."""
        audit = AuditRepository(session)

        now = datetime.now(timezone.utc)
        duration = timedelta(days=plan.duration_days)

        existing.expires_at = _extended_expiry(existing.expires_at, duration)
        existing.last_extended_at = now
        if existing.status in (
            SubscriptionStatus.disabled,
            SubscriptionStatus.error,
            SubscriptionStatus.expired,
        ):
            existing.status = SubscriptionStatus.pending_provisioning
        await audit.log(
            AuditAction.subscription_renewed,
            user_id=existing.user_id,
            entity_type="subscription",
            entity_id=existing.id,
        )
        return existing

    async def _provision_subscription(
        self,
        session: AsyncSession,
        sub: Subscription,
    ) -> None:
        """
        Create or re-enable a VPN client for this subscription.
        On any error, set status=pending_provisioning so worker retries.
        """
        vc_repo = VpnClientRepository(session)
        server_repo = VpnServerRepository(session)
        audit = AuditRepository(session)
        sub_repo = SubscriptionRepository(session)

        # Already has an active VPN client? Just ensure it's enabled.
        existing_vc = await vc_repo.get_by_subscription(sub.id)
        if existing_vc and existing_vc.status != VpnClientStatus.deleted:
            server = await server_repo.get_by_id(existing_vc.server_id)
            if server:
                amnezia = AmneziaClient(base_url=server.base_url, api_key=server.api_key)
                try:
                    async with redis_lock(f"vpn-server:{server.id}"):
                        await amnezia.enable_client(
                            existing_vc.amnezia_client_id, protocol=existing_vc.protocol
                        )
                    existing_vc.status = VpnClientStatus.active
                    sub.status = SubscriptionStatus.active
                    sub.last_provisioned_at = datetime.now(timezone.utc)
                    await audit.log(
                        AuditAction.vpn_client_enabled,
                        entity_type="vpn_client",
                        entity_id=existing_vc.id,
                    )
                    return
                except (AmneziaError, LockTimeoutError) as e:
                    logger.warning("Enable client failed: %s", e)
                    sub.status = SubscriptionStatus.pending_provisioning
                    # Must increment retry_count here too, or a subscription
                    # stuck on this branch never reaches the >=5 threshold in
                    # retry_pending_provisioning() and retries forever instead
                    # of escalating to `error`.
                    sub.retry_count = (sub.retry_count or 0) + 1
                    await audit.log(
                        AuditAction.provisioning_failed,
                        user_id=sub.user_id,
                        entity_type="subscription",
                        entity_id=sub.id,
                        details=str(e),
                    )
                    return

        # Select a VPN server
        server = await server_repo.select_server()
        if not server:
            logger.error("No available VPN servers for provisioning sub %d", sub.id)
            sub.status = SubscriptionStatus.error
            await audit.log(
                AuditAction.provisioning_failed,
                user_id=sub.user_id,
                entity_type="subscription",
                entity_id=sub.id,
                details="No available servers",
            )
            return

        sub.server_id = server.id
        client_name = f"tg_{sub.user_id}_{sub.id}"
        amnezia = AmneziaClient(base_url=server.base_url, api_key=server.api_key)

        try:
            req = CreateClientRequest(
                clientName=client_name,
                protocol=server.protocol,
                expiresAt=None,  # We manage expiry ourselves
            )
            async with redis_lock(f"vpn-server:{server.id}"):
                resp = await amnezia.create_client(req)
        except (AmneziaError, LockTimeoutError) as e:
            logger.warning("Create client failed for sub %d: %s", sub.id, e)
            sub.status = SubscriptionStatus.pending_provisioning
            sub.retry_count = (sub.retry_count or 0) + 1
            await audit.log(
                AuditAction.provisioning_failed,
                user_id=sub.user_id,
                entity_type="subscription",
                entity_id=sub.id,
                details=str(e),
            )
            return

        # Persist VPN client record. If a row for this subscription already
        # exists (e.g. marked `deleted` by a prior failed reissue attempt —
        # see admin_reissue_device), update it in place rather than
        # inserting a second row: subscription_id is unique, so a blind
        # create() here would raise IntegrityError against that stale row.
        if existing_vc:
            existing_vc.server_id = server.id
            existing_vc.amnezia_client_id = resp.client.id
            existing_vc.client_name = client_name
            existing_vc.config_url = resp.client.config
            existing_vc.protocol = resp.client.protocol
            existing_vc.status = VpnClientStatus.active
            vc = existing_vc
        else:
            vc = await vc_repo.create(
                subscription_id=sub.id,
                server_id=server.id,
                amnezia_client_id=resp.client.id,
                client_name=client_name,
                config_url=resp.client.config,
                protocol=resp.client.protocol,
            )
        await server_repo.increment_clients(server.id)

        sub.status = SubscriptionStatus.active
        sub.last_provisioned_at = datetime.now(timezone.utc)
        await audit.log(
            AuditAction.vpn_client_created,
            user_id=sub.user_id,
            entity_type="vpn_client",
            entity_id=vc.id,
        )
        logger.info("Provisioned VPN client %s for sub %d", resp.client.id, sub.id)

    # -----------------------------------------------------------------
    # Expiry / disable
    # -----------------------------------------------------------------

    async def disable_expired_subscriptions(self) -> int:
        """Worker task: disable all expired active subscriptions."""
        count = 0
        async with AsyncSessionLocal() as session:
            sub_repo = SubscriptionRepository(session)
            vc_repo = VpnClientRepository(session)
            server_repo = VpnServerRepository(session)
            audit = AuditRepository(session)

            now = datetime.now(timezone.utc)
            expired = await sub_repo.get_expiring_before(now)

            for sub in expired:
                vc = await vc_repo.get_by_subscription(sub.id)
                if vc and vc.status == VpnClientStatus.active:
                    server = await server_repo.get_by_id(vc.server_id)
                    if server:
                        amnezia = AmneziaClient(
                            base_url=server.base_url, api_key=server.api_key
                        )
                        try:
                            async with redis_lock(f"vpn-server:{server.id}"):
                                await amnezia.disable_client(vc.amnezia_client_id, vc.protocol)
                            vc.status = VpnClientStatus.disabled
                            await server_repo.decrement_clients(server.id)
                        except (AmneziaError, LockTimeoutError) as e:
                            logger.warning("Disable client %s failed: %s", vc.amnezia_client_id, e)

                sub.status = SubscriptionStatus.expired
                await audit.log(
                    AuditAction.subscription_expired,
                    user_id=sub.user_id,
                    entity_type="subscription",
                    entity_id=sub.id,
                )
                count += 1

            await session.commit()
        return count

    async def retry_pending_provisioning(self) -> int:
        """Worker task: retry provisioning for subscriptions stuck in pending_provisioning."""
        count = 0
        async with AsyncSessionLocal() as session:
            sub_repo = SubscriptionRepository(session)
            audit = AuditRepository(session)
            pending = await sub_repo.get_pending_provisioning()
            for sub in pending:
                if (sub.retry_count or 0) >= 5:
                    sub.status = SubscriptionStatus.error
                    continue
                await self._provision_subscription(session, sub)
                await audit.log(
                    AuditAction.provisioning_retried,
                    user_id=sub.user_id,
                    entity_type="subscription",
                    entity_id=sub.id,
                )
                count += 1
            await session.commit()
        return count

    # -----------------------------------------------------------------
    # Admin actions
    # -----------------------------------------------------------------

    async def admin_disable_subscription(self, session: AsyncSession, sub_id: int) -> None:
        sub_repo = SubscriptionRepository(session)
        vc_repo = VpnClientRepository(session)
        server_repo = VpnServerRepository(session)
        audit = AuditRepository(session)

        sub = await sub_repo.get_by_id(sub_id)
        if not sub:
            raise ValueError("Subscription not found")

        vc = await vc_repo.get_by_subscription(sub.id)
        if vc and vc.status == VpnClientStatus.active:
            server = await server_repo.get_by_id(vc.server_id)
            if server:
                amnezia = AmneziaClient(base_url=server.base_url, api_key=server.api_key)
                async with redis_lock(f"vpn-server:{server.id}"):
                    await amnezia.disable_client(vc.amnezia_client_id, vc.protocol)
                vc.status = VpnClientStatus.disabled
                await server_repo.decrement_clients(server.id)

        sub.status = SubscriptionStatus.disabled
        await audit.log(
            AuditAction.subscription_disabled,
            entity_type="subscription",
            entity_id=sub.id,
        )

    async def admin_extend_subscription(
        self, session: AsyncSession, sub_id: int, days: int
    ) -> None:
        sub_repo = SubscriptionRepository(session)
        audit = AuditRepository(session)

        sub = await sub_repo.get_by_id(sub_id)
        if not sub:
            raise ValueError("Subscription not found")

        sub.expires_at = _extended_expiry(sub.expires_at, timedelta(days=days))
        sub.last_extended_at = datetime.now(timezone.utc)

        if sub.status == SubscriptionStatus.expired:
            sub.status = SubscriptionStatus.pending_provisioning

        await audit.log(
            AuditAction.subscription_renewed,
            entity_type="subscription",
            entity_id=sub.id,
            details=json.dumps({"days": days}),
        )

    async def admin_reissue_device(self, session: AsyncSession, sub_id: int) -> str:
        """
        (Re-)provision a device's VPN client, covering two distinct failure
        modes with one command:

        1. A VpnClient row exists but is broken — e.g. amnezia-api returned
           a config that was never applied to the VPN server's WireGuard
           interface (see billing/redis_lock.py for why that could happen).
           We best-effort delete the old client on its VPN server (it may
           already be gone there, which is fine — that's exactly the broken
           state this command exists to fix), then update the row in place
           (subscription_id is unique, so we never insert a second row for
           the same subscription).

        2. No VpnClient row exists at all — provisioning failed before a
           client was ever created (e.g. no VPN server was configured yet
           at purchase time, which leaves the Subscription in `error` status
           with nothing under it). In this case we create a fresh VpnClient
           row via the repository instead of trying to update a row that
           was never there.

        Returns the new config_url.
        """
        sub_repo = SubscriptionRepository(session)
        vc_repo = VpnClientRepository(session)
        server_repo = VpnServerRepository(session)
        audit = AuditRepository(session)

        sub = await sub_repo.get_by_id(sub_id)
        if not sub:
            raise ValueError("Subscription not found")

        vc = await vc_repo.get_by_subscription(sub.id)

        old_server = await server_repo.get_by_id(vc.server_id) if vc else None
        if vc and old_server:
            amnezia = AmneziaClient(base_url=old_server.base_url, api_key=old_server.api_key)
            try:
                async with redis_lock(f"vpn-server:{old_server.id}"):
                    await amnezia.delete_client(vc.amnezia_client_id, vc.protocol)
            except (AmneziaError, LockTimeoutError) as e:
                # Expected in the exact scenario this command fixes: the
                # server never had this peer in the first place.
                logger.info(
                    "Best-effort delete of old client %s failed (continuing): %s",
                    vc.amnezia_client_id,
                    e,
                )
            # The old client is being removed from old_server here,
            # unconditionally, regardless of what happens with the new
            # server below (including create_client failing and this whole
            # function re-raising). Decrementing now — rather than later,
            # only on the overall success path — keeps current_clients
            # accurate even when reissue fails partway through: otherwise
            # old_server's count stays permanently inflated by one for a
            # client that no longer exists there.
            await server_repo.decrement_clients(old_server.id)

        server = await server_repo.select_server()
        if not server:
            raise ValueError("No available VPN servers to provision onto")

        client_name = f"tg_{sub.user_id}_{sub.id}"
        amnezia = AmneziaClient(base_url=server.base_url, api_key=server.api_key)
        req = CreateClientRequest(clientName=client_name, protocol=server.protocol, expiresAt=None)
        try:
            async with redis_lock(f"vpn-server:{server.id}"):
                resp = await amnezia.create_client(req)
        except (AmneziaError, LockTimeoutError) as e:
            logger.error("Reissue failed to create client on server %d: %s", server.id, e)
            sub.status = SubscriptionStatus.pending_provisioning
            sub.retry_count = (sub.retry_count or 0) + 1
            if vc:
                # The old client was already best-effort deleted from
                # old_server above (and its count decremented) — mark this
                # row deleted so the next retry cycle's _provision_subscription
                # correctly treats it as "no client exists, create fresh"
                # (its `status != deleted` check gates the enable_client
                # branch) instead of endlessly retrying enable_client against
                # a client that no longer exists on any server.
                vc.status = VpnClientStatus.deleted
            await audit.log(
                AuditAction.provisioning_failed,
                user_id=sub.user_id,
                entity_type="subscription",
                entity_id=sub.id,
                details=str(e),
            )
            # Re-raise so the API layer returns 503 instead of a bare 200
            # with no config_url — the caller (admin, via the bot) needs to
            # know this attempt didn't produce a usable device.
            raise

        # old_server's count was already decremented right after the
        # best-effort delete above (unconditionally, regardless of which
        # server gets selected next), so this increment is no longer paired
        # with a matching decrement at the same point in time and needs no
        # "only if the server changed" special-casing.
        await server_repo.increment_clients(server.id)

        if vc:
            vc.server_id = server.id
            vc.amnezia_client_id = resp.client.id
            vc.client_name = client_name
            vc.config_url = resp.client.config
            vc.protocol = resp.client.protocol
            vc.status = VpnClientStatus.active
            vc_id = vc.id
        else:
            new_vc = await vc_repo.create(
                subscription_id=sub.id,
                server_id=server.id,
                amnezia_client_id=resp.client.id,
                client_name=client_name,
                config_url=resp.client.config,
                protocol=resp.client.protocol,
            )
            vc_id = new_vc.id

        sub.status = SubscriptionStatus.active
        sub.server_id = server.id
        sub.last_provisioned_at = datetime.now(timezone.utc)

        await audit.log(
            AuditAction.vpn_client_created,
            entity_type="vpn_client",
            entity_id=vc_id,
            details="Provisioned via admin command" if not vc else "Reissued via admin command",
        )

        return resp.client.config

    async def add_server(
        self,
        session: AsyncSession,
        *,
        name: str,
        base_url: str,
        api_key: str,
        region: Optional[str] = "EU",
        weight: int = 100,
        max_clients: int = 200,
    ) -> VpnServer:
        """
        Adds a new VPN server after confirming — via the server's own
        amnezia-api instance, not a guess or an admin-supplied value —
        that it actually supports the AmneziaWG protocol this project
        requires (see integrations.amnezia.client.REQUIRED_AMNEZIAWG_PROTOCOL).
        This is the ONLY place a VpnServer row is created with a protocol
        that wasn't itself read back from a create-client response (see
        _provision_subscription), so it is also the only place that needs
        to change if the required protocol version is ever bumped.

        No server row is created if the check fails — an admin should not
        end up with a "server" in the pool that every purchase will then
        fail against one at a time. Raises:
          - ServerUnreachableError if the amnezia-api instance can't be
            reached at all (bad URL, firewall, service down).
          - AmneziaProtocolNotSupportedError if it's reachable but doesn't
            list the required protocol — the admin needs to upgrade
            AmneziaWG on that server first (see ТЗ point 8: this is a
            real server-side upgrade with new client configs, not
            something this code can paper over).
        """
        amnezia = AmneziaClient(base_url=base_url, api_key=api_key)
        try:
            protocol = await amnezia.resolve_amneziawg_protocol()
        except AmneziaProtocolNotSupportedError:
            raise
        except (AmneziaConnectionError, AmneziaError) as e:
            raise ServerUnreachableError(
                f"Could not reach amnezia-api at {base_url}: {e}"
            ) from e

        server_repo = VpnServerRepository(session)
        server = await server_repo.create(
            name=name,
            base_url=base_url,
            api_key=api_key,
            protocol=protocol,
            region=region,
            weight=weight,
            max_clients=max_clients,
        )
        return server


def billing_plan_repo(session: AsyncSession):
    from billing.repositories.other_repos import PlanRepository
    return PlanRepository(session)
