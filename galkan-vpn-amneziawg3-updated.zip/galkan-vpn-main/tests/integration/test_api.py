"""
Integration tests for billing FastAPI endpoints.
Uses test DB and mocked AmneziaClient.
"""
import os
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from unittest.mock import AsyncMock, patch

from api.main import app
from billing.database import AsyncSessionLocal, engine as _engine
from models import Base
import models.models  # noqa


# ---------------------------------------------------------------------------
# Override DB session in FastAPI dependency for tests
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture(autouse=True)
async def _billing_engine_schema():
    """
    These tests exercise the real FastAPI app end-to-end (ASGITransport, not
    a mocked dependency), so every request goes through Depends(get_db) ->
    billing.database.AsyncSessionLocal -> billing.database.engine — a
    DIFFERENT engine object than the one tests/conftest.py's `engine`/
    `session` fixtures create for the unit tests. SQLite's StaticPool
    (used automatically for ':memory:' URLs) keeps one connection alive per
    engine OBJECT, not per URL string, so this module's requests were
    hitting a schema-less database no other fixture in this codebase was
    ever creating. Drop-then-create on every test keeps them isolated from
    each other's data, same as conftest.py's per-test `engine` fixture does
    for the unit tests.
    """
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture(autouse=True)
def patch_billing_key(monkeypatch):
    monkeypatch.setenv("BILLING_SECRET_KEY", "test-secret")


@pytest.fixture
def client_headers():
    return {"X-Billing-Key": "test-secret"}


@pytest.fixture
def mock_amnezia():
    with patch("billing.services.billing_service.AmneziaClient") as MockClient:
        instance = AsyncMock()
        from integrations.amnezia.schemas import CreateClientResponse, CreatedClient
        instance.create_client.return_value = CreateClientResponse(
            message="OK",
            client=CreatedClient(
                id="integ-client-id",
                config="vpn://integtest",
                protocol="amneziawg3",
            ),
        )
        instance.enable_client.return_value = None
        instance.disable_client.return_value = None
        # Default happy path for add_server's protocol check — tests that
        # need to exercise the rejection path override this directly via
        # instance.resolve_amneziawg_protocol.side_effect.
        instance.resolve_amneziawg_protocol.return_value = "amneziawg3"
        MockClient.return_value = instance
        yield instance


@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_stars_payment_endpoint_unauthorized():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            json={
                "telegram_id": 123,
                "telegram_payment_charge_id": "abc",
                "total_amount": 100,
            },
        )
    assert resp.status_code == 422  # missing X-Billing-Key header


@pytest.mark.asyncio
async def test_stars_payment_missing_plan(client_headers):
    """Should return 400 if no plan exists in DB."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            headers=client_headers,
            json={
                "telegram_id": 9991,
                "telegram_payment_charge_id": "no_plan_test",
                "total_amount": 100,
            },
        )
    # Either 400 (ValueError: No active plan) or 500
    assert resp.status_code in (400, 500)


@pytest.mark.asyncio
async def test_manat_admin_approve_flow_end_to_end(client_headers, mock_amnezia):
    """
    Full HTTP round-trip: create a manat request (auto-assigned to an
    agent), accept it as that agent, report money received as that agent
    (must NOT create a subscription), then approve it as the MAIN ADMIN —
    exercising the actual Pydantic request/response schemas and
    exception-to-status-code mapping in the routers, not just
    BillingService directly (already covered by the unit tests in
    tests/unit/test_billing_service.py). Also verifies a second admin's
    attempt on the same (now-resolved) request is correctly rejected with
    409 (ТЗ p.8/p.13).
    """
    async with AsyncSessionLocal() as session:
        from models.models import Plan, VpnServer, VpnServerStatus

        plan = Plan(
            name="Integ Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        server = VpnServer(
            name="Integ Server", base_url="http://integ-vpn:4001", api_key="k",
            region="EU", weight=100, status=VpnServerStatus.active,
            max_clients=500, current_clients=0, protocol="amneziawg3",
        )
        session.add_all([plan, server])
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents",
            headers=client_headers,
            json={"telegram_id": 9001, "display_name": "Test Agent"},
        )
        assert agent_resp.status_code == 200
        agent_id = agent_resp.json()["id"]
        phone_resp = await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers,
            json={"phone_number": "+993 12 345678"},
        )
        assert phone_resp.status_code == 200

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8001,
                "username": "manat_integ_user",
                "plan_id": plan_id,
            },
        )
        assert create_resp.status_code == 200
        body = create_resp.json()
        assert body["agent_phone_shown"] == "+993 12 345678"
        assert body["amount_manat"] == 350.0
        assert body["assigned_agent_telegram_id"] == 9001
        request_id = body["request_id"]

        # Reporting before accepting must fail — the request is still
        # `assigned`, not awaiting_payment.
        premature_report = await ac.post(
            f"/api/v1/admin/manat/{request_id}/report",
            headers=client_headers,
            json={"agent_id": 9001, "received": True},
        )
        assert premature_report.status_code == 409

        accept_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert accept_resp.status_code == 200
        assert accept_resp.json()["telegram_id"] == 8001

        report_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/report",
            headers=client_headers,
            json={"agent_id": 9001, "received": True},
        )
        assert report_resp.status_code == 200
        assert report_resp.json()["status"] == "admin_review"

        # The agent's report alone must never create a subscription.
        status_after_report = await ac.get(
            f"/api/v1/payments/manat/{request_id}", headers=client_headers,
        )
        assert status_after_report.json()["status"] == "admin_review"

        queue_resp = await ac.get("/api/v1/admin/manat/queue", headers=client_headers)
        assert queue_resp.status_code == 200
        queue_items = queue_resp.json()["items"]
        assert any(item["id"] == request_id for item in queue_items)

        approve_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/approve",
            headers=client_headers,
            json={"admin_telegram_id": 555},
        )
        assert approve_resp.status_code == 200
        approve_body = approve_resp.json()
        assert approve_body["ok"] is True
        assert "subscription_id" in approve_body
        assert approve_body["telegram_id"] == 8001, (
            "bot needs this to notify the payer from the admin's own chat/FSM "
            "session, which has no access to the payer's FSMContext"
        )
        assert approve_body["status"] == "active"
        assert approve_body["config_url"], "mock_amnezia should have provisioned a real client"

        # A second admin approve on the already-resolved request must get
        # 409, not a silent success or a bare 500 (ТЗ p.8/p.13).
        second_approve_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/approve",
            headers=client_headers,
            json={"admin_telegram_id": 556},
        )
        assert second_approve_resp.status_code == 409

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"admin_telegram_id": 556},
        )
        assert reject_resp.status_code == 409

        # The agent must have no way to reach the approve/reject
        # endpoints with agent-only semantics — there is no such route;
        # only /report exists for the agent side, already exercised above.


@pytest.mark.asyncio
async def test_manat_agent_cannot_skip_to_admin_review_without_reporting(client_headers):
    """An agent who never reports receipt must leave the request out of
    the admin queue entirely — admin_review is reached only via /report."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ No-Report Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9010},
        )
        agent_id = agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 555555"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8009, "plan_id": plan_id},
        )
        request_id = create_resp.json()["request_id"]

        await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers, json={"agent_id": 9010},
        )

        queue_resp = await ac.get("/api/v1/admin/manat/queue", headers=client_headers)
        assert all(item["id"] != request_id for item in queue_resp.json()["items"])

        # Admin approve attempted directly (skipping the agent's report)
        # must fail — not in admin_review.
        approve_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/approve",
            headers=client_headers,
            json={"admin_telegram_id": 555},
        )
        assert approve_resp.status_code == 409


@pytest.mark.asyncio
async def test_manat_reject_flow_end_to_end(client_headers):
    """A rejected request must never produce a subscription — checked via
    the same HTTP path a real main-admin "not confirmed" decision takes."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Reject Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents",
            headers=client_headers,
            json={"telegram_id": 9004},
        )
        agent_id = agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers,
            json={"phone_number": "+993 12 999999"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8002,
                "plan_id": plan_id,
            },
        )
        request_id = create_resp.json()["request_id"]

        accept_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers,
            json={"agent_id": 9004},
        )
        assert accept_resp.status_code == 200

        report_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/report",
            headers=client_headers,
            json={"agent_id": 9004, "received": True},
        )
        assert report_resp.status_code == 200

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"admin_telegram_id": 555, "reason": "no transfer seen"},
        )
        assert reject_resp.status_code == 200
        assert reject_resp.json() == {"ok": True}

        status_resp = await ac.get(
            f"/api/v1/payments/manat/{request_id}", headers=client_headers,
        )
        assert status_resp.json()["status"] == "rejected"


@pytest.mark.asyncio
async def test_manat_report_money_not_received_reassigns_to_next_agent(client_headers):
    """An agent reporting "Деньги не получены" must hand the request to
    the next agent in the queue via the actual HTTP path — same outcome as
    an explicit decline."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Not-Received Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        first_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9011},
        )
        first_agent_id = first_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{first_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000003"},
        )
        second_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9012},
        )
        second_agent_id = second_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{second_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000004"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8010, "plan_id": plan_id},
        )
        body = create_resp.json()
        request_id = body["request_id"]
        assigned_telegram_id = body["assigned_agent_telegram_id"]

        await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers, json={"agent_id": assigned_telegram_id},
        )

        report_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/report",
            headers=client_headers,
            json={"agent_id": assigned_telegram_id, "received": False},
        )
        assert report_resp.status_code == 200
        assert report_resp.json()["status"] == "assigned"

        status_resp = await ac.get(
            f"/api/v1/payments/manat/{request_id}", headers=client_headers,
        )
        assert status_resp.json()["status"] == "assigned"


@pytest.mark.asyncio
async def test_manat_decline_reassigns_to_next_agent(client_headers):
    """An agent tapping "Не могу принять" must hand the request to the next
    agent in the queue via the actual HTTP path."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Decline Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        first_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9005},
        )
        first_agent_id = first_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{first_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000001"},
        )
        second_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9006},
        )
        second_agent_id = second_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{second_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000002"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8003, "plan_id": plan_id},
        )
        body = create_resp.json()
        request_id = body["request_id"]
        assigned_telegram_id = body["assigned_agent_telegram_id"]

        decline_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/decline",
            headers=client_headers,
            json={"agent_id": assigned_telegram_id},
        )
        assert decline_resp.status_code == 200
        decline_body = decline_resp.json()
        assert decline_body["reassigned"] is True
        assert decline_body["new_agent_telegram_id"] in (9005, 9006)
        assert decline_body["new_agent_telegram_id"] != assigned_telegram_id

        status_resp = await ac.get(
            f"/api/v1/payments/manat/{request_id}", headers=client_headers,
        )
        assert status_resp.status_code == 200
        assert status_resp.json()["status"] == "assigned"


@pytest.mark.asyncio
async def test_manat_request_unknown_plan_returns_400(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8004,
                "plan_id": 999999,
            },
        )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_manat_request_non_monthly_plan_returns_422(client_headers):
    """Manat payment must be refused up front for any plan other than the
    30-day one — checked via the actual HTTP status code the bot branches
    on to show "use another payment method"."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ 3-month Plan", duration_days=90, price_stars=250,
            price_usdt=8.0, price_manat=900.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8005, "plan_id": plan_id},
        )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_manat_request_no_agent_returns_503(client_headers):
    """No agent registered at all -> 503, distinct from the 400/422 plan
    errors, so the bot can show a different message."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ No-Agent Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8006, "plan_id": plan_id},
        )
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_manat_report_unknown_request_returns_404(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/manat/999999/report",
            headers=client_headers,
            json={"agent_id": 9001, "received": True},
        )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_manat_approve_unknown_request_returns_404(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/manat/999999/approve",
            headers=client_headers,
            json={"admin_telegram_id": 555},
        )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_agent_schedule_and_manual_disable_via_http(client_headers):
    """Admin-configured schedule and independent manual kill switch (ТЗ
    p.2/p.10), exercised via the actual HTTP endpoints."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers,
            json={"telegram_id": 9013, "timezone": "Asia/Ashgabat"},
        )
        agent_id = agent_resp.json()["id"]

        schedule_resp = await ac.patch(
            f"/api/v1/admin/agents/{agent_id}/schedule",
            headers=client_headers,
            json={
                "timezone": "Asia/Ashgabat",
                "work_days": "1,2,3,4,5",
                "work_start_time": "09:00",
                "work_end_time": "18:00",
            },
        )
        assert schedule_resp.status_code == 200

        lookup_resp = await ac.get(
            "/api/v1/admin/agents/by-telegram/9013", headers=client_headers,
        )
        agent_data = lookup_resp.json()
        assert agent_data["work_days"] == "1,2,3,4,5"
        assert agent_data["work_start_time"] == "09:00"
        assert agent_data["work_end_time"] == "18:00"
        assert agent_data["manually_disabled"] is False

        disable_resp = await ac.patch(
            f"/api/v1/admin/agents/{agent_id}/manual-disable",
            headers=client_headers,
            json={"manually_disabled": True},
        )
        assert disable_resp.status_code == 200

        lookup_resp2 = await ac.get(
            "/api/v1/admin/agents/by-telegram/9013", headers=client_headers,
        )
        assert lookup_resp2.json()["manually_disabled"] is True


@pytest.mark.asyncio
async def test_agent_phone_limit_configurable_via_http(client_headers):
    """ТЗ p.9: the per-phone daily limit is a configurable business
    setting, exercised via the actual HTTP endpoint."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9014},
        )
        agent_id = agent_resp.json()["id"]
        phone_resp = await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000009"},
        )
        phone_id = phone_resp.json()["id"]

        limit_resp = await ac.patch(
            f"/api/v1/admin/agents/phones/{phone_id}/limit",
            headers=client_headers,
            json={"daily_limit_manat": 1000},
        )
        assert limit_resp.status_code == 200

        lookup_resp = await ac.get(
            "/api/v1/admin/agents/by-telegram/9014", headers=client_headers,
        )
        phones = lookup_resp.json()["phones"]
        assert phones[0]["daily_limit_manat"] == 1000.0


@pytest.mark.asyncio
async def test_agent_phone_enable_disable_via_http(client_headers):
    """Agent self-service toggle (not admin-only) via the actual HTTP
    path the bot's /my_numbers command uses."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9007},
        )
        agent_id = agent_resp.json()["id"]
        phone_resp = await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000010"},
        )
        phone_id = phone_resp.json()["id"]

        lookup_resp = await ac.get(
            f"/api/v1/admin/agents/by-telegram/9007", headers=client_headers,
        )
        assert lookup_resp.status_code == 200
        assert lookup_resp.json()["phones"][0]["is_enabled"] is True

        disable_resp = await ac.patch(
            f"/api/v1/admin/agents/phones/{phone_id}/enabled",
            headers=client_headers, json={"is_enabled": False},
        )
        assert disable_resp.status_code == 200

        lookup_resp2 = await ac.get(
            f"/api/v1/admin/agents/by-telegram/9007", headers=client_headers,
        )
        assert lookup_resp2.json()["phones"][0]["is_enabled"] is False


@pytest.mark.asyncio
async def test_add_server_endpoint_does_not_accept_protocol_field(client_headers, mock_amnezia):
    """
    /api/v1/admin/servers must determine the protocol automatically via
    the new server's own amnezia-api instance — it must not accept a
    protocol field from the admin at all (ТЗ point 6: "Не принимать
    'amneziawg2' как fallback" / "Не передавать протокол вручную через
    /add_server"). Even if a client sends one, the response's protocol
    must reflect what resolve_amneziawg_protocol() returned, not the
    submitted value.
    """
    mock_amnezia.resolve_amneziawg_protocol.return_value = "amneziawg3"

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/servers",
            headers=client_headers,
            json={
                "name": "New Integ Server",
                "base_url": "http://new-integ-vpn:4001",
                "api_key": "new-key",
                # Deliberately including a stale/wrong protocol field to
                # confirm the API ignores it (Pydantic just drops unknown
                # fields by default) rather than trusting client input.
                "protocol": "amneziawg2",
            },
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["protocol"] == "amneziawg3", (
        "protocol must come from resolve_amneziawg_protocol(), never from "
        "the request body"
    )


@pytest.mark.asyncio
async def test_add_server_rejects_when_protocol_not_supported(client_headers, mock_amnezia):
    """A server that hasn't been upgraded to the required AmneziaWG
    version must be rejected with 422 via the real HTTP path — no server
    row created, matching the unit-level guarantee in
    test_add_server_rejects_server_on_legacy_protocol_only."""
    from integrations.amnezia.errors import AmneziaProtocolNotSupportedError

    mock_amnezia.resolve_amneziawg_protocol.side_effect = AmneziaProtocolNotSupportedError(
        "Server does not support amneziawg3"
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/servers",
            headers=client_headers,
            json={
                "name": "Legacy Integ Server",
                "base_url": "http://legacy-integ-vpn:4001",
                "api_key": "legacy-key",
            },
        )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_add_server_returns_503_when_unreachable(client_headers, mock_amnezia):
    from integrations.amnezia.errors import AmneziaConnectionError

    mock_amnezia.resolve_amneziawg_protocol.side_effect = AmneziaConnectionError("refused")

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/servers",
            headers=client_headers,
            json={
                "name": "Unreachable Integ Server",
                "base_url": "http://unreachable-integ-vpn:4001",
                "api_key": "key",
            },
        )
    assert resp.status_code == 503
