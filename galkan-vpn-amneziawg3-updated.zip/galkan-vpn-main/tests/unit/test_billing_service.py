"""
Unit tests for BillingService core logic.
All external calls (Amnezia API) are mocked.
"""
import pytest
import pytest_asyncio
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

from sqlalchemy import select
from billing.services.billing_service import (
    BillingService,
    MANAT_AGENT_ACCEPT_WINDOW,
    MANAT_PAYMENT_WINDOW,
    ManatPlanNotEligibleError,
    ManatRequestAlreadyResolvedError,
    ManatRequestNotAssignedToAgentError,
    NoAgentAvailableError,
    ServerUnreachableError,
    TrialAlreadyUsedError,
)
from billing.repositories.other_repos import (
    AgentRepository,
    AuditRepository,
    ManatRequestRepository,
    PlanRepository,
    VpnClientRepository,
)
from billing.repositories.server_repo import VpnServerRepository
from billing.repositories.subscription_repo import SubscriptionRepository
from billing.repositories.user_repo import UserRepository
from integrations.amnezia.errors import (
    AmneziaConnectionError,
    AmneziaError,
    AmneziaProtocolNotSupportedError,
)
from models.models import (
    Agent,
    AgentPhone,
    AuditAction,
    AuditLog,
    ManatPaymentRequest,
    ManatPaymentTransaction,
    ManatRequestStatus,
    Plan,
    Subscription,
    SubscriptionStatus,
    VpnClient,
    VpnServer,
    VpnServerStatus,
    VpnClientStatus,
    PaymentProvider,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _seed_plan(session) -> Plan:
    plan = Plan(
        name="Test Plan",
        duration_days=30,
        price_stars=100,
        price_usdt=3.0,
        price_manat=350.0,
        is_active=True,
    )
    session.add(plan)
    await session.flush()
    return plan


async def _seed_trial_plan(session) -> Plan:
    plan = Plan(
        name="Test Trial Plan",
        duration_days=3,
        price_stars=0,
        price_usdt=0,
        is_active=False,
        is_trial=True,
    )
    session.add(plan)
    await session.flush()
    return plan


async def _seed_server(session) -> VpnServer:
    server = VpnServer(
        name="Test Server",
        base_url="http://test-vpn:4001",
        api_key="test-api-key",
        region="EU",
        weight=100,
        status=VpnServerStatus.active,
        max_clients=500,
        current_clients=0,
        protocol="amneziawg3",
    )
    session.add(server)
    await session.flush()
    return server


async def _seed_agent(
    session,
    telegram_id: int,
    phone: str = "+993 12 345678",
    is_active: bool = True,
    manually_disabled: bool = False,
    work_days: str | None = None,
    work_start_time: str | None = None,
    work_end_time: str | None = None,
    timezone_name: str = "Asia/Ashgabat",
) -> tuple[Agent, AgentPhone]:
    """Creates an active agent with one enabled phone — the minimal setup
    for the agent to be a valid candidate in
    BillingService._pick_agent_and_phone. With no schedule args, the agent
    has no configured schedule and is therefore always on-shift (see
    BillingService._agent_is_on_shift)."""
    repo = AgentRepository(session)
    agent = await repo.create(
        telegram_id=telegram_id,
        timezone_name=timezone_name,
        work_days=work_days,
        work_start_time=work_start_time,
        work_end_time=work_end_time,
    )
    if not is_active:
        await repo.set_active(agent.id, False)
    if manually_disabled:
        await repo.set_manually_disabled(agent.id, True)
    agent_phone = await repo.add_phone(agent.id, phone)
    await session.flush()
    return agent, agent_phone


# ---------------------------------------------------------------------------
# Test: Stars payment - new user, new subscription
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_stars_payment_creates_subscription(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=111,
        username="testuser",
        first_name="Test",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_abc123",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    # Re-fetch with relationships eagerly loaded
    from sqlalchemy.orm import joinedload
    result = await session.execute(
        select(type(sub)).options(joinedload(type(sub).vpn_client))
        .where(type(sub).id == sub.id)
    )
    sub = result.unique().scalar_one()

    assert sub is not None
    assert sub.status == SubscriptionStatus.active
    assert sub.vpn_client is not None
    assert sub.vpn_client.amnezia_client_id == "test-uuid-1234"
    assert sub.vpn_client.config_url == "vpn://eyJ0ZXN0IjoiY29uZmlnIn0="
    assert sub.expires_at is not None
    assert sub.expires_at.replace(tzinfo=timezone.utc) > datetime.now(timezone.utc)

    mock_amnezia_client.create_client.assert_called_once()


# ---------------------------------------------------------------------------
# Test: USDT payment
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_usdt_payment_creates_subscription(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=222,
        username=None,
        first_name="Alice",
        last_name=None,
        provider=PaymentProvider.usdt,
        external_id="invoice_xyz999",
        amount=3.0,
        currency="USDT",
    )
    await session.commit()

    from sqlalchemy.orm import joinedload
    result = await session.execute(
        select(type(sub)).options(joinedload(type(sub).vpn_client))
        .where(type(sub).id == sub.id)
    )
    sub = result.unique().scalar_one()

    assert sub.status == SubscriptionStatus.active
    assert sub.vpn_client is not None


# ---------------------------------------------------------------------------
# Test: Duplicate payment is idempotent
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_duplicate_payment_is_idempotent(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()
    kwargs = dict(
        telegram_id=333,
        username="dup",
        first_name="Dup",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_dup_001",
        amount=100,
        currency="XTR",
    )
    sub1 = await svc.handle_payment(session, **kwargs)
    await session.commit()

    try:
        sub2 = await svc.handle_payment(session, **kwargs)
        assert sub2.id == sub1.id
    except ValueError as e:
        assert "Duplicate" in str(e)

    assert mock_amnezia_client.create_client.call_count == 1


# ---------------------------------------------------------------------------
# Test: default mode="new" always creates a brand-new device, even for the
# same telegram_id paying twice — this is the hard "1 payment = 1 device" rule.
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_repeat_payment_creates_new_device_by_default(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()

    sub = await svc.handle_payment(
        session,
        telegram_id=444,
        username=None,
        first_name="Bob",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_device_1",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    sub2 = await svc.handle_payment(
        session,
        telegram_id=444,  # same user
        username=None,
        first_name="Bob",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_device_2",  # different payment
        amount=100,
        currency="XTR",
        # mode defaults to "new"
    )
    await session.commit()

    assert sub2.id != sub.id, "A second payment must provision a second device, not extend the first"
    assert mock_amnezia_client.create_client.call_count == 2

    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(444)
    sub_repo = SubscriptionRepository(session)
    all_devices = await sub_repo.get_all_for_user(user.id)
    assert len(all_devices) == 2


# ---------------------------------------------------------------------------
# Test: mode="renew" extends the ONE specific device given by
# target_subscription_id, and does not create a new one.
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_explicit_renew_extends_specific_device(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()

    sub = await svc.handle_payment(
        session,
        telegram_id=445,
        username=None,
        first_name="Carol",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_renew_base",
        amount=100,
        currency="XTR",
    )
    await session.commit()
    first_expiry = sub.expires_at

    sub2 = await svc.handle_payment(
        session,
        telegram_id=445,
        username=None,
        first_name="Carol",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_renew_actual",
        amount=100,
        currency="XTR",
        mode="renew",
        target_subscription_id=sub.id,
    )
    await session.commit()

    assert sub2.id == sub.id, "Explicit renew must extend the SAME device, not create a new one"
    assert sub2.expires_at > first_expiry

    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(445)
    sub_repo = SubscriptionRepository(session)
    all_devices = await sub_repo.get_all_for_user(user.id)
    assert len(all_devices) == 1, "Renewing must not create a second device"


@pytest.mark.asyncio
async def test_renew_rejects_another_users_subscription(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()

    victim_sub = await svc.handle_payment(
        session,
        telegram_id=446,
        username=None,
        first_name="Victim",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_victim",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    with pytest.raises(ValueError):
        await svc.handle_payment(
            session,
            telegram_id=447,  # different user
            username=None,
            first_name="Attacker",
            last_name=None,
            provider=PaymentProvider.stars,
            external_id="charge_attacker",
            amount=100,
            currency="XTR",
            mode="renew",
            target_subscription_id=victim_sub.id,
        )


@pytest.mark.asyncio
async def test_renew_without_target_id_raises(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()

    with pytest.raises(ValueError):
        await svc.handle_payment(
            session,
            telegram_id=448,
            username=None,
            first_name="NoTarget",
            last_name=None,
            provider=PaymentProvider.stars,
            external_id="charge_no_target",
            amount=100,
            currency="XTR",
            mode="renew",
            target_subscription_id=None,
        )


# ---------------------------------------------------------------------------
# Test: Subscription expiry disables client
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_expiry_disables_subscription(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()

    sub = await svc.handle_payment(
        session,
        telegram_id=555,
        username=None,
        first_name="Expired",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_expire_test",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    # Force-expire: use naive datetime to match SQLite
    from sqlalchemy import update
    from models.models import Subscription
    await session.execute(
        update(Subscription)
        .where(Subscription.id == sub.id)
        .values(expires_at=datetime(2020, 1, 1))
    )
    await session.commit()

    with patch(
        "billing.services.billing_service.AsyncSessionLocal"
    ) as mock_session_factory:
        mock_session_factory.return_value.__aenter__ = AsyncMock(return_value=session)
        mock_session_factory.return_value.__aexit__ = AsyncMock(return_value=False)

        count = await svc.disable_expired_subscriptions()

    assert count >= 1
    mock_amnezia_client.disable_client.assert_called_once()


# ---------------------------------------------------------------------------
# Test: Amnezia API error → pending_provisioning
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_amnezia_error_sets_pending_provisioning(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    from integrations.amnezia.errors import AmneziaConnectionError
    mock_amnezia_client.create_client.side_effect = AmneziaConnectionError("Connection refused")

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=666,
        username=None,
        first_name="Error",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_error_001",
        amount=100,
        currency="XTR",
    )

    assert sub.status == SubscriptionStatus.pending_provisioning
    # No VpnClient should have been created
    vc_result = await session.execute(
        select(VpnClient).where(VpnClient.subscription_id == sub.id)
    )
    assert vc_result.scalar_one_or_none() is None


# ---------------------------------------------------------------------------
# Test: Server selection — weight × (1-load)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_server_selection_by_load(session):
    server_a = VpnServer(
        name="A", base_url="http://a:4001", api_key="k",
        region="EU", weight=100, status=VpnServerStatus.active,
        max_clients=100, current_clients=90, protocol="amneziawg3",
    )
    server_b = VpnServer(
        name="B", base_url="http://b:4001", api_key="k",
        region="EU", weight=100, status=VpnServerStatus.active,
        max_clients=100, current_clients=5, protocol="amneziawg3",
    )
    session.add_all([server_a, server_b])
    await session.commit()

    repo = VpnServerRepository(session)
    picks = {"A": 0, "B": 0}
    for _ in range(50):
        s = await repo.select_server()
        picks[s.name] += 1

    assert picks["B"] > picks["A"], f"Expected B to win more, got {picks}"


# ---------------------------------------------------------------------------
# Test: Disabled server is never selected
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_disabled_server_not_selected(session):
    session.add(VpnServer(
        name="Off", base_url="http://off:4001", api_key="k",
        region="EU", weight=1000, status=VpnServerStatus.disabled,
        max_clients=500, current_clients=0, protocol="amneziawg3",
    ))
    session.add(VpnServer(
        name="On", base_url="http://on:4001", api_key="k",
        region="EU", weight=1, status=VpnServerStatus.active,
        max_clients=500, current_clients=0, protocol="amneziawg3",
    ))
    await session.commit()

    repo = VpnServerRepository(session)
    for _ in range(10):
        s = await repo.select_server()
        assert s.name == "On"


# ---------------------------------------------------------------------------
# Test: Amnezia adapter create_client HTTP schema
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_amnezia_client_create():
    import respx
    import httpx
    from integrations.amnezia.client import AmneziaClient
    from integrations.amnezia.schemas import CreateClientRequest

    with respx.mock(base_url="http://vpn:4001") as mock:
        mock.post("/clients").mock(
            return_value=httpx.Response(
                200,
                json={
                    "message": "Клиент создан",
                    "client": {
                        "id": "abc-123",
                        "config": "vpn://somebase64",
                        "protocol": "amneziawg",
                    },
                },
            )
        )
        client = AmneziaClient(base_url="http://vpn:4001", api_key="mykey")
        resp = await client.create_client(
            CreateClientRequest(clientName="test_user", protocol="amneziawg")
        )

    assert resp.client.id == "abc-123"
    assert resp.client.config == "vpn://somebase64"
    assert resp.client.protocol == "amneziawg"


# ---------------------------------------------------------------------------
# Test: Admin extend subscription
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_admin_extend_subscription(session, mock_amnezia_client):
    await _seed_plan(session)
    await _seed_server(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=777,
        username=None,
        first_name="Admin",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_admin_extend",
        amount=100,
        currency="XTR",
    )
    await session.commit()
    original_expiry = sub.expires_at

    await svc.admin_extend_subscription(session, sub.id, days=15)
    await session.commit()

    from sqlalchemy.orm import joinedload
    from models.models import Subscription
    result = await session.execute(select(Subscription).where(Subscription.id == sub.id))
    refreshed = result.scalar_one()

    # Compare natively (both naive from SQLite or both aware from PG)
    assert refreshed.expires_at > original_expiry


async def test_reissue_creates_client_when_none_ever_existed(session, mock_amnezia_client):
    """
    Reproduces the real production bug: a purchase went through (payment
    captured, Subscription row created with status=error) but provisioning
    failed before any VpnClient row was ever written — e.g. because no VPN
    server was configured in the DB yet at purchase time. admin_reissue_device
    must handle this by creating a fresh VpnClient, not by assuming one
    already exists to update.
    """
    from models.models import Subscription, User, Plan

    plan = await _seed_plan(session)
    server = await _seed_server(session)
    user = User(telegram_id=12345, username="broken_purchase")
    session.add(user)
    await session.flush()

    sub = Subscription(
        user_id=user.id,
        plan_id=plan.id,
        server_id=None,
        status=SubscriptionStatus.error,
    )
    session.add(sub)
    await session.commit()

    # Sanity check this mirrors the real bug: no VpnClient row exists yet.
    vc_repo = VpnClientRepository(session)
    assert await vc_repo.get_by_subscription(sub.id) is None

    svc = BillingService()
    config_url = await svc.admin_reissue_device(session, sub.id)
    await session.commit()

    assert config_url is not None

    vc = await vc_repo.get_by_subscription(sub.id)
    assert vc is not None
    assert vc.server_id == server.id
    assert vc.status == VpnClientStatus.active
    assert vc.config_url == config_url

    result = await session.execute(select(Subscription).where(Subscription.id == sub.id))
    refreshed = result.scalar_one()
    assert refreshed.status == SubscriptionStatus.active
    assert refreshed.server_id == server.id


async def test_reissue_updates_existing_broken_client_in_place(session, mock_amnezia_client):
    """
    The other reissue scenario: a VpnClient row exists (the purchase fully
    completed once) but its config was never actually applied on the VPN
    server — e.g. a race in amnezia-api's create_client dropped the peer.
    admin_reissue_device should update that same row (subscription_id is
    unique) rather than inserting a second one.
    """
    await _seed_plan(session)
    server = await _seed_server(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=888,
        username=None,
        first_name="Broken",
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="charge_broken_client",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    vc_repo = VpnClientRepository(session)
    original_vc = await vc_repo.get_by_subscription(sub.id)
    assert original_vc is not None
    original_vc_id = original_vc.id
    original_amnezia_client_id = original_vc.amnezia_client_id

    config_url = await svc.admin_reissue_device(session, sub.id)
    await session.commit()

    result = await session.execute(
        select(VpnClient).where(VpnClient.subscription_id == sub.id)
    )
    all_rows = result.scalars().all()
    assert len(all_rows) == 1, "reissue must not create a second VpnClient row for the same subscription"

    refreshed_vc = all_rows[0]
    assert refreshed_vc.id == original_vc_id, "the same row should be updated in place"
    assert refreshed_vc.config_url == config_url
    assert refreshed_vc.status == VpnClientStatus.active
    # mock_amnezia_client returns a new client id on each create_client call,
    # so a real reissue should produce a different amnezia_client_id.
    assert refreshed_vc.amnezia_client_id != original_amnezia_client_id or config_url is not None


async def test_reissue_failure_marks_old_client_deleted_and_next_retry_succeeds(
    session, mock_amnezia_client
):
    """
    Closes the known limitation from the reissue fix: if create_client()
    fails while reissuing a device that already had a VpnClient row (the
    old client was already best-effort deleted from its server above), the
    old row must not be left in a state that makes the *next* retry cycle
    waste attempts on enable_client() against a client that no longer
    exists anywhere — it should instead go straight to creating a fresh one.

    Also verifies the row-reuse fix in _provision_subscription: once the old
    row is marked `deleted`, the next successful attempt must UPDATE that
    same row (subscription_id is unique) rather than INSERT a second one.
    """
    plan = await _seed_plan(session)
    server = await _seed_server(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=999,
        username=None,
        first_name="Reissue",
        last_name="Failure",
        provider=PaymentProvider.stars,
        external_id="charge_reissue_failure",
        amount=100,
        currency="XTR",
    )
    await session.commit()

    vc_repo = VpnClientRepository(session)
    server_repo = VpnServerRepository(session)
    sub_repo = SubscriptionRepository(session)

    original_vc = await vc_repo.get_by_subscription(sub.id)
    assert original_vc is not None
    original_vc_id = original_vc.id

    server_after_purchase = await server_repo.get_by_id(server.id)
    clients_after_purchase = server_after_purchase.current_clients
    assert clients_after_purchase == 1

    # Make the next create_client() call fail, simulating amnezia-api being
    # unreachable at the exact moment reissue tries to provision the
    # replacement client (the old one was already deleted from the server
    # by this point in admin_reissue_device).
    with patch(
        "billing.services.billing_service.AmneziaClient"
    ) as MockClientDuringFailure:
        failing_instance = AsyncMock()
        MockClientDuringFailure.return_value = failing_instance
        failing_instance.delete_client.return_value = None
        failing_instance.create_client.side_effect = AmneziaError("amnezia-api unreachable")

        with pytest.raises(AmneziaError):
            await svc.admin_reissue_device(session, sub.id)
        await session.commit()

    # --- Partial-failure bookkeeping must have been applied ---
    refreshed_sub = await sub_repo.get_by_id(sub.id)
    assert refreshed_sub.status == SubscriptionStatus.pending_provisioning
    assert refreshed_sub.retry_count == 1

    refreshed_vc = await vc_repo.get_by_subscription(sub.id)
    assert refreshed_vc is not None
    assert refreshed_vc.id == original_vc_id, "must not have inserted a second row"
    assert refreshed_vc.status == VpnClientStatus.deleted, (
        "old client must be marked deleted so the next retry cycle creates "
        "a fresh one instead of retrying enable_client against a client "
        "that no longer exists on any server"
    )

    server_after_failure = await server_repo.get_by_id(server.id)
    assert server_after_failure.current_clients == 0, (
        "old server's count must be decremented even though reissue failed "
        "partway through — the client really was removed from it"
    )

    audit = AuditRepository(session)
    result = await session.execute(
        select(VpnClient).where(VpnClient.id == original_vc_id)
    )
    assert result.scalar_one() is not None  # row still exists, just deleted

    # --- The next retry cycle must succeed by updating the same row ---
    refreshed_sub.retry_count = 0  # below the escalate-to-error threshold
    await svc._provision_subscription(session, refreshed_sub)
    await session.commit()

    final_sub = await sub_repo.get_by_id(sub.id)
    assert final_sub.status == SubscriptionStatus.active

    result = await session.execute(
        select(VpnClient).where(VpnClient.subscription_id == sub.id)
    )
    all_rows = result.scalars().all()
    assert len(all_rows) == 1, (
        "the retry must update the deleted row in place, not insert a "
        "second row and violate the subscription_id uniqueness constraint"
    )
    assert all_rows[0].id == original_vc_id
    assert all_rows[0].status == VpnClientStatus.active

    server_after_retry = await server_repo.get_by_id(server.id)
    assert server_after_retry.current_clients == 1, (
        "the successful retry must increment the count back to 1"
    )


# ---------------------------------------------------------------------------
# Trial
# ---------------------------------------------------------------------------

async def test_grant_trial_creates_active_subscription(session, mock_amnezia_client):
    server = await _seed_server(session)
    trial_plan = await _seed_trial_plan(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.grant_trial(
        session,
        telegram_id=777,
        username="trialuser",
        first_name="Trial",
        last_name="User",
    )
    await session.commit()

    assert sub.plan_id == trial_plan.id
    assert sub.status == SubscriptionStatus.active

    vc_repo = VpnClientRepository(session)
    vc = await vc_repo.get_by_subscription(sub.id)
    assert vc is not None, "trial must provision a real VpnClient, same as a paid purchase"
    assert vc.status == VpnClientStatus.active


async def test_grant_trial_twice_raises_and_does_not_double_provision(session, mock_amnezia_client):
    server = await _seed_server(session)
    await _seed_trial_plan(session)
    await session.commit()

    svc = BillingService()
    first_sub = await svc.grant_trial(
        session, telegram_id=778, username=None, first_name="A", last_name=None
    )
    await session.commit()

    with pytest.raises(TrialAlreadyUsedError):
        await svc.grant_trial(
            session, telegram_id=778, username=None, first_name="A", last_name=None
        )
    await session.rollback()

    # Confirm no second subscription/order/payment was created for this user.
    sub_repo = SubscriptionRepository(session)
    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(778)
    result = await session.execute(
        select(Subscription).where(Subscription.user_id == user.id)
    )
    all_subs = result.scalars().all()
    assert len(all_subs) == 1
    assert all_subs[0].id == first_sub.id


async def test_grant_trial_without_seeded_trial_plan_raises_value_error(session, mock_amnezia_client):
    # No _seed_trial_plan() call — simulates a fresh deploy where seeds/seed.py
    # hasn't been run with this feature's version yet. Must fail with a clear
    # message, not a confusing downstream error from handle_payment().
    await _seed_server(session)
    await session.commit()

    svc = BillingService()
    with pytest.raises(ValueError, match="No trial plan configured"):
        await svc.grant_trial(
            session, telegram_id=779, username=None, first_name=None, last_name=None
        )


async def test_get_active_plan_never_returns_trial_plan_even_if_marked_active(session):
    """
    The single most important invariant of the whole trial feature: an
    admin mistake (or a future migration) that flips is_active=True on the
    trial plan must never let a REAL purchase silently resolve to the free
    trial. get_active_plan() excludes is_trial=True unconditionally,
    independent of is_active — this test seeds the trial plan with
    is_active=True specifically to prove that flag alone can't cause this.
    """
    plan_repo = PlanRepository(session)
    trial_plan = Plan(
        name="Trial (mistakenly active)",
        duration_days=3,
        price_stars=0,
        price_usdt=0,
        is_active=True,  # the mistake this test guards against
        is_trial=True,
    )
    session.add(trial_plan)
    await session.flush()

    active = await plan_repo.get_active_plan()
    assert active is None, (
        "get_active_plan() must not return the trial plan even when "
        "is_active=True on it — is_trial must be an independent exclusion"
    )

    # Now add a real plan alongside it and confirm THAT one is what a
    # normal purchase would resolve to.
    real_plan = Plan(
        name="Real Plan",
        duration_days=30,
        price_stars=100,
        price_usdt=3.0,
        is_active=True,
        is_trial=False,
    )
    session.add(real_plan)
    await session.flush()

    active = await plan_repo.get_active_plan()
    assert active is not None
    assert active.id == real_plan.id
    assert active.is_trial is False



# ---------------------------------------------------------------------------
# Manat payment (agent queue: assignment, accept/decline, confirm/reject,
# timeouts, per-phone daily limit)
# ---------------------------------------------------------------------------

async def test_create_manat_request_assigns_agent_and_touches_nothing_else(session, mock_amnezia_client):
    """Creating a request must assign an available agent/phone (moving
    straight to `assigned` since assignment happened synchronously) and
    must not create any Order/Payment/Subscription — those only appear
    once the MAIN ADMIN approves the reported payment (ТЗ p.6/p.14)."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9101)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session,
        telegram_id=501,
        username="manatuser",
        first_name="Manat",
        last_name="User",
        plan_id=plan.id,
    )
    await session.commit()

    assert req.status == ManatRequestStatus.assigned
    assert req.plan_id == plan.id
    assert req.amount_manat == plan.price_manat
    assert req.assigned_agent_id == agent.id
    assert req.assigned_phone_id == phone.id
    assert req.agent_phone_shown == phone.phone_number
    assert req.assigned_at is not None

    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(501)
    result = await session.execute(select(Subscription).where(Subscription.user_id == user.id))
    assert result.scalars().all() == [], "no subscription should exist before admin approval"


async def test_create_manat_request_rejects_unknown_plan(session, mock_amnezia_client):
    await _seed_agent(session, telegram_id=9102)
    await session.commit()

    svc = BillingService()
    with pytest.raises(ValueError, match="Plan not found"):
        await svc.create_manat_request(
            session,
            telegram_id=502,
            username=None,
            first_name=None,
            last_name=None,
            plan_id=999999,
        )


async def test_create_manat_request_rejects_non_monthly_plan(session, mock_amnezia_client):
    """Manat payment is restricted to the 1-month (30-day) plan — any other
    duration must be rejected before a request row is even created."""
    other_plan = Plan(
        name="3 months",
        duration_days=90,
        price_stars=250,
        price_usdt=8.0,
        price_manat=900.0,
        is_active=True,
    )
    session.add(other_plan)
    await session.flush()
    await _seed_agent(session, telegram_id=9103)
    await session.commit()

    svc = BillingService()
    with pytest.raises(ManatPlanNotEligibleError):
        await svc.create_manat_request(
            session,
            telegram_id=503,
            username=None,
            first_name=None,
            last_name=None,
            plan_id=other_plan.id,
        )


async def test_create_manat_request_raises_when_no_agent_available(session, mock_amnezia_client):
    """No active agent with a usable phone at all -> NoAgentAvailableError,
    and no request row should be created."""
    plan = await _seed_plan(session)
    await session.commit()  # deliberately no agent seeded

    svc = BillingService()
    with pytest.raises(NoAgentAvailableError):
        await svc.create_manat_request(
            session,
            telegram_id=504,
            username=None,
            first_name=None,
            last_name=None,
            plan_id=plan.id,
        )


async def test_create_manat_request_skips_inactive_and_disabled(session, mock_amnezia_client):
    """An inactive agent and a disabled-phone agent must both be skipped by
    the assignment queue in favor of the one usable agent."""
    plan = await _seed_plan(session)
    await _seed_agent(session, telegram_id=9201, is_active=False)  # inactive agent
    disabled_agent, disabled_phone = await _seed_agent(session, telegram_id=9202, phone="+993 61 000001")
    agent_repo = AgentRepository(session)
    await agent_repo.set_phone_enabled(disabled_phone.id, False)
    good_agent, good_phone = await _seed_agent(session, telegram_id=9203, phone="+993 61 000002")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session,
        telegram_id=505,
        username=None,
        first_name=None,
        last_name=None,
        plan_id=plan.id,
    )
    await session.commit()

    assert req.assigned_agent_id == good_agent.id
    assert req.assigned_phone_id == good_phone.id


async def test_create_manat_request_skips_manually_disabled_agent(session, mock_amnezia_client):
    """ТЗ p.2/p.10: manually_disabled is an admin kill switch independent
    of is_active/schedule — such an agent must never be assigned."""
    plan = await _seed_plan(session)
    await _seed_agent(session, telegram_id=9204, manually_disabled=True)
    good_agent, good_phone = await _seed_agent(session, telegram_id=9205, phone="+993 61 000004")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=5051, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    assert req.assigned_agent_id == good_agent.id


async def test_create_manat_request_skips_agent_outside_work_schedule(session, mock_amnezia_client):
    """ТЗ p.2/p.10: an agent whose work schedule does not cover the
    current time must not receive new assignments, even while
    is_active and not manually_disabled."""
    plan = await _seed_plan(session)
    # A schedule that (barring a very unlucky test run at the boundary)
    # excludes "now": work_days limited to a single day that's virtually
    # never today, so this agent is off-shift regardless of wall-clock time.
    import datetime as dt
    today_iso_weekday = dt.datetime.now(dt.timezone.utc).isoweekday()
    off_day = 1 if today_iso_weekday != 1 else 2
    off_agent, off_phone = await _seed_agent(
        session, telegram_id=9206, phone="+993 61 000005", work_days=str(off_day),
        work_start_time="00:00", work_end_time="23:59",
    )
    on_agent, on_phone = await _seed_agent(session, telegram_id=9207, phone="+993 61 000006")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=5052, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    assert req.assigned_agent_id == on_agent.id


def test_agent_is_on_shift_handles_midnight_crossing_shift():
    """A shift like 22:00 -> 02:00 must be treated as covering the
    midnight boundary, not as an impossible/empty window."""
    from datetime import datetime, timezone

    agent = Agent(
        telegram_id=1, timezone="UTC", work_days=None,
        work_start_time="22:00", work_end_time="02:00",
    )
    at_23 = datetime(2026, 1, 5, 23, 0, tzinfo=timezone.utc)  # Monday 23:00
    at_01 = datetime(2026, 1, 6, 1, 0, tzinfo=timezone.utc)   # Tuesday 01:00
    at_12 = datetime(2026, 1, 5, 12, 0, tzinfo=timezone.utc)  # Monday noon

    assert BillingService._agent_is_on_shift(agent, now_utc=at_23) is True
    assert BillingService._agent_is_on_shift(agent, now_utc=at_01) is True
    assert BillingService._agent_is_on_shift(agent, now_utc=at_12) is False


def test_agent_is_on_shift_no_schedule_always_available():
    from datetime import datetime, timezone
    agent = Agent(telegram_id=1, timezone="UTC", work_days=None, work_start_time=None, work_end_time=None)
    assert BillingService._agent_is_on_shift(agent, now_utc=datetime(2026, 1, 5, 3, 0, tzinfo=timezone.utc)) is True


async def test_accept_manat_request_moves_to_awaiting_payment(session, mock_amnezia_client):
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9301)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=506, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    accepted = await svc.accept_manat_request(session, request_id=req.id, agent_id=9301)
    await session.commit()

    assert accepted.status == ManatRequestStatus.awaiting_payment
    assert accepted.accepted_at is not None


async def test_accept_manat_request_wrong_agent_raises(session, mock_amnezia_client):
    """An agent who does not currently hold the request cannot accept it —
    including a real, active agent who simply wasn't the one assigned."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9302)
    other_agent, other_phone = await _seed_agent(session, telegram_id=9303, phone="+993 61 000003")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=507, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    with pytest.raises(ManatRequestNotAssignedToAgentError):
        await svc.accept_manat_request(session, request_id=req.id, agent_id=9303)


async def test_decline_manat_request_reassigns_to_next_agent(session, mock_amnezia_client):
    plan = await _seed_plan(session)
    first_agent, first_phone = await _seed_agent(session, telegram_id=9401, phone="+993 61 000010")
    await session.commit()
    # Ensure first_agent is the one picked first (least-recently-assigned).
    second_agent, second_phone = await _seed_agent(session, telegram_id=9402, phone="+993 61 000011")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=508, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    original_agent_id = req.assigned_agent_id

    await svc.decline_manat_request(session, request_id=req.id, agent_id=(
        first_agent.telegram_id if original_agent_id == first_agent.id else second_agent.telegram_id
    ))
    await session.commit()

    req_repo = ManatRequestRepository(session)
    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.assigned
    assert refreshed.assigned_agent_id is not None
    assert refreshed.assigned_agent_id != original_agent_id
    # Reassignment must be recorded (ТЗ p.4/p.6/p.11 "история переназначений").
    assert refreshed.reassignment_history is not None
    assert "declined" in refreshed.reassignment_history


async def test_decline_manat_request_expires_when_no_other_agent(session, mock_amnezia_client):
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9501)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=509, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    await svc.decline_manat_request(session, request_id=req.id, agent_id=9501)
    await session.commit()

    req_repo = ManatRequestRepository(session)
    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.expired


async def test_report_payment_moves_to_admin_review_not_subscription(session, mock_amnezia_client):
    """
    Central guarantee of the whole rework (ТЗ p.5/p.6/p.7/p.14): an agent
    tapping "Деньги получены" must move the request to admin_review and
    must NEVER create a Payment/Order/Subscription or trigger provisioning
    by itself.
    """
    server = await _seed_server(session)
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9601)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=510, username=None, first_name="Reported", last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9601)
    await session.commit()

    reported = await svc.report_manat_payment(
        session, request_id=req.id, agent_id=9601, received=True
    )
    await session.commit()

    assert reported.status == ManatRequestStatus.admin_review
    assert reported.reported_by_agent_id == agent.id
    assert reported.reported_at is not None
    assert reported.payment_id is None

    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(510)
    result = await session.execute(select(Subscription).where(Subscription.user_id == user.id))
    assert result.scalars().all() == [], "agent report alone must never create a subscription"

    result = await session.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(10))
    logs = result.scalars().all()
    assert any(l.action == AuditAction.manat_agent_reported_payment for l in logs)


async def test_report_payment_before_accept_raises(session, mock_amnezia_client):
    """An agent cannot jump straight to reporting while the request is
    still `assigned` — accept must happen first."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9701)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=511, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.report_manat_payment(session, request_id=req.id, agent_id=9701, received=True)


async def test_report_money_not_received_reassigns(session, mock_amnezia_client):
    """"Деньги не получены" must re-queue to the next agent, exactly like
    a decline — never resolve the request itself."""
    plan = await _seed_plan(session)
    first_agent, first_phone = await _seed_agent(session, telegram_id=9711, phone="+993 61 000040")
    second_agent, second_phone = await _seed_agent(session, telegram_id=9712, phone="+993 61 000041")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=5111, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    holder_telegram_id = (
        first_agent.telegram_id if req.assigned_agent_id == first_agent.id else second_agent.telegram_id
    )
    await svc.accept_manat_request(session, request_id=req.id, agent_id=holder_telegram_id)
    await session.commit()

    await svc.report_manat_payment(session, request_id=req.id, agent_id=holder_telegram_id, received=False)
    await session.commit()

    req_repo = ManatRequestRepository(session)
    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.assigned
    assert refreshed.assigned_agent_id is not None


async def test_agent_cannot_approve_or_reject_directly(session, mock_amnezia_client):
    """
    ТЗ p.6/p.14: no agent-facing method may exist that resolves
    admin_review. BillingService simply has no such method — this test
    documents/locks that guarantee at the API surface level.
    """
    svc = BillingService()
    assert not hasattr(svc, "confirm_manat_request")
    assert not hasattr(svc, "resolve_manat_request")


async def test_admin_approve_provisions_active_subscription(session, mock_amnezia_client):
    """THE ONLY path that must ever create a Payment/Order/Subscription for
    a manat request (ТЗ p.6/p.14)."""
    server = await _seed_server(session)
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9601)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=510, username=None, first_name="Confirmed", last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9601)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req.id, agent_id=9601, received=True)
    await session.commit()

    sub = await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)
    await session.commit()

    assert sub.status == SubscriptionStatus.active
    assert sub.plan_id == plan.id

    req_repo = ManatRequestRepository(session)
    refreshed_req = await req_repo.get_by_id(req.id)
    assert refreshed_req.status == ManatRequestStatus.completed
    assert refreshed_req.resolved_by_admin_id == 42
    assert refreshed_req.payment_id is not None

    vc_repo = VpnClientRepository(session)
    vc = await vc_repo.get_by_subscription(sub.id)
    assert vc is not None
    assert vc.status == VpnClientStatus.active

    # Approving must record a transaction against the assigned phone for
    # the trailing-24h limit.
    result = await session.execute(
        select(ManatPaymentTransaction).where(ManatPaymentTransaction.agent_phone_id == phone.id)
    )
    txs = result.scalars().all()
    assert len(txs) == 1
    assert float(txs[0].amount_manat) == float(plan.price_manat)

    result = await session.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(10))
    logs = result.scalars().all()
    assert any(l.action == AuditAction.manat_admin_approved for l in logs)


async def test_admin_approve_before_admin_review_raises(session, mock_amnezia_client):
    """An admin cannot approve a request that hasn't reached admin_review
    yet (e.g. still awaiting_payment, agent hasn't reported)."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9701)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=511, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)


async def test_admin_reject_creates_no_subscription(session, mock_amnezia_client):
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9801)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=512, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9801)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req.id, agent_id=9801, received=True)
    await session.commit()

    await svc.reject_manat_request(
        session, request_id=req.id, admin_telegram_id=42, reason="no transfer seen"
    )
    await session.commit()

    req_repo = ManatRequestRepository(session)
    refreshed_req = await req_repo.get_by_id(req.id)
    assert refreshed_req.status == ManatRequestStatus.rejected
    assert refreshed_req.resolved_by_admin_id == 42
    assert refreshed_req.rejection_reason == "no transfer seen"
    assert refreshed_req.payment_id is None

    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(512)
    result = await session.execute(select(Subscription).where(Subscription.user_id == user.id))
    assert result.scalars().all() == []

    result = await session.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(10))
    logs = result.scalars().all()
    assert any(l.action == AuditAction.manat_admin_rejected for l in logs)


async def test_approving_already_resolved_request_raises(session, mock_amnezia_client):
    server = await _seed_server(session)
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=9901)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=513, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9901)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req.id, agent_id=9901, received=True)
    await session.commit()

    await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)
    await session.commit()

    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)

    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.reject_manat_request(session, request_id=req.id, admin_telegram_id=42)


async def test_second_admin_resolve_attempt_is_rejected_regardless_of_action(session, mock_amnezia_client):
    """
    Tests the actual protection mechanism
    (ManatRequestRepository.try_admin_resolve's conditional UPDATE ...
    WHERE status = 'admin_review') deterministically, rather than
    attempting to simulate real concurrent admins.

    A genuine concurrency test (two admins racing in real parallel time)
    was attempted here and removed: SQLite's StaticPool (used
    automatically for ':memory:' engines, including this test suite's)
    holds exactly one physical connection per engine object, so "two
    independent sessions" on the same engine are not actually concurrent
    at the connection level — confirmed empirically that two "racing"
    writers both report a successful commit with no error, but the result
    is a silent lost update rather than the row-level-locking behavior
    Postgres (production) gives for real. That makes SQLite unsuitable for
    testing the race itself; what CAN be tested honestly here is that the
    SQL condition providing the protection is correct — and that condition
    is what actually protects production on Postgres, independent of
    whether the calls happen to be physically concurrent or merely
    sequential. This directly covers ТЗ p.8/p.13: "одновременно
    подтвердить заявку двумя администраторами" / "повторное нажатие
    approve" must never double-provision.
    """
    server = await _seed_server(session)
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10001)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=514, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=10001)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req.id, agent_id=10001, received=True)
    await session.commit()

    # Admin #1 approves — must win.
    sub = await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)
    await session.commit()
    assert sub.status == SubscriptionStatus.active

    # Admin #2 rejects the same (now-resolved) request — must be rejected,
    # not silently accepted or silently ignored.
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.reject_manat_request(session, request_id=req.id, admin_telegram_id=43)

    # State must reflect the FIRST action only — completed, never
    # overwritten by the second attempt.
    req_repo = ManatRequestRepository(session)
    final_req = await req_repo.get_by_id(req.id)
    assert final_req.status == ManatRequestStatus.completed
    assert final_req.resolved_by_admin_id == 42

    # Exactly one subscription — the race protection must never allow a
    # resolved request to be provisioned twice.
    user_repo = UserRepository(session)
    user = await user_repo.get_by_telegram_id(514)
    result = await session.execute(select(Subscription).where(Subscription.user_id == user.id))
    assert len(result.scalars().all()) == 1

    # Retrying the SAME winning approve call again (e.g. a network retry)
    # must also be rejected, not re-provision (ТЗ p.13 "повторный
    # provisioning").
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=42)
    result = await session.execute(select(Subscription).where(Subscription.user_id == user.id))
    assert len(result.scalars().all()) == 1


async def test_try_admin_resolve_returns_false_when_already_resolved(session):
    """
    Narrower, repository-level test of the exact primitive the race
    protection depends on: try_admin_resolve()'s rowcount-based
    conditional UPDATE. First call against an admin_review request must
    return True (it won); an identical second call against the
    now-resolved request must return False.
    """
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10101)
    user_repo = UserRepository(session)
    user, _ = await user_repo.get_or_create(telegram_id=515)
    await session.flush()

    req_repo = ManatRequestRepository(session)
    req = await req_repo.create(
        user_id=user.id,
        plan_id=plan.id,
        mode="new",
        amount_manat=350.0,
        agent_phone_shown=phone.phone_number,
        assigned_agent_id=agent.id,
        assigned_phone_id=phone.id,
    )
    await req_repo.reassign(req.id, agent.id, phone.id, phone.phone_number)
    await session.commit()

    accepted = await req_repo.try_accept(req.id, agent.id)
    assert accepted is True
    await session.commit()

    reported = await req_repo.try_report_payment(req.id, agent.id, received=True)
    assert reported is True
    await session.commit()

    first = await req_repo.try_admin_resolve(req.id, admin_id=42, approve=True)
    assert first is True

    second = await req_repo.try_admin_resolve(req.id, admin_id=43, approve=False)
    assert second is False

    # The row must reflect the WINNING call (approved), not the losing one.
    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.approved
    assert refreshed.resolved_by_admin_id == 42


async def test_phone_daily_limit_excludes_agent_once_exhausted(session, mock_amnezia_client):
    """A phone at (or over) its trailing-24h daily limit must not be
    picked for a new request — the agent should be skipped entirely if
    that is their only phone."""
    plan = await _seed_plan(session)  # price_manat=350.0 — exactly the default limit
    agent, phone = await _seed_agent(session, telegram_id=10201)
    await session.commit()

    svc = BillingService()
    # First request/approve consumes the phone's entire daily limit.
    req1 = await svc.create_manat_request(
        session, telegram_id=516, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req1.id, agent_id=10201)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req1.id, agent_id=10201, received=True)
    await session.commit()
    await svc.approve_manat_request(session, request_id=req1.id, admin_telegram_id=42)
    await session.commit()

    # Second request has no agent left with capacity.
    with pytest.raises(NoAgentAvailableError):
        await svc.create_manat_request(
            session, telegram_id=517, username=None, first_name=None, last_name=None, plan_id=plan.id,
        )


async def test_phone_daily_limit_reserves_capacity_before_confirmation(session, mock_amnezia_client):
    """
    ТЗ p.9: the limit must account for already-reserved OPEN requests, not
    only confirmed transactions — otherwise two concurrent requests could
    both be assigned to the same phone and jointly exceed its limit before
    either is confirmed. This test creates one open (unresolved) request
    at the phone's full limit and checks a second request is refused
    assignment to that phone even though zero ManatPaymentTransaction rows
    exist yet.
    """
    plan = await _seed_plan(session)  # price_manat=350.0 — exactly the default limit
    agent, phone = await _seed_agent(session, telegram_id=10211)
    await session.commit()

    svc = BillingService()
    req1 = await svc.create_manat_request(
        session, telegram_id=5161, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    assert req1.assigned_phone_id == phone.id  # reserved, still unresolved

    with pytest.raises(NoAgentAvailableError):
        await svc.create_manat_request(
            session, telegram_id=5171, username=None, first_name=None, last_name=None, plan_id=plan.id,
        )


async def test_phone_with_custom_limit_is_respected(session, mock_amnezia_client):
    """ТЗ p.9: the daily limit is a configurable per-phone business
    setting, not a hardcoded constant."""
    plan = await _seed_plan(session)  # price_manat=350.0
    agent, phone = await _seed_agent(session, telegram_id=10221)
    agent_repo = AgentRepository(session)
    await agent_repo.set_phone_limit(phone.id, 1000.0)  # raise well above the plan price
    await session.commit()

    svc = BillingService()
    # Two requests at 350 each (700 total) must both fit under the 1000 limit.
    req1 = await svc.create_manat_request(
        session, telegram_id=5181, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    req2 = await svc.create_manat_request(
        session, telegram_id=5182, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    assert req1.assigned_phone_id == phone.id
    assert req2.assigned_phone_id == phone.id


async def test_phone_daily_limit_resets_after_24h_window(session, mock_amnezia_client):
    """A transaction older than 24h must no longer count against the
    phone's limit — this is a trailing window, not a calendar-day reset."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10301)
    await session.commit()

    agent_repo = AgentRepository(session)
    # Simulate a transaction from 25 hours ago that exhausted the limit.
    old_req_repo = ManatRequestRepository(session)
    user_repo = UserRepository(session)
    old_user, _ = await user_repo.get_or_create(telegram_id=518)
    await session.flush()
    old_req = await old_req_repo.create(
        user_id=old_user.id,
        plan_id=plan.id,
        mode="new",
        amount_manat=350.0,
        agent_phone_shown=phone.phone_number,
        assigned_agent_id=agent.id,
        assigned_phone_id=phone.id,
    )
    await session.flush()
    # Resolve the old request fully so it no longer counts as "open
    # reserved" — only the (backdated) confirmed transaction should matter.
    await old_req_repo.try_set_status(old_req.id, ManatRequestStatus.awaiting_agent, ManatRequestStatus.completed)
    tx = await agent_repo.record_transaction(
        agent_phone_id=phone.id, manat_request_id=old_req.id, amount_manat=350.0
    )
    # Backdate the transaction past the 24h window.
    tx.created_at = datetime.now(timezone.utc) - timedelta(hours=25)
    await session.commit()

    svc = BillingService()
    # A new request should succeed — the old transaction has aged out.
    req = await svc.create_manat_request(
        session, telegram_id=519, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    assert req.assigned_agent_id == agent.id


async def test_sweep_reassigns_stale_assigned_requests(session, mock_amnezia_client):
    """A request stuck in `assigned` past the 5-minute acceptance window
    must be re-assigned to another available agent."""
    plan = await _seed_plan(session)
    first_agent, first_phone = await _seed_agent(session, telegram_id=10401, phone="+993 61 000020")
    await session.commit()
    second_agent, second_phone = await _seed_agent(session, telegram_id=10402, phone="+993 61 000021")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=520, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    original_agent_id = req.assigned_agent_id

    # Backdate assigned_at past the acceptance window.
    req_repo = ManatRequestRepository(session)
    stale_req = await req_repo.get_by_id(req.id)
    stale_req.assigned_at = datetime.now(timezone.utc) - MANAT_AGENT_ACCEPT_WINDOW - timedelta(seconds=1)
    await session.commit()

    events = await svc.sweep_manat_timeouts(session)
    await session.commit()

    assert len(events) == 1
    assert events[0]["type"] == "reassigned"

    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.assigned
    assert refreshed.assigned_agent_id != original_agent_id


async def test_sweep_expires_assigned_when_no_other_candidate(session, mock_amnezia_client):
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10501)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=521, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()

    req_repo = ManatRequestRepository(session)
    stale_req = await req_repo.get_by_id(req.id)
    stale_req.assigned_at = datetime.now(timezone.utc) - MANAT_AGENT_ACCEPT_WINDOW - timedelta(seconds=1)
    await session.commit()

    events = await svc.sweep_manat_timeouts(session)
    await session.commit()

    assert len(events) == 1
    assert events[0]["type"] == "expired_no_agent"

    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.expired


async def test_sweep_expires_stale_awaiting_payment_unconditionally(session, mock_amnezia_client):
    """A request stuck in awaiting_payment past the 15-minute payment
    window must expire outright — never re-assigned, since it's the payer
    (not an agent) who missed the window."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10601)
    other_agent, other_phone = await _seed_agent(session, telegram_id=10602, phone="+993 61 000030")
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=522, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    accepted_agent_telegram_id = (
        agent.telegram_id if req.assigned_agent_id == agent.id else other_agent.telegram_id
    )
    await svc.accept_manat_request(session, request_id=req.id, agent_id=accepted_agent_telegram_id)
    await session.commit()

    req_repo = ManatRequestRepository(session)
    stale_req = await req_repo.get_by_id(req.id)
    stale_req.accepted_at = datetime.now(timezone.utc) - MANAT_PAYMENT_WINDOW - timedelta(seconds=1)
    await session.commit()

    events = await svc.sweep_manat_timeouts(session)
    await session.commit()

    assert len(events) == 1
    assert events[0]["type"] == "expired_payment_window"

    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.expired


async def test_sweep_does_not_touch_admin_review_requests(session, mock_amnezia_client):
    """ТЗ has no auto-expiry for admin review — once an agent has reported
    receipt, the request waits on the main admin, not on a timer. The
    sweep must never move an admin_review request to expired even if a
    long time has passed since it was created/reported."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(session, telegram_id=10611)
    await session.commit()

    svc = BillingService()
    req = await svc.create_manat_request(
        session, telegram_id=5221, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    await svc.accept_manat_request(session, request_id=req.id, agent_id=10611)
    await session.commit()
    await svc.report_manat_payment(session, request_id=req.id, agent_id=10611, received=True)
    await session.commit()

    req_repo = ManatRequestRepository(session)
    stale_req = await req_repo.get_by_id(req.id)
    stale_req.reported_at = datetime.now(timezone.utc) - timedelta(days=2)
    await session.commit()

    events = await svc.sweep_manat_timeouts(session)
    await session.commit()

    assert events == []
    refreshed = await req_repo.get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.admin_review


async def test_agent_toggles_own_phone(session):
    """An agent can enable/disable their own phone; a disabled phone must
    be excluded from assignment even while the agent itself is active."""
    agent, phone = await _seed_agent(session, telegram_id=10701)
    await session.commit()

    agent_repo = AgentRepository(session)
    await agent_repo.set_phone_enabled(phone.id, False)
    await session.commit()

    refreshed_phone = await agent_repo.get_phone_by_id(phone.id)
    assert refreshed_phone.is_enabled is False

    await agent_repo.set_phone_enabled(phone.id, True)
    await session.commit()
    refreshed_phone = await agent_repo.get_phone_by_id(phone.id)
    assert refreshed_phone.is_enabled is True


async def test_admin_can_add_and_remove_agent_phone(session):
    agent, first_phone = await _seed_agent(session, telegram_id=10801)
    await session.commit()

    agent_repo = AgentRepository(session)
    second_phone = await agent_repo.add_phone(agent.id, "+993 61 000099")
    await session.commit()

    phones = await agent_repo.get_phones_for_agent(agent.id)
    assert {p.id for p in phones} == {first_phone.id, second_phone.id}

    await agent_repo.remove_phone(second_phone.id)
    await session.commit()

    phones = await agent_repo.get_phones_for_agent(agent.id)
    assert {p.id for p in phones} == {first_phone.id}


async def test_admin_manual_disable_independent_of_schedule(session, mock_amnezia_client):
    """ТЗ p.2/p.10: manually_disabled must take effect even for an agent
    who is otherwise squarely inside their work schedule."""
    plan = await _seed_plan(session)
    agent, phone = await _seed_agent(
        session, telegram_id=10901, work_days=None, work_start_time=None, work_end_time=None,
    )
    await session.commit()

    agent_repo = AgentRepository(session)
    await agent_repo.set_manually_disabled(agent.id, True)
    await session.commit()

    svc = BillingService()
    with pytest.raises(NoAgentAvailableError):
        await svc.create_manat_request(
            session, telegram_id=523, username=None, first_name=None, last_name=None, plan_id=plan.id,
        )

    await agent_repo.set_manually_disabled(agent.id, False)
    await session.commit()
    req = await svc.create_manat_request(
        session, telegram_id=524, username=None, first_name=None, last_name=None, plan_id=plan.id,
    )
    await session.commit()
    assert req.assigned_agent_id == agent.id


# ---------------------------------------------------------------------------
# add_server: protocol auto-detection, no manual override, no fallback
# (ТЗ: "переход на актуальный AmneziaWG и устранение hardcode версии протокола")
# ---------------------------------------------------------------------------

async def test_add_server_resolves_protocol_via_api(session, mock_amnezia_client):
    """add_server must never accept a protocol argument from the caller —
    it is entirely determined by querying the new server's own amnezia-api
    instance (mocked here to confirm amneziawg3, matching a real,
    already-upgraded server)."""
    mock_amnezia_client.resolve_amneziawg_protocol.return_value = "amneziawg3"

    svc = BillingService()
    server = await svc.add_server(
        session,
        name="New Server",
        base_url="http://new-vpn:4001",
        api_key="new-key",
    )
    await session.commit()

    assert server.protocol == "amneziawg3"
    assert server.name == "New Server"
    mock_amnezia_client.resolve_amneziawg_protocol.assert_called_once()

    # Confirm it's actually persisted, not just returned in memory.
    server_repo = VpnServerRepository(session)
    fetched = await server_repo.get_by_id(server.id)
    assert fetched.protocol == "amneziawg3"


async def test_add_server_rejects_server_on_legacy_protocol_only(session, mock_amnezia_client):
    """A server that hasn't been upgraded (still only amneziawg/amneziawg2)
    must be REJECTED outright — no server row created, no silent fallback
    to the old protocol. This is the central guarantee of ТЗ point 6/8:
    "не принимать amneziawg2 как fallback"."""
    mock_amnezia_client.resolve_amneziawg_protocol.side_effect = AmneziaProtocolNotSupportedError(
        "Server does not support amneziawg3 (advertised protocols: ['amneziawg'])"
    )

    svc = BillingService()
    with pytest.raises(AmneziaProtocolNotSupportedError):
        await svc.add_server(
            session,
            name="Old Server",
            base_url="http://old-vpn:4001",
            api_key="old-key",
        )
    await session.commit()

    from sqlalchemy import select
    from models.models import VpnServer
    result = await session.execute(select(VpnServer).where(VpnServer.name == "Old Server"))
    assert result.scalar_one_or_none() is None, "no server row should be created on rejection"


async def test_add_server_raises_when_unreachable(session, mock_amnezia_client):
    """A server whose amnezia-api can't be reached at all (network error)
    must raise ServerUnreachableError — distinct from
    AmneziaProtocolNotSupportedError, since the fix is different (check the
    URL/network vs. upgrade AmneziaWG). No server row is created either
    way."""
    mock_amnezia_client.resolve_amneziawg_protocol.side_effect = AmneziaConnectionError(
        "Connection refused"
    )

    svc = BillingService()
    with pytest.raises(ServerUnreachableError):
        await svc.add_server(
            session,
            name="Unreachable Server",
            base_url="http://unreachable-vpn:4001",
            api_key="key",
        )
    await session.commit()

    from sqlalchemy import select
    from models.models import VpnServer
    result = await session.execute(select(VpnServer).where(VpnServer.name == "Unreachable Server"))
    assert result.scalar_one_or_none() is None


async def test_provisioning_persists_actual_protocol_returned_by_api(session, mock_amnezia_client):
    """The VpnClient row must store whatever protocol amnezia-api actually
    confirmed for THAT client (CreateClientResponse.client.protocol), not
    the server's own VpnServer.protocol re-read at creation time — these
    happen to match in the common case, but the client's own confirmed
    value is the source of truth for future enable/disable/delete calls
    (ТЗ point 4: "использовать фактический protocol, возвращённый/
    подтверждённый Amnezia API")."""
    server = await _seed_server(session)  # protocol="amneziawg3"
    plan = await _seed_plan(session)
    await session.commit()

    svc = BillingService()
    sub = await svc.handle_payment(
        session,
        telegram_id=9999001,
        username=None,
        first_name=None,
        last_name=None,
        provider=PaymentProvider.stars,
        external_id="protocol-test-1",
        amount=plan.price_stars,
        currency="XTR",
        plan_id=plan.id,
        mode="new",
    )
    await session.commit()

    vc_repo = VpnClientRepository(session)
    vc = await vc_repo.get_by_subscription(sub.id)
    assert vc is not None
    assert vc.protocol == "amneziawg3", (
        "VpnClient.protocol must be the protocol amnezia-api's "
        "CreateClientResponse actually returned for this client"
    )
