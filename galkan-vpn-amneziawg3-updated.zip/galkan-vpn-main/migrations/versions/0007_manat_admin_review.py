"""Rework manat payment approval per ТЗ "новая архитектура оплаты манатами
через агентов": an agent may only report receipt (payment_reported); only
the main admin's approval (admin_review -> approved) may create a
Payment/Order/Subscription and trigger VPN provisioning.

Changes:
  - manat_payment_requests: replace the 6-value status check with the full
    new lifecycle (created, awaiting_agent, assigned, awaiting_payment,
    payment_reported, admin_review, approved, provisioning, completed,
    declined, expired, rejected, cancelled, provisioning_failed, plus the
    legacy pending/confirmed values so old app-level enum members still
    validate even though this is a pre-launch, no-existing-rows rework).
  - manat_payment_requests: drop resolved_by_agent_id (from 0004, which
    conflated "agent reported" and "resolved" into one column/actor) and
    add two explicit columns in its place: reported_by_agent_id (agent's
    claim) and resolved_by_admin_id (admin's final decision), plus
    reported_at, rejection_reason, reassignment_history.
  - agents: add timezone, work_days, work_start_time, work_end_time,
    manually_disabled (ТЗ p.2/p.10 work schedule + independent kill
    switch).
  - agent_phones: add daily_limit_manat, a configurable per-phone business
    setting replacing the hardcoded 350 TMT constant (ТЗ p.9).

Revision ID: 0007_manat_admin_review
Revises: 0006_drop_protocol_default
Create Date: 2026-09-25
"""
from alembic import op
import sqlalchemy as sa

revision = "0007_manat_admin_review"
down_revision = "0006_drop_protocol_default"
branch_labels = None
depends_on = None


NEW_STATUS_VALUES = (
    "created", "awaiting_agent", "assigned", "awaiting_payment",
    "payment_reported", "admin_review", "approved", "provisioning",
    "completed", "declined", "expired", "rejected", "cancelled",
    "provisioning_failed",
    # legacy values kept valid so any pre-existing row (none expected —
    # pre-launch project) still passes the check.
    "pending", "confirmed",
)

OLD_STATUS_VALUES = (
    "awaiting_agent", "awaiting_payment", "confirmed", "rejected", "expired", "pending",
)


def upgrade() -> None:
    # --- agents: work schedule + independent manual kill switch (ТЗ p.2/p.10) ---
    op.add_column(
        "agents",
        sa.Column("timezone", sa.String(length=64), nullable=False, server_default="Asia/Ashgabat"),
    )
    op.add_column("agents", sa.Column("work_days", sa.String(length=32), nullable=True))
    op.add_column("agents", sa.Column("work_start_time", sa.String(length=5), nullable=True))
    op.add_column("agents", sa.Column("work_end_time", sa.String(length=5), nullable=True))
    op.add_column(
        "agents",
        sa.Column("manually_disabled", sa.Boolean(), nullable=False, server_default=sa.false()),
    )

    # --- agent_phones: configurable per-phone daily limit (ТЗ p.9) ---
    op.add_column(
        "agent_phones",
        sa.Column("daily_limit_manat", sa.Numeric(14, 2), nullable=True, server_default="350"),
    )

    # --- manat_payment_requests: new lifecycle + admin-review columns ---
    op.drop_constraint(
        "ck_manat_payment_requests_status", "manat_payment_requests", type_="check"
    )
    # resolved_by_agent_id (from 0004) conflated "agent reported" and
    # "resolved" into one column/one actor. Replaced by the two explicit
    # columns below (agent's claim vs. admin's final decision) — see ТЗ
    # p.6/p.14, the whole point of this rework is separating those roles.
    op.drop_column("manat_payment_requests", "resolved_by_agent_id")
    op.add_column(
        "manat_payment_requests",
        sa.Column("reported_by_agent_id", sa.BigInteger(), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("reported_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("resolved_by_admin_id", sa.BigInteger(), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("rejection_reason", sa.String(length=256), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("reassignment_history", sa.Text(), nullable=True),
    )
    op.alter_column(
        "manat_payment_requests", "status", server_default="awaiting_agent"
    )
    op.create_check_constraint(
        "ck_manat_payment_requests_status",
        "manat_payment_requests",
        "status IN (" + ", ".join(f"'{v}'" for v in NEW_STATUS_VALUES) + ")",
    )


def downgrade() -> None:
    op.drop_constraint(
        "ck_manat_payment_requests_status", "manat_payment_requests", type_="check"
    )
    op.alter_column(
        "manat_payment_requests", "status", server_default="awaiting_agent"
    )
    op.create_check_constraint(
        "ck_manat_payment_requests_status",
        "manat_payment_requests",
        "status IN (" + ", ".join(f"'{v}'" for v in OLD_STATUS_VALUES) + ")",
    )
    op.drop_column("manat_payment_requests", "reassignment_history")
    op.drop_column("manat_payment_requests", "rejection_reason")
    op.drop_column("manat_payment_requests", "resolved_at")
    op.drop_column("manat_payment_requests", "resolved_by_admin_id")
    op.drop_column("manat_payment_requests", "reported_at")
    op.drop_column("manat_payment_requests", "reported_by_agent_id")
    op.add_column(
        "manat_payment_requests",
        sa.Column("resolved_by_agent_id", sa.BigInteger(), nullable=True),
    )

    op.drop_column("agent_phones", "daily_limit_manat")

    op.drop_column("agents", "manually_disabled")
    op.drop_column("agents", "work_end_time")
    op.drop_column("agents", "work_start_time")
    op.drop_column("agents", "work_days")
    op.drop_column("agents", "timezone")
