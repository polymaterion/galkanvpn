from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.models import (
    Agent,
    AgentPhone,
    AuditAction,
    AuditLog,
    ManatPaymentRequest,
    ManatPaymentTransaction,
    ManatRequestStatus,
    Order,
    OrderStatus,
    Payment,
    PaymentProvider,
    PaymentStatus,
    Plan,
    ProcessedEvent,
    VpnClient,
    VpnClientStatus,
)


class PlanRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_active_plan(self) -> Optional[Plan]:
        result = await self.session.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.is_trial == False)
            .order_by(Plan.id)
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_trial_plan(self) -> Optional[Plan]:
        result = await self.session.execute(
            select(Plan).where(Plan.is_trial == True).limit(1)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, plan_id: int) -> Optional[Plan]:
        result = await self.session.execute(select(Plan).where(Plan.id == plan_id))
        return result.scalar_one_or_none()

    async def get_all(self) -> list[Plan]:
        result = await self.session.execute(select(Plan))
        return list(result.scalars().all())

    async def get_all_active(self) -> list[Plan]:
        """All active, non-trial plans — for the tariff selection screen.
        Sorted by duration so 1/3/6-month options display in a predictable
        order regardless of insertion order in the DB."""
        result = await self.session.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.is_trial == False)
            .order_by(Plan.duration_days)
        )
        return list(result.scalars().all())


class OrderRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, user_id: int, plan_id: int) -> Order:
        order = Order(user_id=user_id, plan_id=plan_id, status=OrderStatus.pending)
        self.session.add(order)
        await self.session.flush()
        return order

    async def get_by_id(self, order_id: int) -> Optional[Order]:
        result = await self.session.execute(select(Order).where(Order.id == order_id))
        return result.scalar_one_or_none()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[Order]:
        result = await self.session.execute(
            select(Order).offset(offset).limit(limit).order_by(Order.id.desc())
        )
        return list(result.scalars().all())


class PaymentRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_external_id(
        self, provider: PaymentProvider, external_id: str
    ) -> Optional[Payment]:
        result = await self.session.execute(
            select(Payment).where(
                Payment.provider == provider,
                Payment.external_id == external_id,
            )
        )
        return result.scalar_one_or_none()

    async def create(
        self,
        user_id: int,
        order_id: int,
        provider: PaymentProvider,
        external_id: str,
        amount: float,
        currency: str,
    ) -> Payment:
        payment = Payment(
            user_id=user_id,
            order_id=order_id,
            provider=provider,
            external_id=external_id,
            status=PaymentStatus.pending,
            amount=amount,
            currency=currency,
        )
        self.session.add(payment)
        await self.session.flush()
        return payment

    async def mark_paid(self, payment: Payment) -> None:
        payment.status = PaymentStatus.paid
        payment.paid_at = datetime.now(timezone.utc)

    async def link_subscription(self, payment: Payment, subscription_id: int) -> None:
        payment.subscription_id = subscription_id
        await self.session.flush()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[Payment]:
        result = await self.session.execute(
            select(Payment).offset(offset).limit(limit).order_by(Payment.id.desc())
        )
        return list(result.scalars().all())


class ManatRequestRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(
        self,
        user_id: int,
        plan_id: int,
        mode: str,
        amount_manat: float,
        agent_phone_shown: str,
        assigned_agent_id: Optional[int] = None,
        assigned_phone_id: Optional[int] = None,
        target_subscription_id: Optional[int] = None,
    ) -> ManatPaymentRequest:
        now = datetime.now(timezone.utc)
        req = ManatPaymentRequest(
            user_id=user_id,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target_subscription_id,
            amount_manat=amount_manat,
            agent_phone_shown=agent_phone_shown,
            status=ManatRequestStatus.awaiting_agent,
            assigned_agent_id=assigned_agent_id,
            assigned_phone_id=assigned_phone_id,
            assigned_at=now if assigned_agent_id else None,
        )
        self.session.add(req)
        await self.session.flush()
        return req

    async def get_by_id(self, request_id: int) -> Optional[ManatPaymentRequest]:
        result = await self.session.execute(
            select(ManatPaymentRequest).where(ManatPaymentRequest.id == request_id)
        )
        return result.scalar_one_or_none()

    async def try_accept(self, request_id: int, agent_id: int) -> bool:
        """
        Atomically moves this request from awaiting_agent to awaiting_payment
        — but ONLY if it is still awaiting_agent AND still assigned to this
        exact agent_id. Unlike the old "any agent may act" model, a request
        is held by exactly one agent at a time (see BillingService's
        assignment queue), so the race this guards against is the 5-minute
        timeout sweep re-assigning the request to someone else in the same
        instant this agent taps "Ready". A single conditional UPDATE avoids
        the SELECT-then-UPDATE TOCTOU gap. Returns True only if this call
        won.
        """
        result = await self.session.execute(
            update(ManatPaymentRequest)
            .where(
                ManatPaymentRequest.id == request_id,
                ManatPaymentRequest.status == ManatRequestStatus.awaiting_agent,
                ManatPaymentRequest.assigned_agent_id == agent_id,
            )
            .values(
                status=ManatRequestStatus.awaiting_payment,
                accepted_at=datetime.now(timezone.utc),
            )
        )
        won = result.rowcount == 1
        if won:
            req = await self.session.get(ManatPaymentRequest, request_id)
            if req is not None:
                req.status = ManatRequestStatus.awaiting_payment
        return won

    async def try_decline(self, request_id: int, agent_id: int) -> bool:
        """
        Agent explicitly taps "Can't accept" during the awaiting_agent
        window. Moves the request back to awaiting_agent with no
        assigned_agent_id, so BillingService's assignment step picks it up
        as if newly created (goes to the next candidate in the queue). Same
        conditional-UPDATE race guard as try_accept.
        """
        result = await self.session.execute(
            update(ManatPaymentRequest)
            .where(
                ManatPaymentRequest.id == request_id,
                ManatPaymentRequest.status == ManatRequestStatus.awaiting_agent,
                ManatPaymentRequest.assigned_agent_id == agent_id,
            )
            .values(assigned_agent_id=None, assigned_phone_id=None, assigned_at=None)
        )
        won = result.rowcount == 1
        if won:
            req = await self.session.get(ManatPaymentRequest, request_id)
            if req is not None:
                req.assigned_agent_id = None
                req.assigned_phone_id = None
                req.assigned_at = None
        return won

    async def reassign(
        self, request_id: int, agent_id: int, phone_id: int, phone_number: str
    ) -> None:
        """Assigns (or re-assigns, on timeout escalation) this request to a
        new agent/phone, resetting the 5-minute acceptance clock."""
        req = await self.session.get(ManatPaymentRequest, request_id)
        if req is None:
            return
        req.assigned_agent_id = agent_id
        req.assigned_phone_id = phone_id
        req.agent_phone_shown = phone_number
        req.assigned_at = datetime.now(timezone.utc)
        await self.session.flush()

    async def try_resolve(
        self, request_id: int, agent_id: int, new_status: ManatRequestStatus
    ) -> bool:
        """
        Atomically claims this request for `agent_id`, moving it from
        awaiting_payment to `new_status` (confirmed or rejected) — but only
        if it is still awaiting_payment and still held by this agent. Used
        for the "Money received" / "Money not received" step, after the
        agent has already accepted. Same conditional-UPDATE race guard as
        try_accept, this time against the 15-minute payment-window timeout
        sweep expiring the request out from under the agent.
        """
        result = await self.session.execute(
            update(ManatPaymentRequest)
            .where(
                ManatPaymentRequest.id == request_id,
                ManatPaymentRequest.status == ManatRequestStatus.awaiting_payment,
                ManatPaymentRequest.assigned_agent_id == agent_id,
            )
            .values(
                status=new_status,
                resolved_by_agent_id=agent_id,
                resolved_at=datetime.now(timezone.utc),
            )
        )
        won = result.rowcount == 1
        if won:
            # Raw UPDATE bypasses the ORM — if the caller already holds this
            # row in this session's identity map, sync it now so a
            # subsequent read of request.status in the same transaction
            # doesn't see the stale pre-update value. session.get() checks
            # the identity map first and issues no SQL if it's already
            # loaded.
            req = await self.session.get(ManatPaymentRequest, request_id)
            if req is not None:
                req.status = new_status
                req.resolved_by_agent_id = agent_id
        return won

    async def try_expire(
        self, request_id: int, from_status: ManatRequestStatus
    ) -> bool:
        """Used only by the timeout sweep to move a request to `expired`,
        guarded on it still being in `from_status` so a sweep tick racing
        against an agent's tap can't clobber a just-made decision."""
        result = await self.session.execute(
            update(ManatPaymentRequest)
            .where(
                ManatPaymentRequest.id == request_id,
                ManatPaymentRequest.status == from_status,
            )
            .values(status=ManatRequestStatus.expired, resolved_at=datetime.now(timezone.utc))
        )
        return result.rowcount == 1

    async def get_stale_awaiting_agent(self, older_than: datetime) -> list[ManatPaymentRequest]:
        """Requests still awaiting_agent whose 5-minute acceptance window
        has elapsed (assigned_at older than `older_than`) — candidates for
        either re-assignment to the next agent or expiry if no agent is
        left."""
        result = await self.session.execute(
            select(ManatPaymentRequest).where(
                ManatPaymentRequest.status == ManatRequestStatus.awaiting_agent,
                ManatPaymentRequest.assigned_at.isnot(None),
                ManatPaymentRequest.assigned_at < older_than,
            )
        )
        return list(result.scalars().all())

    async def get_stale_awaiting_payment(self, older_than: datetime) -> list[ManatPaymentRequest]:
        """Requests still awaiting_payment whose 15-minute payment window
        has elapsed (accepted_at older than `older_than`) — always expired,
        never re-assigned (the payer, not an agent, missed the window)."""
        result = await self.session.execute(
            select(ManatPaymentRequest).where(
                ManatPaymentRequest.status == ManatRequestStatus.awaiting_payment,
                ManatPaymentRequest.accepted_at.isnot(None),
                ManatPaymentRequest.accepted_at < older_than,
            )
        )
        return list(result.scalars().all())

    async def link_payment(self, request: ManatPaymentRequest, payment_id: int) -> None:
        request.payment_id = payment_id
        await self.session.flush()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[ManatPaymentRequest]:
        result = await self.session.execute(
            select(ManatPaymentRequest)
            .offset(offset)
            .limit(limit)
            .order_by(ManatPaymentRequest.id.desc())
        )
        return list(result.scalars().all())


class AgentRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[Agent]:
        result = await self.session.execute(
            select(Agent).where(Agent.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, agent_id: int) -> Optional[Agent]:
        result = await self.session.execute(select(Agent).where(Agent.id == agent_id))
        return result.scalar_one_or_none()

    async def create(self, telegram_id: int, display_name: Optional[str] = None) -> Agent:
        agent = Agent(telegram_id=telegram_id, display_name=display_name, is_active=True)
        self.session.add(agent)
        await self.session.flush()
        return agent

    async def set_active(self, agent_id: int, is_active: bool) -> None:
        agent = await self.session.get(Agent, agent_id)
        if agent is not None:
            agent.is_active = is_active
            await self.session.flush()

    async def get_all(self) -> list[Agent]:
        result = await self.session.execute(select(Agent).order_by(Agent.id))
        return list(result.scalars().all())

    async def get_active_candidates(self, exclude_agent_id: Optional[int] = None) -> list[Agent]:
        """Active agents ordered for round-robin assignment: the one
        assigned longest ago (or never assigned) first. Does not filter by
        phone availability here — BillingService checks each candidate's
        phones in order and moves to the next if none are usable, since
        that check needs the trailing-24h transaction sums this repository
        doesn't compute."""
        stmt = select(Agent).where(Agent.is_active == True)
        if exclude_agent_id is not None:
            stmt = stmt.where(Agent.id != exclude_agent_id)
        stmt = stmt.order_by(Agent.last_assigned_at.asc().nulls_first())
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def mark_assigned(self, agent_id: int) -> None:
        agent = await self.session.get(Agent, agent_id)
        if agent is not None:
            agent.last_assigned_at = datetime.now(timezone.utc)
            await self.session.flush()

    async def add_phone(self, agent_id: int, phone_number: str) -> AgentPhone:
        phone = AgentPhone(agent_id=agent_id, phone_number=phone_number, is_enabled=True)
        self.session.add(phone)
        await self.session.flush()
        return phone

    async def remove_phone(self, phone_id: int) -> None:
        phone = await self.session.get(AgentPhone, phone_id)
        if phone is not None:
            await self.session.delete(phone)
            await self.session.flush()

    async def set_phone_enabled(self, phone_id: int, is_enabled: bool) -> None:
        phone = await self.session.get(AgentPhone, phone_id)
        if phone is not None:
            phone.is_enabled = is_enabled
            await self.session.flush()

    async def get_phone_by_id(self, phone_id: int) -> Optional[AgentPhone]:
        result = await self.session.execute(
            select(AgentPhone).where(AgentPhone.id == phone_id)
        )
        return result.scalar_one_or_none()

    async def get_phones_for_agent(self, agent_id: int) -> list[AgentPhone]:
        result = await self.session.execute(
            select(AgentPhone).where(AgentPhone.agent_id == agent_id).order_by(AgentPhone.id)
        )
        return list(result.scalars().all())

    async def get_phone_received_since(self, phone_id: int, since: datetime) -> float:
        """Sum of amount_manat across confirmed transactions on this phone
        within the trailing window starting at `since` — the basis for the
        350 TMT / 24h limit check. Returns 0.0 if there are none."""
        result = await self.session.execute(
            select(func.coalesce(func.sum(ManatPaymentTransaction.amount_manat), 0)).where(
                ManatPaymentTransaction.agent_phone_id == phone_id,
                ManatPaymentTransaction.created_at >= since,
            )
        )
        return float(result.scalar_one())

    async def record_transaction(
        self, agent_phone_id: int, manat_request_id: int, amount_manat: float
    ) -> ManatPaymentTransaction:
        tx = ManatPaymentTransaction(
            agent_phone_id=agent_phone_id,
            manat_request_id=manat_request_id,
            amount_manat=amount_manat,
        )
        self.session.add(tx)
        await self.session.flush()
        return tx


class VpnClientRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(
        self,
        subscription_id: int,
        server_id: int,
        amnezia_client_id: str,
        client_name: str,
        config_url: Optional[str],
        protocol: str = "amneziawg2",
    ) -> VpnClient:
        import secrets
        vc = VpnClient(
            subscription_id=subscription_id,
            server_id=server_id,
            amnezia_client_id=amnezia_client_id,
            client_name=client_name,
            config_url=config_url,
            status=VpnClientStatus.active,
            protocol=protocol,
            public_token=secrets.token_hex(24),  # 48 hex chars, unguessable
        )
        self.session.add(vc)
        await self.session.flush()
        return vc

    async def get_by_subscription(self, subscription_id: int) -> Optional[VpnClient]:
        result = await self.session.execute(
            select(VpnClient).where(VpnClient.subscription_id == subscription_id)
        )
        return result.scalar_one_or_none()

    async def get_by_public_token(self, token: str) -> Optional[VpnClient]:
        result = await self.session.execute(
            select(VpnClient).where(VpnClient.public_token == token)
        )
        return result.scalar_one_or_none()


class ProcessedEventRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def exists(self, event_id: str) -> bool:
        result = await self.session.execute(
            select(ProcessedEvent).where(ProcessedEvent.event_id == event_id)
        )
        return result.scalar_one_or_none() is not None

    async def mark(self, event_id: str) -> None:
        evt = ProcessedEvent(event_id=event_id)
        self.session.add(evt)
        await self.session.flush()


class AuditRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def log(
        self,
        action: AuditAction,
        user_id: Optional[int] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[int] = None,
        details: Optional[str] = None,
    ) -> None:
        log = AuditLog(
            action=action,
            user_id=user_id,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
        )
        self.session.add(log)
        await self.session.flush()
