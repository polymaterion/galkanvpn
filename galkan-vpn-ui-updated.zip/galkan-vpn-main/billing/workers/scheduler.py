"""
Background worker: runs on a schedule to:
  - disable expired subscriptions
  - retry failed provisioning
  - sweep manat payment requests past their timeout windows (5-minute agent
    acceptance, 15-minute payment) and notify the affected users
"""
import asyncio
import logging
import os

import httpx
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from billing.database import AsyncSessionLocal
from billing.repositories.user_repo import UserRepository
from billing.services.billing_service import BillingService
from bot.locales import t

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("worker")

service = BillingService()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_API_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"


async def task_disable_expired():
    try:
        count = await service.disable_expired_subscriptions()
        if count:
            logger.info("[worker] Disabled %d expired subscriptions", count)
    except Exception as e:
        logger.error("[worker] disable_expired error: %s", e, exc_info=True)


async def task_retry_provisioning():
    try:
        count = await service.retry_pending_provisioning()
        if count:
            logger.info("[worker] Retried provisioning for %d subscriptions", count)
    except Exception as e:
        logger.error("[worker] retry_provisioning error: %s", e, exc_info=True)


async def _send_telegram_message(
    client: httpx.AsyncClient, chat_id: int, text: str, reply_markup: dict | None = None
) -> None:
    """
    Raw Telegram Bot API call via httpx rather than aiogram — the worker
    process runs Dockerfile.billing, whose requirements.billing.txt does
    not include aiogram (that's a bot-only dependency; see
    requirements.bot.txt). Pulling in the full aiogram stack just to send
    a handful of plain notifications would add a heavy, otherwise-unused
    dependency to the billing image, so this hits Telegram's HTTP API
    directly with the httpx client billing already depends on. Failures
    (blocked bot, deleted chat, etc.) are logged and swallowed — one
    unreachable user must not stop the rest of the sweep from completing.
    """
    payload: dict = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    try:
        resp = await client.post(f"{TELEGRAM_API_BASE}/sendMessage", json=payload)
        if resp.status_code != 200:
            logger.warning(
                "[worker] Telegram sendMessage to %s failed: %s %s",
                chat_id, resp.status_code, resp.text,
            )
    except Exception as e:
        logger.warning("[worker] Telegram sendMessage to %s raised: %s", chat_id, e)


def _accept_keyboard_dict(request_id: int, lang: str) -> dict:
    """
    Plain-dict inline keyboard for Telegram's raw HTTP API, mirroring
    bot/keyboards/keyboards.py's manat_agent_accept_keyboard — but built
    without importing aiogram, since the worker runs Dockerfile.billing
    and requirements.billing.txt deliberately does not include aiogram
    (see _send_telegram_message's docstring for why). Keep the button
    labels and callback_data format in sync with that function by hand;
    both encode the same "manat_ready:<id>" / "manat_notready:<id>"
    callback contract the bot's handlers already parse.
    """
    return {
        "inline_keyboard": [[
            {"text": t("manat_agent_ready_btn", lang), "callback_data": f"manat_ready:{request_id}"},
            {"text": t("manat_agent_not_ready_btn", lang), "callback_data": f"manat_notready:{request_id}"},
        ]]
    }


async def task_sweep_manat_timeouts():
    """
    Runs BillingService.sweep_manat_timeouts_job() and notifies whoever is
    affected by each outcome:
      - reassigned: payer told their request moved to a new agent; the new
        agent gets the same "new request" prompt the original assignment
        would have sent (see cb_pay_manat in bot/handlers/main_handlers.py).
      - expired_no_agent / expired_payment_window: payer told the request
        is closed.
    Runs frequently (every 30s — see main()) since both timeout windows are
    short (5 and 15 minutes) and a slow sweep interval would eat into the
    time actually available to agents/payers.
    """
    if not TELEGRAM_TOKEN:
        logger.warning("[worker] TELEGRAM_TOKEN not set, skipping manat timeout sweep notifications")
        return
    try:
        events = await service.sweep_manat_timeouts_job()
    except Exception as e:
        logger.error("[worker] sweep_manat_timeouts error: %s", e, exc_info=True)
        return

    if not events:
        return
    logger.info("[worker] Manat timeout sweep: %d event(s)", len(events))

    async with AsyncSessionLocal() as session:
        user_repo = UserRepository(session)

        async def lang_for(telegram_id: int | None) -> str:
            if not telegram_id:
                return "ru"
            user = await user_repo.get_by_telegram_id(telegram_id)
            return (user.language if user and user.language else "ru")

        async with httpx.AsyncClient(timeout=10.0) as client:
            for event in events:
                payer_id = event.get("payer_telegram_id")
                if event["type"] == "reassigned":
                    payer_lang = await lang_for(payer_id)
                    if payer_id:
                        await _send_telegram_message(
                            client, payer_id, t("manat_reassigned_to_payer", payer_lang)
                        )
                    new_agent_id = event.get("new_agent_telegram_id")
                    if new_agent_id:
                        agent_lang = await lang_for(new_agent_id)
                        payer_label = str(payer_id) if payer_id else "?"
                        await _send_telegram_message(
                            client,
                            new_agent_id,
                            t(
                                "manat_agent_new_request",
                                agent_lang,
                                request_id=event["request_id"],
                                payer=payer_label,
                                amount=event["amount_manat"],
                            ),
                            reply_markup=_accept_keyboard_dict(event["request_id"], agent_lang),
                        )
                elif event["type"] == "expired_no_agent":
                    if payer_id:
                        payer_lang = await lang_for(payer_id)
                        await _send_telegram_message(
                            client, payer_id, t("manat_expired_no_agent", payer_lang)
                        )
                elif event["type"] == "expired_payment_window":
                    if payer_id:
                        payer_lang = await lang_for(payer_id)
                        await _send_telegram_message(
                            client, payer_id, t("manat_expired_payment_window", payer_lang)
                        )


def main():
    # AsyncIOScheduler.start() calls asyncio.get_event_loop() internally if
    # no loop is passed explicitly (see apscheduler's own source) — and that
    # call already emits DeprecationWarning with no loop running in the main
    # thread on Python 3.12, with no guarantee it keeps working in future
    # versions. Create the loop explicitly once and hand it to both the
    # scheduler and this function's own run_forever(), so neither relies on
    # the deprecated "current loop" lookup.
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    scheduler = AsyncIOScheduler(event_loop=loop, timezone="UTC")

    scheduler.add_job(
        task_disable_expired,
        trigger=IntervalTrigger(minutes=5),
        id="disable_expired",
        replace_existing=True,
        misfire_grace_time=60,
    )
    scheduler.add_job(
        task_retry_provisioning,
        trigger=IntervalTrigger(minutes=3),
        id="retry_provisioning",
        replace_existing=True,
        misfire_grace_time=60,
    )
    scheduler.add_job(
        task_sweep_manat_timeouts,
        trigger=IntervalTrigger(seconds=30),
        id="sweep_manat_timeouts",
        replace_existing=True,
        misfire_grace_time=30,
    )

    scheduler.start()
    logger.info("Worker started. Jobs: %s", [j.id for j in scheduler.get_jobs()])

    try:
        loop.run_forever()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Worker shutting down")
        scheduler.shutdown()


if __name__ == "__main__":
    main()
