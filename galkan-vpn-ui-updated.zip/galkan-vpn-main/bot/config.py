"""
Bot configuration loaded from ENV.
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings


class BotSettings(BaseSettings):
    TELEGRAM_TOKEN: str
    BILLING_BASE_URL: str = "http://billing:8000"
    BILLING_SECRET_KEY: str = ""

    ADMIN_IDS: str = ""  # comma-separated

    CRYPTOPAY_TOKEN: str = ""
    CRYPTOPAY_NETWORK: str = "mainnet"

    # Display-only — the actual trial length lives in the trial Plan row
    # (billing/seeds/seed.py reads TRIAL_DURATION_DAYS at seed time to set
    # Plan.duration_days). Keep this in sync with that same env var so the
    # "N-day trial" message the bot shows matches what's actually granted.
    TRIAL_DURATION_DAYS: int = 3

    SUPPORT_LINK: str = "https://t.me/support"

    # Info section URL buttons (bot/handlers/main_handlers.py's info screen).
    PRIVACY_POLICY_LINK: str = "https://telegra.ph/Politika-konfidencialnosti-09-12-100"
    TERMS_OF_SERVICE_LINK: str = "https://telegra.ph/Polzovatelskoe-soglashenie-09-12-61"
    CHANNEL_LINK: str = "https://t.me/GalkanVPN"

    # "Download VPN" screen — three separate sources rather than one
    # generic AmneziaVPN link, so each platform's button goes straight to
    # the right store/file instead of a landing page the user has to
    # navigate from. ANDROID_APK_LINK deliberately points at GitHub's
    # "latest" redirect (not a pinned version/tag), so it always resolves
    # to whatever Amnezia has most recently released without this env var
    # ever needing to change.
    GOOGLE_PLAY_LINK: str = "https://play.google.com/store/apps/details?id=org.amnezia.vpn"
    APP_STORE_LINK: str = "https://apps.apple.com/app/amneziavpn/id1600529900"
    ANDROID_APK_LINK: str = "https://github.com/amnezia-vpn/amnezia-client/releases/latest"

    AMNEZIA_INSTRUCTION_LINK: str = "https://docs.amnezia.org/documentation/instructions/connect-via-text-key"

    # Manat (manual bank transfer) payments now route through an agent
    # queue stored in the database (Agent/AgentPhone models) rather than a
    # static env-configured list — see /add_agent and /add_agent_phone in
    # bot/handlers/admin_handlers.py. No MANAT_* env vars remain here.

    @property
    def admin_ids_list(self) -> list[int]:
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = BotSettings()
