"""
HTTP client for the Billing Service REST API.
The bot uses this to interact with billing without knowing any DB or VPN details.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import httpx

from bot.config import settings

logger = logging.getLogger(__name__)


class BillingClient:
    def __init__(self):
        self._base = settings.BILLING_BASE_URL.rstrip("/")
        self._headers = {
            "X-Billing-Key": settings.BILLING_SECRET_KEY,
            "Content-Type": "application/json",
        }

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base,
            headers=self._headers,
            timeout=30.0,
        )

    async def get_plan(self) -> Optional[dict]:
        async with self._client() as c:
            resp = await c.get("/api/v1/subscriptions/plan")
            resp.raise_for_status()
            return resp.json()

    async def get_plans(self) -> list[dict]:
        """All active tariffs (1/3/6-month), sorted by duration — for the
        tariff selection screen."""
        async with self._client() as c:
            resp = await c.get("/api/v1/subscriptions/plans")
            resp.raise_for_status()
            return resp.json()

    async def get_subscription(self, telegram_id: int) -> Optional[dict]:
        async with self._client() as c:
            resp = await c.get("/api/v1/subscriptions/my", params={"telegram_id": telegram_id})
            resp.raise_for_status()
            return resp.json()

    async def get_devices(self, telegram_id: int) -> list[dict]:
        """All devices (subscriptions) this user has ever bought, newest first."""
        async with self._client() as c:
            resp = await c.get("/api/v1/subscriptions/devices", params={"telegram_id": telegram_id})
            resp.raise_for_status()
            return resp.json()

    async def get_me(self, telegram_id: int) -> dict:
        async with self._client() as c:
            resp = await c.get("/api/v1/users/me", params={"telegram_id": telegram_id})
            resp.raise_for_status()
            return resp.json()

    async def set_user_language(self, telegram_id: int, language: str) -> dict:
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/users/language",
                json={"telegram_id": telegram_id, "language": language},
            )
            resp.raise_for_status()
            return resp.json()

    async def handle_stars_payment(
        self,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        charge_id: str,
        total_amount: int,
        plan_id: Optional[int] = None,
        mode: str = "new",
        target_subscription_id: Optional[int] = None,
    ) -> dict:
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/payments/stars",
                json={
                    "telegram_id": telegram_id,
                    "username": username,
                    "first_name": first_name,
                    "last_name": last_name,
                    "telegram_payment_charge_id": charge_id,
                    "total_amount": total_amount,
                    "plan_id": plan_id,
                    "mode": mode,
                    "target_subscription_id": target_subscription_id,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def handle_usdt_payment(
        self,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        invoice_id: str,
        amount: float,
        plan_id: Optional[int] = None,
        mode: str = "new",
        target_subscription_id: Optional[int] = None,
    ) -> dict:
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/payments/usdt",
                json={
                    "telegram_id": telegram_id,
                    "username": username,
                    "first_name": first_name,
                    "last_name": last_name,
                    "invoice_id": invoice_id,
                    "amount": amount,
                    "currency": "USDT",
                    "plan_id": plan_id,
                    "mode": mode,
                    "target_subscription_id": target_subscription_id,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def get_manat_request_status(self, request_id: int) -> dict:
        """Returns current status/assignment for a manat request — used
        when the bot needs to know which agent currently holds a request
        without having kept that context from an earlier message (e.g. the
        payer's "I paid" tap). Raises httpx.HTTPStatusError with
        status_code == 404 if request_id doesn't exist."""
        async with self._client() as c:
            resp = await c.get(f"/api/v1/payments/manat/{request_id}")
            resp.raise_for_status()
            return resp.json()

    async def create_manat_request(
        self,
        telegram_id: int,
        username: Optional[str],
        first_name: Optional[str],
        last_name: Optional[str],
        plan_id: int,
        mode: str = "new",
        target_subscription_id: Optional[int] = None,
    ) -> dict:
        """Returns {"request_id", "amount_manat", "agent_phone_shown",
        "assigned_agent_telegram_id"} — no subscription exists yet, that
        only happens once the assigned agent confirms money received (see
        confirm_manat_request). Raises httpx.HTTPStatusError with
        status_code == 422 if the plan isn't eligible for manat payment
        (only the 1-month plan is), or 503 if no agent currently has
        capacity — callers should catch both to show a specific message
        rather than a generic error."""
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/payments/manat",
                json={
                    "telegram_id": telegram_id,
                    "username": username,
                    "first_name": first_name,
                    "last_name": last_name,
                    "plan_id": plan_id,
                    "mode": mode,
                    "target_subscription_id": target_subscription_id,
                },
            )
            resp.raise_for_status()
            return resp.json()

    # --- Admin helpers ---

    async def admin_list_users(self, offset: int = 0) -> dict:
        async with self._client() as c:
            resp = await c.get("/api/v1/admin/users", params={"offset": offset, "limit": 20})
            resp.raise_for_status()
            return resp.json()

    async def admin_list_subscriptions(self, offset: int = 0) -> dict:
        async with self._client() as c:
            resp = await c.get(
                "/api/v1/admin/subscriptions", params={"offset": offset, "limit": 20}
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_list_payments(self, offset: int = 0) -> dict:
        async with self._client() as c:
            resp = await c.get(
                "/api/v1/admin/payments", params={"offset": offset, "limit": 20}
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_list_servers(self) -> dict:
        async with self._client() as c:
            resp = await c.get("/api/v1/admin/servers")
            resp.raise_for_status()
            return resp.json()

    async def admin_extend_subscription(self, sub_id: int, days: int) -> dict:
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/subscriptions/{sub_id}/extend", json={"days": days}
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_disable_subscription(self, sub_id: int) -> dict:
        async with self._client() as c:
            resp = await c.post(f"/api/v1/admin/subscriptions/{sub_id}/disable")
            resp.raise_for_status()
            return resp.json()

    async def admin_reissue_device(self, sub_id: int) -> dict:
        async with self._client() as c:
            resp = await c.post(f"/api/v1/admin/subscriptions/{sub_id}/reissue")
            resp.raise_for_status()
            return resp.json()

    async def admin_set_server_status(self, server_id: int, status: str) -> dict:
        async with self._client() as c:
            resp = await c.patch(
                f"/api/v1/admin/servers/{server_id}", json={"status": status}
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_add_server(
        self,
        name: str,
        base_url: str,
        api_key: str,
        region: str = "EU",
        weight: int = 100,
        max_clients: int = 200,
        protocol: str = "amneziawg2",
    ) -> dict:
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/admin/servers",
                json={
                    "name": name,
                    "base_url": base_url,
                    "api_key": api_key,
                    "region": region,
                    "weight": weight,
                    "max_clients": max_clients,
                    "protocol": protocol,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def grant_trial(
        self,
        telegram_id: int,
        username: Optional[str] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
    ) -> dict:
        """Raises httpx.HTTPStatusError with response.status_code == 409 if
        this telegram_id already used its trial — callers should catch that
        specifically to show a "you already used this" message rather than
        a generic error."""
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/admin/trial",
                json={
                    "telegram_id": telegram_id,
                    "username": username,
                    "first_name": first_name,
                    "last_name": last_name,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_broadcast_recipients(self) -> list[int]:
        async with self._client() as c:
            resp = await c.get("/api/v1/admin/broadcast/recipients")
            resp.raise_for_status()
            return resp.json().get("telegram_ids", [])

    async def accept_manat_request(self, request_id: int, agent_id: int) -> dict:
        """Raises httpx.HTTPStatusError with response.status_code == 409 if
        this request is no longer assigned to this agent (already timed
        out and re-assigned) — callers should catch that specifically."""
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/manat/{request_id}/accept",
                json={"agent_id": agent_id},
            )
            resp.raise_for_status()
            return resp.json()

    async def decline_manat_request(self, request_id: int, agent_id: int) -> dict:
        """Same 409 semantics as accept_manat_request. Returns
        {"reassigned", "new_agent_telegram_id", ...} — the bot uses
        reassigned to decide whether to notify a new agent or tell the
        payer the request expired outright."""
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/manat/{request_id}/decline",
                json={"agent_id": agent_id},
            )
            resp.raise_for_status()
            return resp.json()

    async def confirm_manat_request(self, request_id: int, agent_id: int) -> dict:
        """Raises httpx.HTTPStatusError with response.status_code == 409 if
        this request is no longer assigned to this agent or was already
        resolved — callers should catch that specifically to show "this
        request is no longer yours" rather than a generic error. 404 means
        the request_id doesn't exist at all."""
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/manat/{request_id}/confirm",
                json={"agent_id": agent_id},
            )
            resp.raise_for_status()
            return resp.json()

    async def reject_manat_request(self, request_id: int, agent_id: int) -> dict:
        """Same 409/404 semantics as confirm_manat_request."""
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/manat/{request_id}/reject",
                json={"agent_id": agent_id},
            )
            resp.raise_for_status()
            return resp.json()

    # --- Manat agent management ---

    async def admin_create_agent(self, telegram_id: int, display_name: Optional[str] = None) -> dict:
        """Raises httpx.HTTPStatusError with status_code == 409 if an agent
        already exists for this telegram_id."""
        async with self._client() as c:
            resp = await c.post(
                "/api/v1/admin/agents",
                json={"telegram_id": telegram_id, "display_name": display_name},
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_list_agents(self) -> dict:
        async with self._client() as c:
            resp = await c.get("/api/v1/admin/agents")
            resp.raise_for_status()
            return resp.json()

    async def admin_set_agent_active(self, agent_id: int, is_active: bool) -> dict:
        async with self._client() as c:
            resp = await c.patch(
                f"/api/v1/admin/agents/{agent_id}", json={"is_active": is_active}
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_add_agent_phone(self, agent_id: int, phone_number: str) -> dict:
        async with self._client() as c:
            resp = await c.post(
                f"/api/v1/admin/agents/{agent_id}/phones",
                json={"phone_number": phone_number},
            )
            resp.raise_for_status()
            return resp.json()

    async def admin_remove_agent_phone(self, phone_id: int) -> dict:
        async with self._client() as c:
            resp = await c.delete(f"/api/v1/admin/agents/phones/{phone_id}")
            resp.raise_for_status()
            return resp.json()

    async def set_agent_phone_enabled(self, phone_id: int, is_enabled: bool) -> dict:
        """Called by the agent themselves (not admin-only) to toggle one of
        their own numbers in or out of rotation."""
        async with self._client() as c:
            resp = await c.patch(
                f"/api/v1/admin/agents/phones/{phone_id}/enabled",
                json={"is_enabled": is_enabled},
            )
            resp.raise_for_status()
            return resp.json()

    async def get_agent_by_telegram_id(self, telegram_id: int) -> dict:
        """Raises httpx.HTTPStatusError with status_code == 404 if this
        telegram_id isn't a registered agent. Used by /my_numbers."""
        async with self._client() as c:
            resp = await c.get(f"/api/v1/admin/agents/by-telegram/{telegram_id}")
            resp.raise_for_status()
            return resp.json()


billing_client = BillingClient()
