"""
Integration tests for billing FastAPI endpoints.
Uses test DB and mocked AmneziaClient.
"""
import os
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from unittest.mock import AsyncMock, patch

from api.main import app
from billing.database import AsyncSessionLocal, engine as _engine
from models import Base
import models.models  # noqa


# ---------------------------------------------------------------------------
# Override DB session in FastAPI dependency for tests
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture(autouse=True)
async def _billing_engine_schema():
    """
    These tests exercise the real FastAPI app end-to-end (ASGITransport, not
    a mocked dependency), so every request goes through Depends(get_db) ->
    billing.database.AsyncSessionLocal -> billing.database.engine — a
    DIFFERENT engine object than the one tests/conftest.py's `engine`/
    `session` fixtures create for the unit tests. SQLite's StaticPool
    (used automatically for ':memory:' URLs) keeps one connection alive per
    engine OBJECT, not per URL string, so this module's requests were
    hitting a schema-less database no other fixture in this codebase was
    ever creating. Drop-then-create on every test keeps them isolated from
    each other's data, same as conftest.py's per-test `engine` fixture does
    for the unit tests.
    """
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture(autouse=True)
def patch_billing_key(monkeypatch):
    monkeypatch.setenv("BILLING_SECRET_KEY", "test-secret")


@pytest.fixture
def client_headers():
    return {"X-Billing-Key": "test-secret"}


@pytest.fixture
def mock_amnezia():
    with patch("billing.services.billing_service.AmneziaClient") as MockClient:
        instance = AsyncMock()
        from integrations.amnezia.schemas import CreateClientResponse, CreatedClient
        instance.create_client.return_value = CreateClientResponse(
            message="OK",
            client=CreatedClient(
                id="integ-client-id",
                config="vpn://integtest",
                protocol="amneziawg",
            ),
        )
        instance.enable_client.return_value = None
        instance.disable_client.return_value = None
        MockClient.return_value = instance
        yield instance


@pytest.mark.asyncio
async def test_health_endpoint():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_stars_payment_endpoint_unauthorized():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            json={
                "telegram_id": 123,
                "telegram_payment_charge_id": "abc",
                "total_amount": 100,
            },
        )
    assert resp.status_code == 422  # missing X-Billing-Key header


@pytest.mark.asyncio
async def test_stars_payment_missing_plan(client_headers):
    """Should return 400 if no plan exists in DB."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/stars",
            headers=client_headers,
            json={
                "telegram_id": 9991,
                "telegram_payment_charge_id": "no_plan_test",
                "total_amount": 100,
            },
        )
    # Either 400 (ValueError: No active plan) or 500
    assert resp.status_code in (400, 500)


@pytest.mark.asyncio
async def test_manat_request_confirm_flow_end_to_end(client_headers, mock_amnezia):
    """
    Full HTTP round-trip: create a manat request (auto-assigned to an
    agent), accept it as that agent, confirm it, and verify a second
    agent's attempt on the same (now-resolved) request is correctly
    rejected with 409 — exercising the actual Pydantic request/response
    schemas and exception-to-status-code mapping in the routers, not just
    BillingService directly (already covered by the unit tests in
    tests/unit/test_billing_service.py).
    """
    async with AsyncSessionLocal() as session:
        from models.models import Plan, VpnServer, VpnServerStatus

        plan = Plan(
            name="Integ Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        server = VpnServer(
            name="Integ Server", base_url="http://integ-vpn:4001", api_key="k",
            region="EU", weight=100, status=VpnServerStatus.active,
            max_clients=500, current_clients=0,
        )
        session.add_all([plan, server])
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents",
            headers=client_headers,
            json={"telegram_id": 9001, "display_name": "Test Agent"},
        )
        assert agent_resp.status_code == 200
        agent_id = agent_resp.json()["id"]
        phone_resp = await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers,
            json={"phone_number": "+993 12 345678"},
        )
        assert phone_resp.status_code == 200

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8001,
                "username": "manat_integ_user",
                "plan_id": plan_id,
            },
        )
        assert create_resp.status_code == 200
        body = create_resp.json()
        assert body["agent_phone_shown"] == "+993 12 345678"
        assert body["amount_manat"] == 350.0
        assert body["assigned_agent_telegram_id"] == 9001
        request_id = body["request_id"]

        # Confirming before accepting must fail — the request is still
        # awaiting_agent, not awaiting_payment.
        premature_confirm = await ac.post(
            f"/api/v1/admin/manat/{request_id}/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert premature_confirm.status_code == 409

        accept_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert accept_resp.status_code == 200
        assert accept_resp.json()["telegram_id"] == 8001

        confirm_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert confirm_resp.status_code == 200
        confirm_body = confirm_resp.json()
        assert confirm_body["ok"] is True
        assert "subscription_id" in confirm_body
        assert confirm_body["telegram_id"] == 8001, (
            "bot needs this to notify the payer from the agent's own chat/FSM "
            "session, which has no access to the payer's FSMContext"
        )
        assert confirm_body["status"] == "active"
        assert confirm_body["config_url"], "mock_amnezia should have provisioned a real client"

        # A second attempt on the already-resolved request must get 409,
        # not a silent success or a bare 500.
        second_confirm_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert second_confirm_resp.status_code == 409

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"agent_id": 9001},
        )
        assert reject_resp.status_code == 409


@pytest.mark.asyncio
async def test_manat_reject_flow_end_to_end(client_headers):
    """A rejected request must never produce a subscription — checked via
    the same HTTP path a real "no transfer seen" agent action takes."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Reject Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents",
            headers=client_headers,
            json={"telegram_id": 9004},
        )
        agent_id = agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers,
            json={"phone_number": "+993 12 999999"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8002,
                "plan_id": plan_id,
            },
        )
        request_id = create_resp.json()["request_id"]

        accept_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/accept",
            headers=client_headers,
            json={"agent_id": 9004},
        )
        assert accept_resp.status_code == 200

        reject_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/reject",
            headers=client_headers,
            json={"agent_id": 9004},
        )
        assert reject_resp.status_code == 200
        assert reject_resp.json() == {"ok": True}


@pytest.mark.asyncio
async def test_manat_decline_reassigns_to_next_agent(client_headers):
    """An agent tapping "Can't accept" must hand the request to the next
    agent in the queue via the actual HTTP path."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ Decline Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        first_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9005},
        )
        first_agent_id = first_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{first_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000001"},
        )
        second_agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9006},
        )
        second_agent_id = second_agent_resp.json()["id"]
        await ac.post(
            f"/api/v1/admin/agents/{second_agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000002"},
        )

        create_resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8003, "plan_id": plan_id},
        )
        body = create_resp.json()
        request_id = body["request_id"]
        assigned_telegram_id = body["assigned_agent_telegram_id"]

        decline_resp = await ac.post(
            f"/api/v1/admin/manat/{request_id}/decline",
            headers=client_headers,
            json={"agent_id": assigned_telegram_id},
        )
        assert decline_resp.status_code == 200
        decline_body = decline_resp.json()
        assert decline_body["reassigned"] is True
        assert decline_body["new_agent_telegram_id"] in (9005, 9006)
        assert decline_body["new_agent_telegram_id"] != assigned_telegram_id

        status_resp = await ac.get(
            f"/api/v1/payments/manat/{request_id}", headers=client_headers,
        )
        assert status_resp.status_code == 200
        assert status_resp.json()["status"] == "awaiting_agent"


@pytest.mark.asyncio
async def test_manat_request_unknown_plan_returns_400(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={
                "telegram_id": 8004,
                "plan_id": 999999,
            },
        )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_manat_request_non_monthly_plan_returns_422(client_headers):
    """Manat payment must be refused up front for any plan other than the
    30-day one — checked via the actual HTTP status code the bot branches
    on to show "use another payment method"."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ 3-month Plan", duration_days=90, price_stars=250,
            price_usdt=8.0, price_manat=900.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8005, "plan_id": plan_id},
        )
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_manat_request_no_agent_returns_503(client_headers):
    """No agent registered at all -> 503, distinct from the 400/422 plan
    errors, so the bot can show a different message."""
    async with AsyncSessionLocal() as session:
        from models.models import Plan

        plan = Plan(
            name="Integ No-Agent Plan", duration_days=30, price_stars=100,
            price_usdt=3.0, price_manat=350.0, is_active=True,
        )
        session.add(plan)
        await session.commit()
        plan_id = plan.id

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/payments/manat",
            headers=client_headers,
            json={"telegram_id": 8006, "plan_id": plan_id},
        )
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_manat_confirm_unknown_request_returns_404(client_headers):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/api/v1/admin/manat/999999/confirm",
            headers=client_headers,
            json={"agent_id": 9001},
        )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_agent_phone_enable_disable_via_http(client_headers):
    """Agent self-service toggle (not admin-only) via the actual HTTP
    path the bot's /my_numbers command uses."""
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        agent_resp = await ac.post(
            "/api/v1/admin/agents", headers=client_headers, json={"telegram_id": 9007},
        )
        agent_id = agent_resp.json()["id"]
        phone_resp = await ac.post(
            f"/api/v1/admin/agents/{agent_id}/phones",
            headers=client_headers, json={"phone_number": "+993 12 000010"},
        )
        phone_id = phone_resp.json()["id"]

        lookup_resp = await ac.get(
            f"/api/v1/admin/agents/by-telegram/9007", headers=client_headers,
        )
        assert lookup_resp.status_code == 200
        assert lookup_resp.json()["phones"][0]["is_enabled"] is True

        disable_resp = await ac.patch(
            f"/api/v1/admin/agents/phones/{phone_id}/enabled",
            headers=client_headers, json={"is_enabled": False},
        )
        assert disable_resp.status_code == 200

        lookup_resp2 = await ac.get(
            f"/api/v1/admin/agents/by-telegram/9007", headers=client_headers,
        )
        assert lookup_resp2.json()["phones"][0]["is_enabled"] is False
