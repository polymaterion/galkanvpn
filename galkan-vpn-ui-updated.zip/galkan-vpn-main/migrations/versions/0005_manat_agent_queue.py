"""Rework manat payments into an agent queue: agents table, agent_phones
table (multi-number per agent, admin adds/removes, agent enables/disables),
manat_payment_transactions table (trailing-24h per-phone limit tracking),
and new columns/statuses on manat_payment_requests for the two-stage
timeout flow (5-minute agent acceptance, 15-minute payment window).

Revision ID: 0005_manat_agent_queue
Revises: 0004_trial_and_manat
Create Date: 2026-09-13
"""
from alembic import op
import sqlalchemy as sa

revision = "0005_manat_agent_queue"
down_revision = "0004_trial_and_manat"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "agents",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("telegram_id", sa.BigInteger(), nullable=False, unique=True),
        sa.Column("display_name", sa.String(length=128), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("last_assigned_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
    )
    op.create_index("ix_agents_telegram_id", "agents", ["telegram_id"])

    op.create_table(
        "agent_phones",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("agent_id", sa.Integer(), sa.ForeignKey("agents.id"), nullable=False),
        sa.Column("phone_number", sa.String(length=32), nullable=False),
        sa.Column("is_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
        sa.UniqueConstraint("agent_id", "phone_number", name="uq_agent_phone"),
    )
    op.create_index("ix_agent_phones_agent_id", "agent_phones", ["agent_id"])

    # manat_payment_requests: drop the old 4-value status check so the
    # column can hold the new lifecycle values, add the assignment/timeout
    # columns, then re-add the check with the full new value set (including
    # the legacy 'pending' value so any pre-existing row — there should be
    # none in practice, since this is a pre-launch rework, but the app-level
    # enum keeps it as a valid value on purpose — still passes the check).
    op.drop_constraint(
        "ck_manat_payment_requests_status", "manat_payment_requests", type_="check"
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("assigned_agent_id", sa.Integer(), sa.ForeignKey("agents.id"), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("assigned_phone_id", sa.Integer(), sa.ForeignKey("agent_phones.id"), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("assigned_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "manat_payment_requests",
        sa.Column("accepted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.alter_column(
        "manat_payment_requests", "status", server_default="awaiting_agent"
    )
    op.create_check_constraint(
        "ck_manat_payment_requests_status",
        "manat_payment_requests",
        "status IN ('awaiting_agent', 'awaiting_payment', 'confirmed', 'rejected', 'expired', 'pending')",
    )

    op.create_table(
        "manat_payment_transactions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "agent_phone_id", sa.Integer(), sa.ForeignKey("agent_phones.id"), nullable=False
        ),
        sa.Column(
            "manat_request_id",
            sa.Integer(),
            sa.ForeignKey("manat_payment_requests.id"),
            nullable=False,
            unique=True,
        ),
        sa.Column("amount_manat", sa.Numeric(14, 2), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
    )
    op.create_index(
        "ix_manat_payment_transactions_agent_phone_id",
        "manat_payment_transactions",
        ["agent_phone_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_manat_payment_transactions_agent_phone_id",
        table_name="manat_payment_transactions",
    )
    op.drop_table("manat_payment_transactions")

    op.drop_constraint(
        "ck_manat_payment_requests_status", "manat_payment_requests", type_="check"
    )
    op.alter_column("manat_payment_requests", "status", server_default="pending")
    op.create_check_constraint(
        "ck_manat_payment_requests_status",
        "manat_payment_requests",
        "status IN ('pending', 'confirmed', 'rejected', 'expired')",
    )
    op.drop_column("manat_payment_requests", "accepted_at")
    op.drop_column("manat_payment_requests", "assigned_at")
    op.drop_column("manat_payment_requests", "assigned_phone_id")
    op.drop_column("manat_payment_requests", "assigned_agent_id")

    op.drop_index("ix_agent_phones_agent_id", table_name="agent_phones")
    op.drop_table("agent_phones")

    op.drop_index("ix_agents_telegram_id", table_name="agents")
    op.drop_table("agents")
