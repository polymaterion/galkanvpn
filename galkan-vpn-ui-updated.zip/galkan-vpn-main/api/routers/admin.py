"""
Admin router — used by Telegram admin commands and (optionally) a web UI.
Protected by internal billing key.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.dependencies import verify_internal_key
from billing.database import get_db
from billing.repositories.other_repos import (
    AgentRepository,
    ManatRequestRepository,
    PaymentRepository,
    PlanRepository,
    VpnClientRepository,
)
from billing.repositories.server_repo import VpnServerRepository
from billing.repositories.subscription_repo import SubscriptionRepository
from billing.repositories.user_repo import UserRepository
from billing.services.billing_service import (
    BillingService,
    MANAT_PHONE_DAILY_LIMIT,
    ManatRequestAlreadyResolvedError,
    ManatRequestNotAssignedToAgentError,
    TrialAlreadyUsedError,
)
from billing.redis_lock import LockTimeoutError
from integrations.amnezia.client import AmneziaClient
from integrations.amnezia.errors import AmneziaError
from models.models import VpnServerStatus

router = APIRouter(dependencies=[Depends(verify_internal_key)])
_svc = BillingService()


# ---- Users ----

@router.get("/users")
async def list_users(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = UserRepository(session)
    users = await repo.get_all(offset=offset, limit=limit)
    total = await repo.count()
    return {
        "total": total,
        "items": [
            {
                "id": u.id,
                "telegram_id": u.telegram_id,
                "username": u.username,
                "first_name": u.first_name,
                "is_banned": u.is_banned,
                "created_at": u.created_at.isoformat(),
            }
            for u in users
        ],
    }


@router.get("/broadcast/recipients")
async def broadcast_recipients(session=Depends(get_db)):
    """All telegram_id for non-banned users — used by /broadcast to reach
    every user who has ever started the bot, not just new signups. No
    pagination: the bot needs the full list to send to, not a page."""
    repo = UserRepository(session)
    ids = await repo.get_all_telegram_ids()
    return {"telegram_ids": ids}


# ---- Subscriptions ----

@router.get("/subscriptions")
async def list_subscriptions(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = SubscriptionRepository(session)
    subs = await repo.get_all(offset=offset, limit=limit)
    return {
        "items": [
            {
                "id": s.id,
                "user_id": s.user_id,
                "status": s.status.value,
                "expires_at": s.expires_at.isoformat() if s.expires_at else None,
                "plan": s.plan.name if s.plan else None,
            }
            for s in subs
        ]
    }


class ExtendRequest(BaseModel):
    days: int = 30


@router.post("/subscriptions/{sub_id}/extend")
async def extend_subscription(sub_id: int, req: ExtendRequest, session=Depends(get_db)):
    await _svc.admin_extend_subscription(session, sub_id, req.days)
    return {"ok": True}


@router.post("/subscriptions/{sub_id}/disable")
async def disable_subscription(sub_id: int, session=Depends(get_db)):
    await _svc.admin_disable_subscription(session, sub_id)
    return {"ok": True}


@router.post("/subscriptions/{sub_id}/reissue")
async def reissue_device(sub_id: int, session=Depends(get_db)):
    """
    Re-provision a subscription's VPN client from scratch (bot command:
    /reissue_device). Use when a client's config_url looks valid but never
    connects — the old client is best-effort deleted from its VPN server
    (it may already be missing there) and a brand new one is created.
    """
    try:
        config_url = await _svc.admin_reissue_device(session, sub_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except (AmneziaError, LockTimeoutError) as e:
        # admin_reissue_device already updated the subscription/vpn_client
        # rows to reflect the partial failure (pending_provisioning,
        # retry_count, vc marked deleted, old server's count decremented) —
        # but those changes live only in this session's pending transaction
        # until committed. get_db() commits only on a clean return; since
        # the HTTPException raised below propagates straight through it,
        # get_db() would instead roll back everything admin_reissue_device
        # just did, silently discarding that bookkeeping. Commit explicitly
        # here, before raising, so the next retry cycle actually sees it.
        await session.commit()
        raise HTTPException(
            status_code=503,
            detail=f"VPN server unavailable, try again shortly: {e}",
        )
    return {"ok": True, "config_url": config_url}


class GrantTrialRequest(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None


@router.post("/trial")
async def grant_trial(req: GrantTrialRequest, session=Depends(get_db)):
    """Grants the one-time free trial device to this telegram_id. Used by
    the bot both for new users (auto-granted on first /start) and existing
    users (via the trial deep-link, /start=trial)."""
    try:
        sub = await _svc.grant_trial(
            session,
            telegram_id=req.telegram_id,
            username=req.username,
            first_name=req.first_name,
            last_name=req.last_name,
        )
    except TrialAlreadyUsedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"ok": True, "subscription_id": sub.id}


class ManatAgentActionRequest(BaseModel):
    agent_id: int  # the agent's telegram_id, not the Agent.id primary key


@router.post("/manat/{request_id}/accept")
async def accept_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the currently-assigned agent taps "Ready to
    accept" within the 5-minute window. Moves the request to
    awaiting_payment and starts the 15-minute payment-window clock."""
    try:
        request = await _svc.accept_manat_request(
            session, request_id=request_id, agent_id=req.agent_id
        )
    except ManatRequestNotAssignedToAgentError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(request.user_id)
    return {
        "ok": True,
        "telegram_id": user.telegram_id if user else None,
        "amount_manat": float(request.amount_manat),
        "agent_phone_shown": request.agent_phone_shown,
    }


@router.post("/manat/{request_id}/decline")
async def decline_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the currently-assigned agent taps "Can't
    accept" within the 5-minute window — immediately re-assigns to the next
    agent in the queue rather than waiting out the rest of the timeout."""
    try:
        await _svc.decline_manat_request(session, request_id=request_id, agent_id=req.agent_id)
    except ManatRequestNotAssignedToAgentError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    request = await ManatRequestRepository(session).get_by_id(request_id)
    if not request:
        return {"ok": True, "reassigned": False}

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(request.user_id)
    agent_repo = AgentRepository(session)
    new_agent = (
        await agent_repo.get_by_id(request.assigned_agent_id)
        if request.assigned_agent_id
        else None
    )
    return {
        "ok": True,
        "reassigned": new_agent is not None,
        "telegram_id": user.telegram_id if user else None,
        "new_agent_telegram_id": new_agent.telegram_id if new_agent else None,
        "amount_manat": float(request.amount_manat),
        "agent_phone_shown": request.agent_phone_shown,
        "status": request.status.value,
    }


@router.post("/manat/{request_id}/confirm")
async def confirm_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the assigned agent taps "Money received" —
    only the agent currently holding this request (in awaiting_payment) can
    confirm it. See BillingService.confirm_manat_request."""
    try:
        sub = await _svc.confirm_manat_request(
            session, request_id=request_id, agent_id=req.agent_id
        )
    except ManatRequestAlreadyResolvedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    user_repo = UserRepository(session)
    user = await user_repo.get_by_id(sub.user_id)
    vc_repo = VpnClientRepository(session)
    vc = await vc_repo.get_by_subscription(sub.id)
    return {
        "ok": True,
        "subscription_id": sub.id,
        "telegram_id": user.telegram_id if user else None,
        "status": sub.status.value,
        "expires_at": sub.expires_at.isoformat() if sub.expires_at else None,
        "config_url": vc.config_url if vc else None,
    }


@router.post("/manat/{request_id}/reject")
async def reject_manat_request(
    request_id: int, req: ManatAgentActionRequest, session=Depends(get_db)
):
    """Called by the bot when the assigned agent taps "Money not received"
    — no transfer seen, wrong amount, etc."""
    try:
        await _svc.reject_manat_request(session, request_id=request_id, agent_id=req.agent_id)
    except ManatRequestAlreadyResolvedError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"ok": True}


# ---- Manat agents ----

class AgentCreateRequest(BaseModel):
    telegram_id: int
    display_name: Optional[str] = None


@router.post("/agents")
async def create_agent(req: AgentCreateRequest, session=Depends(get_db)):
    """Register a new manat payment agent (admin-only — bot command:
    /add_agent). The agent starts with zero phone numbers; add one with
    POST /agents/{agent_id}/phones before they can receive assignments."""
    repo = AgentRepository(session)
    existing = await repo.get_by_telegram_id(req.telegram_id)
    if existing:
        raise HTTPException(status_code=409, detail="Agent already exists for this telegram_id")
    agent = await repo.create(telegram_id=req.telegram_id, display_name=req.display_name)
    return {"ok": True, "id": agent.id, "telegram_id": agent.telegram_id}


@router.get("/agents")
async def list_agents(session=Depends(get_db)):
    repo = AgentRepository(session)
    agents = await repo.get_all()
    result = []
    for agent in agents:
        since = datetime.now(timezone.utc) - timedelta(hours=24)
        phones = await repo.get_phones_for_agent(agent.id)
        phone_info = []
        for phone in phones:
            received = await repo.get_phone_received_since(phone.id, since)
            phone_info.append({
                "id": phone.id,
                "phone_number": phone.phone_number,
                "is_enabled": phone.is_enabled,
                "received_last_24h": received,
            })
        result.append({
            "id": agent.id,
            "telegram_id": agent.telegram_id,
            "display_name": agent.display_name,
            "is_active": agent.is_active,
            "phones": phone_info,
        })
    return {"items": result}


class AgentActiveUpdate(BaseModel):
    is_active: bool


@router.patch("/agents/{agent_id}")
async def update_agent_active(agent_id: int, req: AgentActiveUpdate, session=Depends(get_db)):
    """Admin-only: enable/disable an agent entirely (removes them from the
    assignment queue regardless of their phones' state)."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    await repo.set_active(agent_id, req.is_active)
    return {"ok": True}


class AgentPhoneCreateRequest(BaseModel):
    phone_number: str


@router.post("/agents/{agent_id}/phones")
async def add_agent_phone(agent_id: int, req: AgentPhoneCreateRequest, session=Depends(get_db)):
    """Admin-only: add a phone number to an agent (bot command:
    /add_agent_phone). New numbers start enabled."""
    repo = AgentRepository(session)
    agent = await repo.get_by_id(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    phone = await repo.add_phone(agent_id, req.phone_number)
    return {"ok": True, "id": phone.id, "phone_number": phone.phone_number}


@router.delete("/agents/phones/{phone_id}")
async def remove_agent_phone(phone_id: int, session=Depends(get_db)):
    """Admin-only: permanently remove a phone number from an agent (bot
    command: /remove_agent_phone). Use PATCH .../enabled to temporarily
    take a number out of rotation instead of deleting it."""
    repo = AgentRepository(session)
    phone = await repo.get_phone_by_id(phone_id)
    if not phone:
        raise HTTPException(status_code=404, detail="Phone not found")
    await repo.remove_phone(phone_id)
    return {"ok": True}


class AgentPhoneEnabledUpdate(BaseModel):
    is_enabled: bool


@router.patch("/agents/phones/{phone_id}/enabled")
async def set_agent_phone_enabled(
    phone_id: int, req: AgentPhoneEnabledUpdate, session=Depends(get_db)
):
    """Toggled by the agent themselves from the bot (not admin-only) —
    temporarily taking a number in or out of rotation, e.g. while it's
    low on balance or unavailable, without losing its 24h history."""
    repo = AgentRepository(session)
    phone = await repo.get_phone_by_id(phone_id)
    if not phone:
        raise HTTPException(status_code=404, detail="Phone not found")
    await repo.set_phone_enabled(phone_id, req.is_enabled)
    return {"ok": True}


@router.get("/agents/by-telegram/{telegram_id}")
async def get_agent_by_telegram_id(telegram_id: int, session=Depends(get_db)):
    """Used by the bot's /my_numbers command to look up the calling agent
    (identified by their own telegram_id) and show their phones + trailing
    24h usage."""
    repo = AgentRepository(session)
    agent = await repo.get_by_telegram_id(telegram_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Not a registered agent")
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    phones = await repo.get_phones_for_agent(agent.id)
    phone_info = []
    for phone in phones:
        received = await repo.get_phone_received_since(phone.id, since)
        phone_info.append({
            "id": phone.id,
            "phone_number": phone.phone_number,
            "is_enabled": phone.is_enabled,
            "received_last_24h": received,
        })
    return {
        "id": agent.id,
        "telegram_id": agent.telegram_id,
        "display_name": agent.display_name,
        "is_active": agent.is_active,
        "phones": phone_info,
        "daily_limit_per_phone": MANAT_PHONE_DAILY_LIMIT,
    }


# ---- Payments ----

@router.get("/payments")
async def list_payments(offset: int = 0, limit: int = 50, session=Depends(get_db)):
    repo = PaymentRepository(session)
    payments = await repo.get_all(offset=offset, limit=limit)
    return {
        "items": [
            {
                "id": p.id,
                "user_id": p.user_id,
                "provider": p.provider.value,
                "amount": float(p.amount),
                "currency": p.currency,
                "status": p.status.value,
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            }
            for p in payments
        ]
    }


# ---- Servers ----

@router.get("/servers")
async def list_servers(session=Depends(get_db)):
    repo = VpnServerRepository(session)
    servers = await repo.get_all()
    result = []
    for s in servers:
        load_info: dict[str, Any] = {}
        try:
            amnezia = AmneziaClient(base_url=s.base_url, api_key=s.api_key)
            info = await amnezia.get_server_info()
            load_info = {"cpu": info.cpu, "memory": info.memory, "uptime": info.uptime}
        except Exception:
            load_info = {"error": "unreachable"}
        result.append(
            {
                "id": s.id,
                "name": s.name,
                "region": s.region,
                "status": s.status.value,
                "weight": s.weight,
                "protocol": s.protocol,
                "current_clients": s.current_clients,
                "max_clients": s.max_clients,
                "load": load_info,
            }
        )
    return {"items": result}


class ServerStatusUpdate(BaseModel):
    status: str  # "active" | "disabled"


@router.patch("/servers/{server_id}")
async def update_server_status(
    server_id: int, req: ServerStatusUpdate, session=Depends(get_db)
):
    repo = VpnServerRepository(session)
    server = await repo.get_by_id(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    try:
        server.status = VpnServerStatus(req.status)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid status: {req.status}")
    return {"ok": True, "new_status": server.status.value}


class ServerCreateRequest(BaseModel):
    name: str
    base_url: str
    api_key: str
    region: Optional[str] = "EU"
    weight: int = 100
    max_clients: int = 200
    protocol: str = "amneziawg2"  # must match protocols enabled on that server


@router.post("/servers")
async def create_server(req: ServerCreateRequest, session=Depends(get_db)):
    """
    Add a new VPN server. Use this to add servers after the initial deploy —
    the seed script only runs once, so this is the normal way to grow the
    server pool later (bot command: /add_server).
    """
    repo = VpnServerRepository(session)
    server = await repo.create(
        name=req.name,
        base_url=req.base_url,
        api_key=req.api_key,
        region=req.region,
        weight=req.weight,
        max_clients=req.max_clients,
        protocol=req.protocol,
    )
    return {"ok": True, "id": server.id, "name": server.name, "protocol": server.protocol}


@router.delete("/servers/{server_id}")
async def delete_server(server_id: int, session=Depends(get_db)):
    """
    Remove a server that has no clients on it. Servers with existing clients
    should be disabled (PATCH status=disabled) instead of deleted, since
    vpn_clients/subscriptions reference server_id via foreign key.
    """
    repo = VpnServerRepository(session)
    server = await repo.get_by_id(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.current_clients > 0:
        raise HTTPException(
            status_code=400,
            detail="Server has active clients — disable it instead of deleting",
        )
    await repo.delete(server_id)
    return {"ok": True}


# ---- Plan price ----

class PlanUpdate(BaseModel):
    price_stars: Optional[int] = None
    price_usdt: Optional[float] = None


@router.patch("/plans/{plan_id}")
async def update_plan(plan_id: int, req: PlanUpdate, session=Depends(get_db)):
    repo = PlanRepository(session)
    plan = await repo.get_by_id(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    if req.price_stars is not None:
        plan.price_stars = req.price_stars
    if req.price_usdt is not None:
        plan.price_usdt = req.price_usdt
    return {"ok": True}
