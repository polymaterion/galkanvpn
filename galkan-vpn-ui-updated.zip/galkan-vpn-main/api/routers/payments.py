"""
Payments router.
Bot calls POST /api/v1/payments/stars or /api/v1/payments/usdt
after a successful Telegram payment event.
"""
from __future__ import annotations

import os
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.dependencies import verify_internal_key
from billing.database import get_db
from billing.repositories.other_repos import AgentRepository, VpnClientRepository
from billing.repositories.user_repo import UserRepository
from billing.services.billing_service import (
    BillingService,
    ManatPlanNotEligibleError,
    NoAgentAvailableError,
)
from models.models import PaymentProvider

router = APIRouter(dependencies=[Depends(verify_internal_key)])
_svc = BillingService()

PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")


class StarsPaymentRequest(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    telegram_payment_charge_id: str   # unique ID from Telegram
    total_amount: int                 # in Stars (XTR)
    plan_id: Optional[int] = None
    mode: str = "new"                 # "new" | "renew"
    target_subscription_id: Optional[int] = None


class UsdtPaymentRequest(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    invoice_id: str                   # unique ID from crypto provider
    amount: float
    currency: str = "USDT"
    plan_id: Optional[int] = None
    mode: str = "new"                 # "new" | "renew"
    target_subscription_id: Optional[int] = None


class ManatPaymentRequestIn(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    plan_id: int
    mode: str = "new"
    target_subscription_id: Optional[int] = None


class ManatPaymentRequestOut(BaseModel):
    request_id: int
    amount_manat: float
    agent_phone_shown: str
    # The agent this request was assigned to — the bot needs this to know
    # who to notify (only that one agent, not "all agents" as before).
    assigned_agent_telegram_id: int


class ManatRequestStatusOut(BaseModel):
    request_id: int
    status: str
    amount_manat: float
    agent_phone_shown: str
    payer_telegram_id: Optional[int]
    # None once the request reaches a final state (confirmed/rejected/
    # expired) with no agent currently holding it, or while awaiting_agent
    # briefly has no assignee between a decline and re-assignment.
    assigned_agent_telegram_id: Optional[int]


class PaymentResponse(BaseModel):
    subscription_id: int
    status: str
    expires_at: Optional[str]
    config_url: Optional[str]
    connect_url: Optional[str]  # public one-tap "open in Amnezia" link


async def _payment_response(session, sub) -> PaymentResponse:
    vpn_client = await VpnClientRepository(session).get_by_subscription(sub.id)
    connect_url = None
    if vpn_client and vpn_client.public_token and PUBLIC_BASE_URL:
        connect_url = f"{PUBLIC_BASE_URL}/connect/{vpn_client.public_token}"
    return PaymentResponse(
        subscription_id=sub.id,
        status=sub.status.value,
        expires_at=sub.expires_at.isoformat() if sub.expires_at else None,
        config_url=vpn_client.config_url if vpn_client else None,
        connect_url=connect_url,
    )


@router.post("/stars", response_model=PaymentResponse)
async def handle_stars_payment(req: StarsPaymentRequest, session=Depends(get_db)):
    sub = await _svc.handle_payment(
        session,
        telegram_id=req.telegram_id,
        username=req.username,
        first_name=req.first_name,
        last_name=req.last_name,
        provider=PaymentProvider.stars,
        external_id=req.telegram_payment_charge_id,
        amount=req.total_amount,
        currency="XTR",
        plan_id=req.plan_id,
        mode=req.mode,
        target_subscription_id=req.target_subscription_id,
    )
    return await _payment_response(session, sub)


@router.post("/usdt", response_model=PaymentResponse)
async def handle_usdt_payment(req: UsdtPaymentRequest, session=Depends(get_db)):
    sub = await _svc.handle_payment(
        session,
        telegram_id=req.telegram_id,
        username=req.username,
        first_name=req.first_name,
        last_name=req.last_name,
        provider=PaymentProvider.usdt,
        external_id=req.invoice_id,
        amount=req.amount,
        currency=req.currency,
        plan_id=req.plan_id,
        mode=req.mode,
        target_subscription_id=req.target_subscription_id,
    )
    return await _payment_response(session, sub)


@router.post("/manat", response_model=ManatPaymentRequestOut)
async def create_manat_payment_request(req: ManatPaymentRequestIn, session=Depends(get_db)):
    """
    Creates a manat request and assigns it to the next available agent
    (round-robin queue — see BillingService._pick_agent_and_phone). Does
    NOT return a PaymentResponse, since no Subscription exists yet (that
    only happens once the assigned agent confirms money received; see
    /api/v1/admin/manat/{id}/confirm). The bot uses
    assigned_agent_telegram_id to notify exactly that one agent — unlike
    the old broadcast-to-all-agents model — and shows the payer a "waiting
    for agent" screen until that agent accepts.
    """
    try:
        request = await _svc.create_manat_request(
            session,
            telegram_id=req.telegram_id,
            username=req.username,
            first_name=req.first_name,
            last_name=req.last_name,
            plan_id=req.plan_id,
            mode=req.mode,
            target_subscription_id=req.target_subscription_id,
        )
    except ManatPlanNotEligibleError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except NoAgentAvailableError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    agent_repo = AgentRepository(session)
    agent = await agent_repo.get_by_id(request.assigned_agent_id)
    return ManatPaymentRequestOut(
        request_id=request.id,
        amount_manat=float(request.amount_manat),
        agent_phone_shown=request.agent_phone_shown,
        assigned_agent_telegram_id=agent.telegram_id,
    )


@router.get("/manat/{request_id}", response_model=ManatRequestStatusOut)
async def get_manat_request_status(request_id: int, session=Depends(get_db)):
    """
    Current state of a manat request — used by the payer's bot session to
    look up which agent currently holds the request (e.g. when the payer
    taps "I paid" and the bot needs a telegram_id to notify, without
    having kept the agent's chat context from the earlier assignment
    message). Returns 404 if the request_id doesn't exist.
    """
    from billing.repositories.other_repos import ManatRequestRepository

    req_repo = ManatRequestRepository(session)
    request = await req_repo.get_by_id(request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Manat request not found")

    user_repo = UserRepository(session)
    payer = await user_repo.get_by_id(request.user_id)

    agent_telegram_id = None
    if request.assigned_agent_id:
        agent_repo = AgentRepository(session)
        agent = await agent_repo.get_by_id(request.assigned_agent_id)
        agent_telegram_id = agent.telegram_id if agent else None

    return ManatRequestStatusOut(
        request_id=request.id,
        status=request.status.value,
        amount_manat=float(request.amount_manat),
        agent_phone_shown=request.agent_phone_shown,
        payer_telegram_id=payer.telegram_id if payer else None,
        assigned_agent_telegram_id=agent_telegram_id,
    )
