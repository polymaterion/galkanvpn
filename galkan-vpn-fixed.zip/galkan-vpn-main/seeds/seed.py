"""
Seed script: creates three subscription plans (1/3/6 months), the free trial
plan, and any VPN servers configured via env vars. Run once after migrate.

Plan prices are configured independently per duration — no discount formula
is applied for longer durations; each of PLAN_1M_*/PLAN_3M_*/PLAN_6M_* is
its own set of prices in .env.

VPN servers are picked up dynamically from env vars of the form:
  VPN_SERVER{N}_URL, VPN_SERVER{N}_KEY  (N = 1, 2, 3, ...)
  VPN_SERVER{N}_NAME, VPN_SERVER{N}_REGION, VPN_SERVER{N}_WEIGHT  (optional)
  VPN_SERVER{N}_PROTOCOL  (optional, default "amneziawg2" — must match what's
    actually installed/enabled on that server's amnezia-api instance, see its
    .env: PROTOCOLS_ENABLED. Wrong value causes 400 Bad Request on client creation.)

Only servers with both *_URL and *_KEY actually set (non-empty, not a leftover
placeholder) are created. This means:
  - With just VPN_SERVER1_URL/VPN_SERVER1_KEY set, only one server is seeded.
  - To add more servers later, either add VPN_SERVER2_URL/VPN_SERVER2_KEY (etc.)
    to .env *before* the very first run of this script, or — since this script
    only runs once (it skips seeding if any VpnServer already exists) — use the
    admin API/bot command to add servers afterwards:
      POST /api/v1/admin/servers   (see api/routers/admin.py)
      /add_server command in the bot admin panel
"""
import asyncio
import os

from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import select

from models.models import Plan, VpnServer, VpnServerStatus

DATABASE_URL = os.environ["DATABASE_URL"]

# Values that mean "not actually configured, don't seed this server"
_PLACEHOLDER_MARKERS = {"", "replace_with_real_api_key"}
_MAX_SERVER_SLOTS = 10  # how many VPN_SERVER{N}_* slots to scan for

# (duration_days, env_prefix, default_stars, default_usdt, default_manat)
_PLAN_DURATIONS = [
    (30, "PLAN_1M", 100, 3.00, 350.00),
    (90, "PLAN_3M", 270, 8.00, 950.00),
    (180, "PLAN_6M", 500, 15.00, 1800.00),
]


def _configured_servers() -> list[VpnServer]:
    """Build VpnServer objects from VPN_SERVER{N}_* env vars that are actually set."""
    servers: list[VpnServer] = []
    for n in range(1, _MAX_SERVER_SLOTS + 1):
        url = os.getenv(f"VPN_SERVER{n}_URL", "").strip()
        key = os.getenv(f"VPN_SERVER{n}_KEY", "").strip()

        if not url or not key or key in _PLACEHOLDER_MARKERS:
            # Not configured — skip silently. This is expected for slots beyond
            # the servers you actually have (e.g. VPN_SERVER2 when you only run one).
            continue

        servers.append(
            VpnServer(
                name=os.getenv(f"VPN_SERVER{n}_NAME", f"Server {n}"),
                base_url=url,
                api_key=key,
                region=os.getenv(f"VPN_SERVER{n}_REGION", "EU"),
                weight=int(os.getenv(f"VPN_SERVER{n}_WEIGHT", "100")),
                status=VpnServerStatus.active,
                max_clients=int(os.getenv(f"VPN_SERVER{n}_MAX_CLIENTS", "200")),
                current_clients=0,
                protocol=os.getenv(f"VPN_SERVER{n}_PROTOCOL", "amneziawg2"),
            )
        )
    return servers


async def seed():
    engine = create_async_engine(DATABASE_URL)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        # --- Plans: one row per duration, each checked independently ---
        # NOTE on name/description: these fields are NOT shown to customers.
        # The bot builds the customer-facing plan name/description entirely
        # from bot/locales/{ru,tk}.py ("plan_name_text" / "plan_description_text",
        # parameterized by duration_days) so it's always in the user's chosen
        # language — see bot/handlers/main_handlers.py. Only
        # duration_days/price_stars/price_usdt/price_manat from these rows
        # are actually read. name/description exist only as an
        # internal/admin-facing label, kept language-neutral on purpose.
        #
        # Checked per-duration (not a single "does any plan exist" check) so
        # re-running this script against an already-deployed project that
        # only has the old single 30-day plan still creates the missing
        # 90/180-day ones instead of being skipped entirely.
        for duration_days, env_prefix, default_stars, default_usdt, default_manat in _PLAN_DURATIONS:
            result = await session.execute(
                select(Plan).where(
                    Plan.duration_days == duration_days, Plan.is_trial == False
                ).limit(1)
            )
            if result.scalar_one_or_none():
                print(f"[seed] Plan for {duration_days} days already exists, skip")
                continue

            plan = Plan(
                name=f"{duration_days}-day plan (internal label — not shown to users)",
                description="See bot/locales/*.py for the real customer-facing text.",
                duration_days=duration_days,
                price_stars=int(os.getenv(f"{env_prefix}_PRICE_STARS", str(default_stars))),
                price_usdt=float(os.getenv(f"{env_prefix}_PRICE_USDT", str(default_usdt))),
                price_manat=float(os.getenv(f"{env_prefix}_PRICE_MANAT", str(default_manat))),
                is_active=True,
            )
            session.add(plan)
            print(f"[seed] Created {duration_days}-day plan")

        # --- Trial plan: separate row, separate existence check ---
        # Deliberately independent of the main-plan checks above so that
        # re-running this script against an already-deployed project (which
        # already has its main plans from before this feature existed) still
        # creates the trial plan instead of being skipped by any "a plan
        # already exists" condition.
        result = await session.execute(select(Plan).where(Plan.is_trial == True).limit(1))
        if not result.scalar_one_or_none():
            trial_plan = Plan(
                name="Free trial (internal label — not shown to users)",
                description="Granted via grant_trial(); see billing_service.py.",
                duration_days=int(os.getenv("TRIAL_DURATION_DAYS", "3")),
                price_stars=0,
                price_usdt=0,
                price_manat=0,
                is_active=False,  # belt-and-suspenders — get_active_plan() already
                                  # excludes is_trial=True regardless of this flag.
                is_trial=True,
            )
            session.add(trial_plan)
            print("[seed] Created trial plan")
        else:
            print("[seed] Trial plan already exists, skip")

        # --- VPN Servers: only ones with real config in env ---
        result = await session.execute(select(VpnServer).limit(1))
        if not result.scalar_one_or_none():
            servers = _configured_servers()
            if servers:
                session.add_all(servers)
                names = ", ".join(s.name for s in servers)
                print(f"[seed] Created {len(servers)} VPN server(s): {names}")
            else:
                print(
                    "[seed] WARNING: no VPN_SERVER*_URL/*_KEY configured in env — "
                    "no VPN servers were created. Add at least VPN_SERVER1_URL and "
                    "VPN_SERVER1_KEY to .env and re-run, or add a server later via "
                    "the admin API/bot."
                )
        else:
            print("[seed] VPN servers already exist, skip")

        await session.commit()

    await engine.dispose()
    print("[seed] Done.")


if __name__ == "__main__":
    asyncio.run(seed())
