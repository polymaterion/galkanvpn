"""
All SQLAlchemy ORM models.
Import order matters for Alembic to detect all tables.
"""
import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Enum, Float, ForeignKey,
    Index, Integer, Numeric, String, Text, UniqueConstraint, func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models import Base, TimestampMixin


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SubscriptionStatus(str, enum.Enum):
    pending_payment = "pending_payment"
    pending_provisioning = "pending_provisioning"
    active = "active"
    expired = "expired"
    disabled = "disabled"
    error = "error"


class PaymentStatus(str, enum.Enum):
    pending = "pending"
    paid = "paid"
    failed = "failed"
    refunded = "refunded"


class PaymentProvider(str, enum.Enum):
    stars = "stars"
    usdt = "usdt"
    manat = "manat"


class ManatRequestStatus(str, enum.Enum):
    pending = "pending"      # created, waiting for an agent to confirm or reject
    confirmed = "confirmed"  # an agent confirmed — Payment/Order/Subscription created
    rejected = "rejected"    # an agent rejected (no transfer seen, wrong amount, etc.)
    expired = "expired"      # reserved for a future timeout sweep; not set anywhere yet


class OrderStatus(str, enum.Enum):
    pending = "pending"
    completed = "completed"
    failed = "failed"


class VpnServerStatus(str, enum.Enum):
    active = "active"
    disabled = "disabled"
    maintenance = "maintenance"


class VpnClientStatus(str, enum.Enum):
    active = "active"
    disabled = "disabled"
    deleted = "deleted"


class AuditAction(str, enum.Enum):
    subscription_created = "subscription_created"
    subscription_renewed = "subscription_renewed"
    subscription_expired = "subscription_expired"
    subscription_disabled = "subscription_disabled"
    subscription_enabled = "subscription_enabled"
    vpn_client_created = "vpn_client_created"
    vpn_client_disabled = "vpn_client_disabled"
    vpn_client_enabled = "vpn_client_enabled"
    vpn_client_deleted = "vpn_client_deleted"
    payment_received = "payment_received"
    provisioning_failed = "provisioning_failed"
    provisioning_retried = "provisioning_retried"


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------

class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    # None = language not chosen yet (bot shows the picker on /start).
    # "ru" or "tk" once chosen.
    language: Mapped[Optional[str]] = mapped_column(String(8), nullable=True)

    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="user")
    orders: Mapped[list["Order"]] = relationship(back_populates="user")
    payments: Mapped[list["Payment"]] = relationship(back_populates="user")


class Plan(Base, TimestampMixin):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)
    price_stars: Mapped[int] = mapped_column(Integer, nullable=False)     # XTR
    price_usdt: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    price_manat: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False, server_default="0")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # True only for the single free trial plan (see grant_trial()). Excluded
    # from get_active_plan()'s query regardless of is_active, so an admin
    # mistake (e.g. accidentally flipping is_active on it) can't make a
    # regular purchase silently resolve to the free trial.
    is_trial: Mapped[bool] = mapped_column(Boolean, default=False)

    orders: Mapped[list["Order"]] = relationship(back_populates="plan")
    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="plan")


class VpnServer(Base, TimestampMixin):
    __tablename__ = "vpn_servers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    base_url: Mapped[str] = mapped_column(String(512), nullable=False)
    api_key: Mapped[str] = mapped_column(String(512), nullable=False)
    region: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    weight: Mapped[int] = mapped_column(Integer, default=100)
    status: Mapped[VpnServerStatus] = mapped_column(
        Enum(VpnServerStatus), default=VpnServerStatus.active
    )
    max_clients: Mapped[int] = mapped_column(Integer, default=500)
    current_clients: Mapped[int] = mapped_column(Integer, default=0)
    # Which amnezia-api protocol this server has installed/enabled:
    # "amneziawg", "amneziawg2" or "xray". Must match what's actually running
    # on that VPN server (check its amnezia-api .env: PROTOCOLS_ENABLED),
    # otherwise client creation fails with 400 Bad Request.
    protocol: Mapped[str] = mapped_column(String(32), default="amneziawg2")

    vpn_clients: Mapped[list["VpnClient"]] = relationship(back_populates="server")


class Order(Base, TimestampMixin):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    status: Mapped[OrderStatus] = mapped_column(
        Enum(OrderStatus), default=OrderStatus.pending, nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="orders")
    plan: Mapped["Plan"] = relationship(back_populates="orders")
    payments: Mapped[list["Payment"]] = relationship(back_populates="order")


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), nullable=False, index=True)
    # Which subscription (device) this payment ultimately provisioned/renewed.
    # Set right after the subscription is created/extended. Used to resolve
    # duplicate/replayed payment events to the exact right device instead of
    # guessing "latest subscription for user" (unreliable once a user can
    # have several concurrent devices).
    subscription_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("subscriptions.id"), nullable=True, index=True
    )
    provider: Mapped[PaymentProvider] = mapped_column(Enum(PaymentProvider), nullable=False)
    external_id: Mapped[str] = mapped_column(String(512), nullable=False)
    status: Mapped[PaymentStatus] = mapped_column(
        Enum(PaymentStatus), default=PaymentStatus.pending
    )
    amount: Mapped[float] = mapped_column(Numeric(14, 4), nullable=False)
    currency: Mapped[str] = mapped_column(String(16), nullable=False)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="payments")
    order: Mapped["Order"] = relationship(back_populates="payments")

    __table_args__ = (
        UniqueConstraint("provider", "external_id", name="uq_payment_provider_external"),
        Index("ix_payment_external_id", "external_id"),
    )


class ManatPaymentRequest(Base, TimestampMixin):
    """
    A pending manual-payment request awaiting agent confirmation. Deliberately
    NOT a Payment row — Payment/Order/Subscription are only created once an
    agent actually confirms (see BillingService.confirm_manat_request), so
    a request that's rejected or never actioned never touches those tables
    at all. All the "what should this become once confirmed" parameters
    that handle_payment() normally receives as call arguments have to be
    persisted here instead, since real time (and potentially a process
    restart) passes between request creation and confirmation.
    """
    __tablename__ = "manat_payment_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    mode: Mapped[str] = mapped_column(String(16), nullable=False)  # "new" or "renew"
    target_subscription_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("subscriptions.id"), nullable=True
    )
    amount_manat: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)
    agent_phone_shown: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[ManatRequestStatus] = mapped_column(
        Enum(ManatRequestStatus, native_enum=False),
        default=ManatRequestStatus.pending,
        nullable=False,
    )
    # Which agent actually confirmed/rejected — set only on resolution. Any
    # agent may have RECEIVED the notification (all of them do, by design —
    # first to act wins), but only one's action here is the one that stuck.
    resolved_by_agent_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    # Populated only once confirmed — the Payment that resulted from this
    # request, for audit/lookup ("which manat request led to this payment").
    payment_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("payments.id"), nullable=True
    )

    user: Mapped["User"] = relationship()
    plan: Mapped["Plan"] = relationship()


class Subscription(Base, TimestampMixin):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    server_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("vpn_servers.id"), nullable=True
    )
    status: Mapped[SubscriptionStatus] = mapped_column(
        Enum(SubscriptionStatus), default=SubscriptionStatus.pending_payment, nullable=False
    )
    starts_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_provisioned_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_extended_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    retry_count: Mapped[int] = mapped_column(Integer, default=0)

    user: Mapped["User"] = relationship(back_populates="subscriptions")
    plan: Mapped["Plan"] = relationship(back_populates="subscriptions")
    server: Mapped[Optional["VpnServer"]] = relationship()
    vpn_client: Mapped[Optional["VpnClient"]] = relationship(
        back_populates="subscription", uselist=False
    )


class VpnClient(Base, TimestampMixin):
    __tablename__ = "vpn_clients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscriptions.id"), unique=True, nullable=False
    )
    server_id: Mapped[int] = mapped_column(ForeignKey("vpn_servers.id"), nullable=False)
    amnezia_client_id: Mapped[str] = mapped_column(String(512), nullable=False)
    client_name: Mapped[str] = mapped_column(String(256), nullable=False)
    config_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # vpn:// URL
    status: Mapped[VpnClientStatus] = mapped_column(
        Enum(VpnClientStatus), default=VpnClientStatus.active
    )
    protocol: Mapped[str] = mapped_column(String(32), default="amneziawg2")
    # Opaque random token used in the public /connect/{token} redirect link
    # (see api/routers/connect.py). Never expose amnezia_client_id or api keys
    # in a public URL — this token is the only thing that travels there.
    public_token: Mapped[Optional[str]] = mapped_column(
        String(64), unique=True, nullable=True, index=True
    )

    subscription: Mapped["Subscription"] = relationship(back_populates="vpn_client")
    server: Mapped["VpnServer"] = relationship(back_populates="vpn_clients")

    __table_args__ = (
        UniqueConstraint("server_id", "amnezia_client_id", name="uq_vpnclient_server_client"),
    )


class ProcessedEvent(Base):
    """Idempotency table – store processed payment event IDs to prevent double-processing."""
    __tablename__ = "processed_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[str] = mapped_column(String(512), unique=True, nullable=False, index=True)
    processed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )
    action: Mapped[AuditAction] = mapped_column(Enum(AuditAction), nullable=False)
    entity_type: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    entity_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON string
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
