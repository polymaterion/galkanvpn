"""Inline keyboards for the screen-based bot UI."""
from __future__ import annotations

from typing import Optional

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.locales import t


def language_picker(lang: str = "ru", include_back: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=t("btn_lang_ru", lang), callback_data="lang:ru"),
        InlineKeyboardButton(text=t("btn_lang_tk", lang), callback_data="lang:tk"),
    )
    if include_back:
        builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def main_menu(lang: str) -> InlineKeyboardMarkup:
    """The only screen without a back button: it is the navigation root."""
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_my_subscriptions", lang), callback_data="nav:devices"))
    builder.row(InlineKeyboardButton(text=t("btn_buy_new", lang), callback_data="nav:buy_new"))
    builder.row(
        InlineKeyboardButton(text=t("btn_download_vpn", lang), callback_data="nav:download_vpn"),
        InlineKeyboardButton(text=t("btn_support", lang), callback_data="nav:support"),
    )
    builder.row(
        InlineKeyboardButton(text=t("btn_info", lang), callback_data="nav:info"),
        InlineKeyboardButton(text=t("btn_language", lang), callback_data="nav:language"),
    )
    return builder.as_markup()


def back_keyboard(lang: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def devices_keyboard(lang: str, devices: list[dict]) -> InlineKeyboardMarkup:
    """List screen. Each device opens its own card screen."""
    builder = InlineKeyboardBuilder()
    for i, d in enumerate(devices, start=1):
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_open", lang, n=i), callback_data=f"nav:device:{d['id']}"
            )
        )
    builder.row(InlineKeyboardButton(text=t("btn_buy_new", lang), callback_data="nav:buy_new"))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def device_card_keyboard(lang: str, device: dict, number: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if device.get("config_url") and device.get("status") == "active":
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_connect", lang, n=number), callback_data=f"show_key:{device['id']}"
            )
        )
        builder.row(
            InlineKeyboardButton(
                text=t("btn_device_qr", lang, n=number), callback_data=f"show_qr:{device['id']}"
            )
        )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_device_renew", lang, n=number),
            callback_data=f"nav:renew:{device['id']}",
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def tariff_select_keyboard(
    lang: str, plans: list[dict], mode: str, target_id: Optional[int]
) -> InlineKeyboardMarkup:
    """Screen shown after "Buy subscription" / "Renew" — one button per
    active plan (1/3/6 months), each showing its Stars price for a quick
    price sense before diving into the plan card / payment method."""
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    for plan in plans:
        builder.row(
            InlineKeyboardButton(
                text=t(
                    "btn_tariff_option",
                    lang,
                    duration_days=plan["duration_days"],
                    price_stars=plan["price_stars"],
                ),
                callback_data=f"nav:tariff:{plan['id']}:{mode}:{target}",
            )
        )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def payment_method_menu(
    lang: str, plan_id: int, mode: str, target_id: Optional[int]
) -> InlineKeyboardMarkup:
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_stars", lang), callback_data=f"pay_stars:{mode}:{target}:{plan_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_usdt", lang), callback_data=f"pay_usdt:{mode}:{target}:{plan_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(
            text=t("btn_pay_manat", lang), callback_data=f"pay_manat:{mode}:{target}:{plan_id}"
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def invoice_keyboard(lang: str, price_stars: int) -> InlineKeyboardMarkup:
    """
    reply_markup for send_invoice: Telegram requires the first button to be
    a `pay=True` button when reply_markup is provided at all (otherwise
    Telegram auto-generates one with English "Pay {price}" text, which is
    what we're overriding here for tk/ru). '⭐' in the button text is
    rendered by Telegram as its native Star icon, not a literal emoji.
    A second row with a normal callback button (nav:back) is allowed by the
    API as long as the Pay button stays first.
    """
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_invoice_pay", lang, price=price_stars), pay=True))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def check_usdt_payment(lang: str, invoice_id: str, mode: str, target_id: Optional[int]) -> InlineKeyboardMarkup:
    target = target_id or 0
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=t("btn_i_paid", lang), callback_data=f"check_usdt:{invoice_id}:{mode}:{target}"
        )
    )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def config_ready_keyboard(lang: str, has_config: bool, subscription_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_config:
        builder.row(
            InlineKeyboardButton(text=t("btn_connect_amnezia", lang), callback_data=f"show_key:{subscription_id}")
        )
        builder.row(
            InlineKeyboardButton(text=t("btn_show_qr", lang), callback_data=f"show_qr:{subscription_id}")
        )
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def download_vpn_keyboard(lang: str, download_url: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_amnezia_download", lang), url=download_url))
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def info_keyboard(lang: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="nav:back"))
    return builder.as_markup()


def admin_menu(lang: str, show_back: bool = True) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=t("adm_btn_users", lang), callback_data="nav:admin:users"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_subs", lang), callback_data="nav:admin:subs"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_payments", lang), callback_data="nav:admin:payments"))
    builder.row(InlineKeyboardButton(text=t("adm_btn_servers", lang), callback_data="nav:admin:servers"))
    if show_back:
        builder.row(InlineKeyboardButton(text=t("btn_back", lang), callback_data="start"))
    return builder.as_markup()


def admin_back_keyboard(lang: str) -> InlineKeyboardMarkup:
    return back_keyboard(lang)
