"""
Fetches the user's saved language (via billing API) once per incoming
update and injects it into handler kwargs as `lang`. Handlers that need it
just declare `lang: str` in their signature — aiogram 3 fills it from data.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from bot.billing_client import billing_client
from bot.locales import DEFAULT_LANG

logger = logging.getLogger(__name__)


class LanguageMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        lang = DEFAULT_LANG
        is_new_user = False
        user = data.get("event_from_user")
        if user:
            try:
                me = await billing_client.get_me(user.id)
                lang = me.get("language") or ""
                is_new_user = bool(me.get("is_new"))
            except Exception as e:
                logger.warning("Failed to fetch user info for %s: %s", user.id, e)
        data["lang"] = lang
        # Only meaningful on the very first update we ever see from this
        # user (whichever it is — /start or otherwise), since get_me()'s
        # get_or_create() is what actually creates the row. A handler that
        # wants to grant something exactly once for new users (see
        # cmd_start's auto-trial) must consume this from `data` right here —
        # there's no second chance to observe it later, calling billing
        # again would just see an already-existing user.
        data["is_new_user"] = is_new_user
        return await handler(event, data)
