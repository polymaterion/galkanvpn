"""
Admin Telegram commands.
Only accessible to users in ADMIN_IDS.

Navigation is deliberately kept separate from the customer-facing flow:
every admin screen's "back" button returns to the admin panel (callback
"adm_menu", handled here), never to the customer main menu ("start", handled
in main_handlers.py). Mixing the two meant an admin browsing e.g. Users and
tapping "back" would land in the "buy a device" screen instead of back in
the admin panel — confusing and easy to mis-tap through by accident.

The admin panel respects the admin's own selected language (same `lang`
middleware-injected value as the rest of the bot) rather than being
hardcoded to Russian — every string lives in bot/locales/{ru,tk}.py under
the "adm_" prefix.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

import httpx
from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from bot import navigation
from bot.billing_client import billing_client
from bot.config import settings
from bot.keyboards.keyboards import admin_back_keyboard, admin_menu
from bot.locales import t

logger = logging.getLogger(__name__)
router = Router()


def _is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids_list


_ALLOWED_URL_SCHEMES = ("http://", "https://", "tg://")


@dataclass
class ButtonParseError(Exception):
    line_num: int
    line: str


def _parse_broadcast_buttons(text: str) -> InlineKeyboardMarkup | None:
    """
    Parses /broadcast's argument text into an inline keyboard.
    One input line = one keyboard row. Buttons within a row are separated
    by " | ". Each button is "label - url", split on the LAST " - " (so a
    label that happens to contain " - " itself doesn't break the split —
    URLs never contain a literal " - " with spaces on both sides, since
    spaces in URLs must be percent-encoded).

    Returns None for empty/whitespace-only input (no buttons requested —
    a perfectly normal case, not an error). Raises ButtonParseError with
    enough context (1-indexed line number and the offending line) for the
    caller to show the admin exactly what to fix.
    """
    text = text.strip()
    if not text:
        return None

    rows: list[list[InlineKeyboardButton]] = []
    for line_num, line in enumerate(text.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        row: list[InlineKeyboardButton] = []
        for button_spec in line.split("|"):
            button_spec = button_spec.strip()
            if " - " not in button_spec:
                raise ButtonParseError(line_num=line_num, line=line)
            label, url = button_spec.rsplit(" - ", 1)
            label, url = label.strip(), url.strip()
            if not label or not url.lower().startswith(_ALLOWED_URL_SCHEMES):
                raise ButtonParseError(line_num=line_num, line=line)
            row.append(InlineKeyboardButton(text=label, url=url))
        if row:
            rows.append(row)

    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


# --- Admin panel entry / navigation ---

@router.message(Command("admin"))
async def cmd_admin(msg: Message, state: FSMContext, lang: str):
    if not _is_admin(msg.from_user.id):
        await msg.answer(t("adm_access_denied", lang))
        return
    # Admin panel is a branch below the global main screen, so it participates
    # in the same stack and its own sub-screens can return exactly one level.
    await navigation.reset(state, "main")
    await navigation.push(state, "admin_menu")
    panel = await msg.answer(t("adm_panel_title", lang), reply_markup=admin_menu(lang))
    await navigation.set_ui_message(state, panel.message_id)


@router.callback_query(F.data == "adm_menu")
async def cb_adm_menu(cb: CallbackQuery, state: FSMContext, lang: str):
    """Back button target for every admin sub-screen — stays within the
    admin panel, never falls through to the customer menu."""
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.reset(state, "main")
    await navigation.push(state, "admin_menu")
    await navigation.set_ui_message(state, cb.message.message_id)
    await cb.message.edit_text(t("adm_panel_title", lang), reply_markup=admin_menu(lang))
    await cb.answer()


# --- Users ---
@router.callback_query(F.data == "nav:admin:users")
async def adm_users(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_users")
    try:
        data = await billing_client.admin_list_users()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    total = data.get("total", 0)
    users = data.get("items", [])
    lines = [t("adm_users_title", lang, total=total)]
    for u in users[:15]:
        uname = f"@{u['username']}" if u.get("username") else u.get("first_name", "—")
        lines.append(f"• <code>{u['telegram_id']}</code> {uname}")

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Subscriptions ---
@router.callback_query(F.data == "nav:admin:subs")
async def adm_subs(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_subs")
    try:
        data = await billing_client.admin_list_subscriptions()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    subs = data.get("items", [])
    lines = [t("adm_subs_title", lang)]
    for s in subs[:15]:
        exp = (s.get("expires_at") or "")[:10]
        lines.append(f"• #{s['id']} user={s['user_id']} [{s['status']}] до {exp}")

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Payments ---
@router.callback_query(F.data == "nav:admin:payments")
async def adm_payments(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_payments")
    try:
        data = await billing_client.admin_list_payments()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    items = data.get("items", [])
    lines = [t("adm_payments_title", lang)]
    for p in items[:15]:
        lines.append(
            f"• #{p['id']} {p['provider']} {p['amount']} {p['currency']} [{p['status']}]"
        )

    await cb.message.edit_text("\n".join(lines), reply_markup=admin_back_keyboard(lang))
    await cb.answer()


# --- Servers ---
@router.callback_query(F.data == "nav:admin:servers")
async def adm_servers(cb: CallbackQuery, state: FSMContext, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    await navigation.push(state, "admin_servers")
    try:
        data = await billing_client.admin_list_servers()
    except Exception as e:
        await cb.answer(t("adm_error", lang, error=e), show_alert=True)
        return

    items = data.get("items", [])
    lines = [t("adm_servers_title", lang)]
    for s in items:
        load = s.get("load", {})
        cpu = load.get("cpu", "?")
        lines.append(
            f"• #{s['id']} {s['name']} [{s['status']}] protocol={s.get('protocol', '?')} "
            f"{s['current_clients']}/{s['max_clients']} клиентов CPU={cpu}"
        )

    await cb.message.edit_text(
        "\n".join(lines) if items else t("adm_no_servers", lang),
        reply_markup=admin_back_keyboard(lang),
    )
    await cb.answer()


# --- Text commands for admin actions ---

@router.message(Command("extend"))
async def cmd_extend(msg: Message, lang: str):
    """Usage: /extend <sub_id> [days]"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_extend_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        days = int(parts[2]) if len(parts) > 2 else 30
        await billing_client.admin_extend_subscription(sub_id, days)
        await msg.answer(t("adm_extend_success", lang, sub_id=sub_id, days=days))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("disable_sub"))
async def cmd_disable_sub(msg: Message, lang: str):
    """Usage: /disable_sub <sub_id>"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_disable_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        await billing_client.admin_disable_subscription(sub_id)
        await msg.answer(t("adm_disable_success", lang, sub_id=sub_id))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("reissue_device"))
async def cmd_reissue_device(msg: Message, lang: str):
    """
    Usage: /reissue_device <sub_id>

    (Re-)provisions the VPN client for a subscription. Covers two cases:
    - The subscription has a VpnClient but it's broken (key looks valid but
      never connects) — the old client is best-effort deleted and a new one
      created in its place.
    - The subscription has NO VpnClient at all — e.g. the purchase went
      through but provisioning failed before any client was created (a
      common cause: no VPN server was configured in the DB yet). A fresh
      client is created for it.
    Use this any time a customer paid but doesn't have a working key.
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 2:
        await msg.answer(t("adm_reissue_usage", lang))
        return
    try:
        sub_id = int(parts[1])
        await billing_client.admin_reissue_device(sub_id)
        await msg.answer(t("adm_reissue_success", lang, sub_id=sub_id))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("server_status"))
async def cmd_server_status(msg: Message, lang: str):
    """Usage: /server_status <server_id> <active|disabled>"""
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 3:
        await msg.answer(t("adm_server_status_usage", lang))
        return
    try:
        server_id = int(parts[1])
        status = parts[2]
        await billing_client.admin_set_server_status(server_id, status)
        await msg.answer(t("adm_server_status_success", lang, server_id=server_id, status=status))
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


@router.message(Command("add_server"))
async def cmd_add_server(msg: Message, lang: str):
    """
    Usage: /add_server <name> <base_url> <api_key> [region] [weight] [max_clients] [protocol]

    Example:
      /add_server Server-DE http://45.10.20.30 8f2a1c... DE 100 200 amneziawg2

    base_url should point at the amnezia-api instance on that VPN server
    (port 80 through its nginx proxy — not 4001). api_key is the
    FASTIFY_API_KEY that amnezia-api's setup.sh printed on that server.
    protocol must match what's actually installed/enabled on that server
    (check its amnezia-api .env: PROTOCOLS_ENABLED) — "amneziawg",
    "amneziawg2" or "xray". Wrong value causes every client creation on
    this server to fail with 400 Bad Request. Defaults to "amneziawg2".
    """
    if not _is_admin(msg.from_user.id):
        return
    parts = msg.text.split()
    if len(parts) < 4:
        await msg.answer(t("adm_add_server_usage", lang))
        return
    try:
        name = parts[1]
        base_url = parts[2]
        api_key = parts[3]
        region = parts[4] if len(parts) > 4 else "EU"
        weight = int(parts[5]) if len(parts) > 5 else 100
        max_clients = int(parts[6]) if len(parts) > 6 else 200
        protocol = parts[7] if len(parts) > 7 else "amneziawg2"
        result = await billing_client.admin_add_server(
            name=name,
            base_url=base_url,
            api_key=api_key,
            region=region,
            weight=weight,
            max_clients=max_clients,
            protocol=protocol,
        )
        await msg.answer(
            t(
                "adm_add_server_success",
                lang,
                id=result["id"],
                name=result["name"],
                protocol=result["protocol"],
            )
        )
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))


# --- Broadcast --------------------------------------------------------------

@dataclass
class _PendingBroadcast:
    from_chat_id: int
    message_id: int
    reply_markup: InlineKeyboardMarkup | None
    recipient_count: int


# In-memory, not FSM state: the parsed button list can be long enough that
# stuffing it into FSMContext (which round-trips through storage on every
# get/update) is wasteful, and this only ever needs to survive between two
# messages from the same admin a few seconds apart — MemoryStorage-level
# durability is more than enough. Keyed by admin telegram_id so multiple
# admins can each have their own pending broadcast without clobbering each
# other's.
_pending_broadcasts: dict[int, _PendingBroadcast] = {}


async def _run_broadcast(bot: Bot, admin_chat_id: int, lang: str, pending: _PendingBroadcast, recipient_ids: list[int]) -> None:
    """
    Sends the copy to every recipient, respecting Telegram's ~30 msg/sec
    global rate limit with a small per-send sleep, treating
    TelegramForbiddenError (blocked the bot / deleted account — routine and
    expected at this scale, not a reason to stop) as a normal failure to
    count rather than log loudly, and honoring TelegramRetryAfter's
    requested wait instead of hammering straight into the next flood-control
    rejection. Runs as a background task (see cb_broadcast_confirm) so the
    bot's event loop keeps handling other users' updates while this is in
    flight instead of freezing on it.
    """
    sent, failed = 0, 0
    for telegram_id in recipient_ids:
        for attempt in range(2):  # one retry after a RetryAfter wait, then give up on that recipient
            try:
                await bot.copy_message(
                    chat_id=telegram_id,
                    from_chat_id=pending.from_chat_id,
                    message_id=pending.message_id,
                    reply_markup=pending.reply_markup,
                )
                sent += 1
                break
            except TelegramRetryAfter as exc:
                logger.info("Broadcast flood-controlled, waiting %ss", exc.retry_after)
                await asyncio.sleep(exc.retry_after)
                continue
            except TelegramForbiddenError:
                # Blocked the bot, deleted their account, etc. — expected
                # and routine at any real scale, not worth an error log per
                # occurrence.
                failed += 1
                break
            except Exception as exc:
                logger.warning("Broadcast to %s failed: %s", telegram_id, exc)
                failed += 1
                break
        await asyncio.sleep(0.05)  # ~20/sec, comfortably under Telegram's ~30/sec global cap

    await bot.send_message(admin_chat_id, t("adm_broadcast_done", lang, sent=sent, failed=failed))


@router.message(Command("broadcast"))
async def cmd_broadcast(msg: Message, command: CommandObject, lang: str):
    """
    Usage: reply to the message you want broadcast with /broadcast, adding
    button lines as the command's argument text if you want link buttons.
    See adm_broadcast_usage for the exact button syntax.

    This only parses and previews — nothing is sent until the admin taps
    the confirm button on the preview (see cb_broadcast_confirm). A typo'd
    /broadcast on the wrong message must not be able to reach 50 real users.
    """
    if not _is_admin(msg.from_user.id):
        return
    if not msg.reply_to_message:
        await msg.answer(t("adm_broadcast_no_reply", lang) + "\n\n" + t("adm_broadcast_usage", lang))
        return

    try:
        reply_markup = _parse_broadcast_buttons(command.args or "")
    except ButtonParseError as e:
        await msg.answer(t("adm_broadcast_bad_button", lang, line_num=e.line_num, line=e.line))
        return

    try:
        recipient_ids = await billing_client.admin_broadcast_recipients()
    except Exception as e:
        await msg.answer(t("adm_generic_error", lang, error=e))
        return

    _pending_broadcasts[msg.from_user.id] = _PendingBroadcast(
        from_chat_id=msg.chat.id,
        message_id=msg.reply_to_message.message_id,
        reply_markup=reply_markup,
        recipient_count=len(recipient_ids),
    )

    confirm_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=t("adm_broadcast_confirm_btn", lang), callback_data="broadcast_confirm"),
                InlineKeyboardButton(text=t("adm_broadcast_cancel_btn", lang), callback_data="broadcast_cancel"),
            ]
        ]
    )
    await msg.answer(
        t("adm_broadcast_confirm", lang, count=len(recipient_ids)),
        reply_markup=confirm_kb,
    )


@router.callback_query(F.data == "broadcast_confirm")
async def cb_broadcast_confirm(cb: CallbackQuery, bot: Bot, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    pending = _pending_broadcasts.pop(cb.from_user.id, None)
    if not pending:
        # Stale button (bot restarted, or this admin already confirmed/
        # cancelled it and is tapping a leftover message) — MemoryStorage
        # doesn't survive a restart, so this is the honest way to say
        # "start over" rather than silently doing nothing.
        await cb.answer(t("adm_broadcast_expired", lang), show_alert=True)
        return

    await cb.message.edit_text(t("adm_broadcast_started", lang, count=pending.recipient_count))
    await cb.answer()

    try:
        recipient_ids = await billing_client.admin_broadcast_recipients()
    except Exception as e:
        await bot.send_message(cb.from_user.id, t("adm_generic_error", lang, error=e))
        return

    # Fire-and-forget: the admin already got the "started" confirmation
    # above, and 50+ sequential Telegram API calls must not block this
    # handler (and therefore the bot's single event loop) from processing
    # anyone else's updates in the meantime.
    asyncio.create_task(_run_broadcast(bot, cb.from_user.id, lang, pending, recipient_ids))


@router.callback_query(F.data == "broadcast_cancel")
async def cb_broadcast_cancel(cb: CallbackQuery, lang: str):
    if not _is_admin(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    _pending_broadcasts.pop(cb.from_user.id, None)
    await cb.message.edit_text(t("adm_broadcast_cancelled", lang))
    await cb.answer()


# --- Trial link ---------------------------------------------------------

@router.message(Command("trial_link"))
async def cmd_trial_link(msg: Message, bot: Bot, lang: str):
    """Usage: /trial_link (no arguments) — posts the deep-link that grants
    the free trial, for sharing with users who already started the bot
    before this feature existed (new users get the trial automatically)."""
    if not _is_admin(msg.from_user.id):
        return
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start=trial"
    await msg.answer(t("adm_trial_link_message", lang, link=link))
