from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.models import (
    AuditAction,
    AuditLog,
    ManatPaymentRequest,
    ManatRequestStatus,
    Order,
    OrderStatus,
    Payment,
    PaymentProvider,
    PaymentStatus,
    Plan,
    ProcessedEvent,
    VpnClient,
    VpnClientStatus,
)


class PlanRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_active_plan(self) -> Optional[Plan]:
        result = await self.session.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.is_trial == False)
            .order_by(Plan.id)
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_trial_plan(self) -> Optional[Plan]:
        result = await self.session.execute(
            select(Plan).where(Plan.is_trial == True).limit(1)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, plan_id: int) -> Optional[Plan]:
        result = await self.session.execute(select(Plan).where(Plan.id == plan_id))
        return result.scalar_one_or_none()

    async def get_all(self) -> list[Plan]:
        result = await self.session.execute(select(Plan))
        return list(result.scalars().all())

    async def get_all_active(self) -> list[Plan]:
        """All active, non-trial plans — for the tariff selection screen.
        Sorted by duration so 1/3/6-month options display in a predictable
        order regardless of insertion order in the DB."""
        result = await self.session.execute(
            select(Plan)
            .where(Plan.is_active == True, Plan.is_trial == False)
            .order_by(Plan.duration_days)
        )
        return list(result.scalars().all())


class OrderRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, user_id: int, plan_id: int) -> Order:
        order = Order(user_id=user_id, plan_id=plan_id, status=OrderStatus.pending)
        self.session.add(order)
        await self.session.flush()
        return order

    async def get_by_id(self, order_id: int) -> Optional[Order]:
        result = await self.session.execute(select(Order).where(Order.id == order_id))
        return result.scalar_one_or_none()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[Order]:
        result = await self.session.execute(
            select(Order).offset(offset).limit(limit).order_by(Order.id.desc())
        )
        return list(result.scalars().all())


class PaymentRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_external_id(
        self, provider: PaymentProvider, external_id: str
    ) -> Optional[Payment]:
        result = await self.session.execute(
            select(Payment).where(
                Payment.provider == provider,
                Payment.external_id == external_id,
            )
        )
        return result.scalar_one_or_none()

    async def create(
        self,
        user_id: int,
        order_id: int,
        provider: PaymentProvider,
        external_id: str,
        amount: float,
        currency: str,
    ) -> Payment:
        payment = Payment(
            user_id=user_id,
            order_id=order_id,
            provider=provider,
            external_id=external_id,
            status=PaymentStatus.pending,
            amount=amount,
            currency=currency,
        )
        self.session.add(payment)
        await self.session.flush()
        return payment

    async def mark_paid(self, payment: Payment) -> None:
        payment.status = PaymentStatus.paid
        payment.paid_at = datetime.now(timezone.utc)

    async def link_subscription(self, payment: Payment, subscription_id: int) -> None:
        payment.subscription_id = subscription_id
        await self.session.flush()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[Payment]:
        result = await self.session.execute(
            select(Payment).offset(offset).limit(limit).order_by(Payment.id.desc())
        )
        return list(result.scalars().all())


class ManatRequestRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(
        self,
        user_id: int,
        plan_id: int,
        mode: str,
        amount_manat: float,
        agent_phone_shown: str,
        target_subscription_id: Optional[int] = None,
    ) -> ManatPaymentRequest:
        req = ManatPaymentRequest(
            user_id=user_id,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target_subscription_id,
            amount_manat=amount_manat,
            agent_phone_shown=agent_phone_shown,
            status=ManatRequestStatus.pending,
        )
        self.session.add(req)
        await self.session.flush()
        return req

    async def get_by_id(self, request_id: int) -> Optional[ManatPaymentRequest]:
        result = await self.session.execute(
            select(ManatPaymentRequest).where(ManatPaymentRequest.id == request_id)
        )
        return result.scalar_one_or_none()

    async def try_resolve(
        self, request_id: int, agent_id: int, new_status: ManatRequestStatus
    ) -> bool:
        """
        Atomically claims this request for `agent_id`, moving it from
        pending to `new_status` (confirmed or rejected) — but ONLY if it is
        still pending. All agents get the same notification and any of them
        may tap Confirm/Reject at any time (by design, per the product
        decision this implements), so two agents racing to act on the same
        request is the expected case to guard against, not an edge case.

        A single conditional UPDATE ... WHERE status = 'pending' is used
        instead of a SELECT-then-UPDATE: the latter would itself be the
        exact TOCTOU race this method exists to close (both agents' SELECTs
        could see "pending" before either UPDATE commits). Returns True if
        this call is the one that actually won the race (rowcount == 1),
        False if someone else already resolved it first.
        """
        result = await self.session.execute(
            update(ManatPaymentRequest)
            .where(
                ManatPaymentRequest.id == request_id,
                ManatPaymentRequest.status == ManatRequestStatus.pending,
            )
            .values(
                status=new_status,
                resolved_by_agent_id=agent_id,
                resolved_at=datetime.now(timezone.utc),
            )
        )
        won = result.rowcount == 1
        if won:
            # Raw UPDATE bypasses the ORM — if the caller already holds this
            # row in this session's identity map, sync it now so a
            # subsequent read of request.status in the same transaction
            # doesn't see the stale pre-update value. session.get() checks
            # the identity map first and issues no SQL if it's already
            # loaded.
            req = await self.session.get(ManatPaymentRequest, request_id)
            if req is not None:
                req.status = new_status
                req.resolved_by_agent_id = agent_id
        return won

    async def link_payment(self, request: ManatPaymentRequest, payment_id: int) -> None:
        request.payment_id = payment_id
        await self.session.flush()

    async def get_all(self, offset: int = 0, limit: int = 50) -> list[ManatPaymentRequest]:
        result = await self.session.execute(
            select(ManatPaymentRequest)
            .offset(offset)
            .limit(limit)
            .order_by(ManatPaymentRequest.id.desc())
        )
        return list(result.scalars().all())


class VpnClientRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(
        self,
        subscription_id: int,
        server_id: int,
        amnezia_client_id: str,
        client_name: str,
        config_url: Optional[str],
        protocol: str = "amneziawg2",
    ) -> VpnClient:
        import secrets
        vc = VpnClient(
            subscription_id=subscription_id,
            server_id=server_id,
            amnezia_client_id=amnezia_client_id,
            client_name=client_name,
            config_url=config_url,
            status=VpnClientStatus.active,
            protocol=protocol,
            public_token=secrets.token_hex(24),  # 48 hex chars, unguessable
        )
        self.session.add(vc)
        await self.session.flush()
        return vc

    async def get_by_subscription(self, subscription_id: int) -> Optional[VpnClient]:
        result = await self.session.execute(
            select(VpnClient).where(VpnClient.subscription_id == subscription_id)
        )
        return result.scalar_one_or_none()

    async def get_by_public_token(self, token: str) -> Optional[VpnClient]:
        result = await self.session.execute(
            select(VpnClient).where(VpnClient.public_token == token)
        )
        return result.scalar_one_or_none()


class ProcessedEventRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def exists(self, event_id: str) -> bool:
        result = await self.session.execute(
            select(ProcessedEvent).where(ProcessedEvent.event_id == event_id)
        )
        return result.scalar_one_or_none() is not None

    async def mark(self, event_id: str) -> None:
        evt = ProcessedEvent(event_id=event_id)
        self.session.add(evt)
        await self.session.flush()


class AuditRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def log(
        self,
        action: AuditAction,
        user_id: Optional[int] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[int] = None,
        details: Optional[str] = None,
    ) -> None:
        log = AuditLog(
            action=action,
            user_id=user_id,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
        )
        self.session.add(log)
        await self.session.flush()
