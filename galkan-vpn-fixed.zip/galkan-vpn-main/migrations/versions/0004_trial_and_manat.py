"""Add trial plan support and manat payment (Plan.is_trial, Plan.price_manat,
PaymentProvider.manat, manat_payment_requests table)

Revision ID: 0004_trial_and_manat
Revises: 0003_lang_and_public_token
Create Date: 2026-09-07
"""
from alembic import op
import sqlalchemy as sa

revision = "0004_trial_and_manat"
down_revision = "0003_lang_and_public_token"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "plans",
        sa.Column("is_trial", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.add_column(
        "plans",
        sa.Column("price_manat", sa.Numeric(14, 2), nullable=False, server_default="0"),
    )

    # ALTER TYPE ... ADD VALUE cannot run inside the same transaction that
    # later reads/writes a row using the new value (Postgres only makes a
    # new enum label visible after the adding transaction commits) — not an
    # issue here since this migration never inserts a payments row with
    # provider='manat', only changes schema. Still isolated in its own
    # autocommit block for safety across PG versions (this project runs 16,
    # see docker-compose.yml, where it's not strictly required — but cheap
    # insurance against ever running on an older PG).
    with op.get_context().autocommit_block():
        op.execute("ALTER TYPE paymentprovider ADD VALUE IF NOT EXISTS 'manat'")

    # manat_payment_requests' status column is a plain string with an
    # application-level check, NOT a Postgres enum type — deliberately
    # avoids the enum-creation footgun entirely (SQLAlchemy's automatic
    # CREATE TYPE on first column use of an Enum object cannot easily be
    # deduplicated against a separate explicit .create() call in the same
    # migration; simpler to just not use a DB-level enum for a value that's
    # already validated in Python via the ManatRequestStatus enum class).
    op.create_table(
        "manat_payment_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("plan_id", sa.Integer(), sa.ForeignKey("plans.id"), nullable=False),
        sa.Column("mode", sa.String(length=16), nullable=False),
        sa.Column(
            "target_subscription_id",
            sa.Integer(),
            sa.ForeignKey("subscriptions.id"),
            nullable=True,
        ),
        sa.Column("amount_manat", sa.Numeric(14, 2), nullable=False),
        sa.Column("agent_phone_shown", sa.String(length=32), nullable=False),
        sa.Column(
            "status",
            sa.String(length=16),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("resolved_by_agent_id", sa.BigInteger(), nullable=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("payment_id", sa.Integer(), sa.ForeignKey("payments.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
        sa.CheckConstraint(
            "status IN ('pending', 'confirmed', 'rejected', 'expired')",
            name="ck_manat_payment_requests_status",
        ),
    )
    op.create_index(
        "ix_manat_payment_requests_user_id", "manat_payment_requests", ["user_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_manat_payment_requests_user_id", table_name="manat_payment_requests")
    op.drop_table("manat_payment_requests")
    op.drop_column("plans", "price_manat")
    op.drop_column("plans", "is_trial")
    # Postgres has no ALTER TYPE ... DROP VALUE — removing an enum label
    # requires rebuilding the type (create new type, migrate column, drop
    # old type). Left as a no-op; a stray unused 'manat' label is harmless
    # once nothing references it.
