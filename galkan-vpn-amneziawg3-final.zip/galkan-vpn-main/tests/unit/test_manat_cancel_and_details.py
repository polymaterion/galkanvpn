"""
Unit tests for the payer-side manat flow (cancel / "I paid") and the shared
client+agent details used by every admin notification.
"""
import pytest
from sqlalchemy import select

from billing.repositories.other_repos import AgentRepository, ManatRequestRepository
from billing.repositories.user_repo import UserRepository
from billing.services.billing_service import (
    BillingService,
    ManatRequestAlreadyResolvedError,
    ManatRequestNotAssignedToAgentError,
)
from billing.services.manat_details import build_manat_request_details
from models.models import ManatRequestStatus, Payment, Plan, Subscription


async def _plan(session) -> Plan:
    plan = Plan(
        name="Plan 30", duration_days=30, price_stars=100, price_usdt=3.0,
        price_manat=100.0, is_active=True,
    )
    session.add(plan)
    await session.flush()
    return plan


async def _agent(session, telegram_id, phone="+993 12 000001", display_name=None):
    repo = AgentRepository(session)
    agent = await repo.create(telegram_id=telegram_id, display_name=display_name)
    await repo.add_phone(agent.id, phone, daily_limit_manat=1000)
    return agent


async def _request(session, svc, plan, telegram_id=700, **kw):
    req = await svc.create_manat_request(
        session, telegram_id=telegram_id, username=kw.get("username"),
        first_name=kw.get("first_name"), last_name=kw.get("last_name"), plan_id=plan.id,
    )
    await session.commit()
    return req


# --------------------------------------------------------------------------
# cancel
# --------------------------------------------------------------------------

@pytest.mark.parametrize("stage", ["assigned", "awaiting_payment"])
async def test_payer_can_cancel_before_reporting_payment(session, stage):
    plan = await _plan(session)
    await _agent(session, 9001)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 701)
    if stage == "awaiting_payment":
        await svc.accept_manat_request(session, request_id=req.id, agent_id=9001)
        await session.commit()

    cancelled = await svc.cancel_manat_request(session, request_id=req.id, telegram_id=701)
    await session.commit()

    assert cancelled.status == ManatRequestStatus.cancelled
    assert cancelled.resolved_at is not None
    # nothing financial was created by cancelling
    assert (await session.execute(select(Payment))).scalars().all() == []
    assert (await session.execute(select(Subscription))).scalars().all() == []


async def test_cancel_releases_the_agent_phone_capacity(session):
    """A cancelled request must stop counting against the phone's daily
    limit — otherwise 'cancel, then create a new request' would be blocked."""
    plan = await _plan(session)
    agent = await _agent(session, 9002)
    phone = (await AgentRepository(session).get_phones_for_agent(agent.id))[0]
    await AgentRepository(session).set_phone_limit(phone.id, 100)  # room for exactly one request
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 702)

    repo = AgentRepository(session)
    assert await repo.get_phone_reserved_open_total(phone.id) == 100.0

    await svc.cancel_manat_request(session, request_id=req.id, telegram_id=702)
    await session.commit()
    assert await repo.get_phone_reserved_open_total(phone.id) == 0.0

    # ...and the same payer can immediately create a new request.
    again = await _request(session, svc, plan, 702)
    assert again.status == ManatRequestStatus.assigned
    assert again.id != req.id


async def test_cancel_refused_after_payer_reported_paid(session):
    plan = await _plan(session)
    await _agent(session, 9003)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 703)
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9003)
    await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=703)
    await session.commit()

    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.cancel_manat_request(session, request_id=req.id, telegram_id=703)
    refreshed = await ManatRequestRepository(session).get_by_id(req.id)
    assert refreshed.status == ManatRequestStatus.awaiting_payment


async def test_double_cancel_second_is_rejected(session):
    plan = await _plan(session)
    await _agent(session, 9004)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 704)
    await svc.cancel_manat_request(session, request_id=req.id, telegram_id=704)
    await session.commit()
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.cancel_manat_request(session, request_id=req.id, telegram_id=704)


async def test_cancel_by_someone_else_is_not_found(session):
    plan = await _plan(session)
    await _agent(session, 9005)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 705)
    with pytest.raises(ValueError, match="not found"):
        await svc.cancel_manat_request(session, request_id=req.id, telegram_id=99999)
    # and the real owner's request is untouched
    assert (await ManatRequestRepository(session).get_by_id(req.id)).status == ManatRequestStatus.assigned


async def test_after_cancel_agent_and_admin_actions_cannot_resurrect_it(session):
    plan = await _plan(session)
    await _agent(session, 9006)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 706)
    await svc.cancel_manat_request(session, request_id=req.id, telegram_id=706)
    await session.commit()

    with pytest.raises(ManatRequestNotAssignedToAgentError):
        await svc.accept_manat_request(session, request_id=req.id, agent_id=9006)
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.report_manat_payment(session, request_id=req.id, agent_id=9006, received=True)
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.approve_manat_request(session, request_id=req.id, admin_telegram_id=1)
    assert (await session.execute(select(Subscription))).scalars().all() == []


async def test_cancelled_request_is_not_picked_up_by_timeout_sweep(session):
    from datetime import datetime, timedelta, timezone
    plan = await _plan(session)
    await _agent(session, 9007)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 707)
    await svc.cancel_manat_request(session, request_id=req.id, telegram_id=707)
    refreshed = await ManatRequestRepository(session).get_by_id(req.id)
    refreshed.assigned_at = datetime.now(timezone.utc) - timedelta(minutes=30)
    await session.commit()
    assert await svc.sweep_manat_timeouts(session) == []


# --------------------------------------------------------------------------
# payer "I paid"
# --------------------------------------------------------------------------

async def test_payer_paid_is_recorded_once(session):
    plan = await _plan(session)
    await _agent(session, 9010)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 710)
    await svc.accept_manat_request(session, request_id=req.id, agent_id=9010)
    await session.commit()

    first = await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=710)
    await session.commit()
    assert first.payer_paid_at is not None
    assert first.status == ManatRequestStatus.awaiting_payment  # status is unchanged

    with pytest.raises(ManatRequestAlreadyResolvedError):  # repeated tap
        await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=710)


async def test_payer_paid_requires_accepted_request_and_owner(session):
    plan = await _plan(session)
    await _agent(session, 9011)
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 711)  # still `assigned`, agent hasn't accepted
    with pytest.raises(ManatRequestAlreadyResolvedError):
        await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=711)
    with pytest.raises(ValueError, match="not found"):
        await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=1234)


async def test_money_not_received_resets_payer_paid_for_next_round(session):
    plan = await _plan(session)
    await _agent(session, 9012, phone="+993 12 000012")
    await _agent(session, 9013, phone="+993 12 000013")
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 712)
    first_agent_tg = (await AgentRepository(session).get_by_id(req.assigned_agent_id)).telegram_id
    await svc.accept_manat_request(session, request_id=req.id, agent_id=first_agent_tg)
    await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=712)
    await session.commit()

    after = await svc.report_manat_payment(
        session, request_id=req.id, agent_id=first_agent_tg, received=False
    )
    await session.commit()

    assert after.status == ManatRequestStatus.assigned
    assert after.assigned_agent_id is not None and after.payer_paid_at is None
    # the next agent's round can be reported again
    second_tg = (await AgentRepository(session).get_by_id(after.assigned_agent_id)).telegram_id
    assert second_tg != first_agent_tg
    await svc.accept_manat_request(session, request_id=req.id, agent_id=second_tg)
    await svc.mark_manat_payer_paid(session, request_id=req.id, telegram_id=712)


# --------------------------------------------------------------------------
# details: client + the agent LINKED to the request (never guessed by name)
# --------------------------------------------------------------------------

async def test_details_use_the_agent_linked_to_the_request(session):
    plan = await _plan(session)
    # two agents with the SAME display name: only the DB link can tell them apart
    a1 = await _agent(session, 9020, phone="+993 12 000020", display_name="Petr")
    a2 = await _agent(session, 9021, phone="+993 12 000021", display_name="Petr")
    await UserRepository(session).get_or_create(
        telegram_id=9021, username="petr_two", first_name="P", last_name="Two"
    )
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 720, username="ivan", first_name="Ivan", last_name="I")
    holder_tg = (await AgentRepository(session).get_by_id(req.assigned_agent_id)).telegram_id
    await svc.accept_manat_request(session, request_id=req.id, agent_id=holder_tg)
    await svc.report_manat_payment(session, request_id=req.id, agent_id=holder_tg, received=True)
    await session.commit()

    request = await ManatRequestRepository(session).get_by_id(req.id)
    d = await build_manat_request_details(session, request)

    assert d["status"] == "admin_review"
    assert d["amount_manat"] == 100.0
    assert d["client"] == {
        "telegram_id": 720, "username": "ivan", "first_name": "Ivan", "last_name": "I",
    }
    assert d["agent"]["telegram_id"] == holder_tg
    assert d["agent"]["id"] == request.reported_by_agent_id
    if holder_tg == 9021:
        assert d["agent"]["username"] == "petr_two"
    else:
        assert d["agent"]["username"] is None  # agent never spoke to the bot: no username known


async def test_details_agent_override_for_detached_agent(session):
    """After a decline the row no longer points at the declining agent; the
    caller can still name them explicitly."""
    plan = await _plan(session)
    a1 = await _agent(session, 9030, phone="+993 12 000030", display_name="Decliner")
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 730)
    await svc.decline_manat_request(session, request_id=req.id, agent_id=9030)  # nobody else -> expired
    await session.commit()
    request = await ManatRequestRepository(session).get_by_id(req.id)
    assert request.status == ManatRequestStatus.expired

    d = await build_manat_request_details(session, request, agent=a1)
    assert d["agent"]["display_name"] == "Decliner" and d["agent"]["telegram_id"] == 9030


async def test_sweep_events_name_the_agent_that_timed_out(session):
    from datetime import datetime, timedelta, timezone
    plan = await _plan(session)
    await _agent(session, 9040, phone="+993 12 000040")
    await _agent(session, 9041, phone="+993 12 000041")
    await session.commit()
    svc = BillingService()
    req = await _request(session, svc, plan, 740)
    first = req.assigned_agent_id
    r = await ManatRequestRepository(session).get_by_id(req.id)
    r.assigned_at = datetime.now(timezone.utc) - timedelta(minutes=10)
    await session.commit()

    events = await svc.sweep_manat_timeouts(session)
    await session.commit()
    assert events and events[0]["type"] == "reassigned"
    assert events[0]["previous_agent_id"] == first
