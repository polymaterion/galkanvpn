"""Worker: timeout outcomes are announced to every admin, failures isolated."""
from unittest.mock import AsyncMock

import pytest

from billing.repositories.other_repos import AgentRepository, ManatRequestRepository
from billing.workers import scheduler
from models.models import Plan


async def _setup(session):
    plan = Plan(name="P", duration_days=30, price_stars=1, price_usdt=1.0, price_manat=50.0, is_active=True)
    session.add(plan)
    repo = AgentRepository(session)
    a = await repo.create(telegram_id=9601, display_name="Slow Agent")
    await repo.add_phone(a.id, "+993 1", daily_limit_manat=1000)
    await session.commit()
    return plan, a


async def test_worker_notice_for_each_admin_is_sent_independently(session, monkeypatch):
    from billing.services.billing_service import BillingService
    from datetime import datetime, timedelta, timezone
    plan, agent = await _setup(session)
    svc = BillingService()
    req = await svc.create_manat_request(session, telegram_id=602, username="cl2", first_name="Cl",
                                         last_name=None, plan_id=plan.id)
    r = await ManatRequestRepository(session).get_by_id(req.id)
    r.assigned_at = datetime.now(timezone.utc) - timedelta(minutes=10)
    await session.commit()
    events = await svc.sweep_manat_timeouts(session)
    await session.commit()

    sent = []
    async def fake_send(client, chat_id, text, reply_markup=None):
        sent.append((chat_id, text))
    monkeypatch.setattr(scheduler, "_send_telegram_message", fake_send)
    monkeypatch.setenv("ADMIN_IDS", "1,2")
    async def lang_for(_): return "ru"
    await scheduler._notify_admins_of_event(None, session, lang_for, events[0])

    assert [c for c, _ in sent] == [1, 2]
    text = sent[0][1]
    for expected in ("нет доступного агента", "Slow Agent", "9601", "@cl2", "602", f"#{req.id}"):
        assert expected in text, expected
