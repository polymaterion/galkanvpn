"""
Tests for the admin notice formatter, navigation stack and the bot handlers'
manat / key / QR flows (Telegram and billing API are mocked).
"""
import os
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.base import StorageKey
from aiogram.fsm.storage.memory import MemoryStorage

os.environ.setdefault("ADMIN_IDS", "12345")

from bot import navigation
from bot.handlers import main_handlers as mh
from bot.manat_notices import KINDS, render_admin_notice
from bot.locales import LOCALES, t

DETAILS = {
    "request_id": 123, "status": "admin_review", "mode": "new", "amount_manat": 1000.0,
    "agent_phone_shown": "+993 1", "plan_duration_days": 30,
    "created_at": "2026-10-02T10:15:00+00:00", "reported_at": "2026-10-02T10:30:00+00:00",
    "payer_paid_at": None, "resolved_at": None, "rejection_reason": None,
    "client": {"telegram_id": 123456789, "username": "ivan", "first_name": "Иван", "last_name": None},
    "agent": {"id": 5, "telegram_id": 987654321, "display_name": "Пётр", "username": "agent",
              "first_name": "P", "last_name": None},
}


# ----------------------------------------------------------------- notices

@pytest.mark.parametrize("lang", ["ru", "tk"])
@pytest.mark.parametrize("kind", KINDS)
def test_every_notice_kind_renders_in_both_languages(kind, lang):
    text = render_admin_notice(kind, lang, DETAILS, prev_agent=DETAILS["agent"],
                               actor={"telegram_id": 1, "username": "adm"}, outcome="reassigned")
    assert "#123" in text and "123456789" in text and "987654321" in text
    assert "manat_" not in text  # no missing locale key leaked through


def test_review_notice_contains_client_agent_and_payment():
    text = render_admin_notice("review", "ru", DETAILS)
    for expected in ("Иван", "@ivan", "123456789", "Пётр", "@agent", "987654321",
                     "#123", "1000.0 TMT", "Ожидает подтверждения администратора", "02.10.2026 10:15"):
        assert expected in text, expected


def test_username_line_omitted_when_absent_and_html_escaped():
    d = dict(DETAILS)
    d["client"] = {"telegram_id": 5, "username": None, "first_name": "<b>X</b>", "last_name": None}
    text = render_admin_notice("created", "ru", d)
    assert "&lt;b&gt;X&lt;/b&gt;" in text and "<b>X</b>" not in text
    client_block = text.split("Агент:")[0]
    assert "Username" not in client_block


def test_explicit_agent_overrides_details_agent():
    declining = {"telegram_id": 111, "display_name": "Decliner", "username": "dec"}
    text = render_admin_notice("agent_declined", "ru", {**DETAILS, "agent": None}, agent=declining)
    assert "Decliner" in text and "@dec" in text and "111" in text


def test_locales_have_same_keys():
    assert set(LOCALES["ru"]) == set(LOCALES["tk"])


# -------------------------------------------------------------- navigation

def _state(user=1):
    return FSMContext(storage=MemoryStorage(), key=StorageKey(bot_id=1, chat_id=user, user_id=user))


async def test_push_same_screen_twice_does_not_grow_stack():
    st = _state()
    await navigation.reset(st)
    await navigation.push(st, "devices")
    await navigation.push(st, "devices")
    await navigation.push(st, "device_card", subscription_id=1)
    await navigation.push(st, "device_card", subscription_id=1)
    await navigation.push(st, "device_card", subscription_id=2)  # different params: real push
    stack = (await st.get_data())[navigation.STACK_KEY]
    assert [e["screen"] for e in stack] == ["main", "devices", "device_card", "device_card"]


async def test_back_is_safe_when_repeated_and_never_pops_root():
    st = _state()
    await navigation.reset(st)
    await navigation.push(st, "devices")
    assert (await navigation.back(st))["screen"] == "main"
    assert (await navigation.back(st))["screen"] == "main"
    assert (await navigation.back(st))["screen"] == "main"


# ---------------------------------------------------------------- handlers

def _cb(data, user_id=777, photo=False):
    msg = MagicMock()
    msg.chat.id = user_id
    msg.message_id = 50
    msg.photo = [object()] if photo else None
    msg.invoice = None
    msg.edit_text = AsyncMock()
    msg.edit_reply_markup = AsyncMock()
    msg.delete = AsyncMock()
    cb = MagicMock()
    cb.data = data
    cb.from_user = SimpleNamespace(id=user_id, username="u", first_name="F", last_name=None)
    cb.message = msg
    cb.answer = AsyncMock()
    cb.bot = MagicMock()
    cb.bot.send_message = AsyncMock(return_value=SimpleNamespace(message_id=99))
    cb.bot.send_photo = AsyncMock(return_value=SimpleNamespace(message_id=98))
    return cb


def _bot():
    b = MagicMock()
    b.id = 1
    b.send_message = AsyncMock(return_value=SimpleNamespace(message_id=77))
    b.edit_message_text = AsyncMock()
    return b


def _status_error(code):
    req = httpx.Request("POST", "http://x")
    return httpx.HTTPStatusError("e", request=req, response=httpx.Response(code, request=req))


@pytest.fixture
def billing(monkeypatch):
    client = MagicMock()
    for name in ("create_manat_request", "accept_manat_request", "decline_manat_request",
                 "report_manat_payment", "manat_payer_paid", "cancel_manat_request",
                 "admin_get_manat_request", "get_manat_request_status", "get_me",
                 "admin_approve_manat_request", "admin_reject_manat_request", "get_devices"):
        setattr(client, name, AsyncMock())
    client.get_me.return_value = {"language": "ru"}
    client.admin_get_manat_request.return_value = DETAILS
    client.get_devices.return_value = [
        {"id": 5, "status": "active", "config_url": "vpn://abc", "expires_at": "2026-12-01T00:00:00"}]
    monkeypatch.setattr(mh, "billing_client", client)
    import bot.notify as notify
    monkeypatch.setattr(notify, "billing_client", client)
    monkeypatch.setattr(notify.settings, "ADMIN_IDS", "12345,67890")
    mh._inflight.clear()
    return client


def _admin_msgs(bot):
    return [c for c in bot.send_message.await_args_list if c.args[0] in (12345, 67890)]


async def test_new_request_notifies_agent_and_every_admin(billing):
    billing.create_manat_request.return_value = {
        "request_id": 123, "amount_manat": 1000.0, "agent_phone_shown": "+993 1",
        "assigned_agent_telegram_id": 987654321}
    bot, cb, st = _bot(), _cb("pay_manat:new:0:1"), _state(777)
    await mh.cb_pay_manat(cb, bot, st, "ru")

    targets = [c.args[0] for c in bot.send_message.await_args_list]
    assert 987654321 in targets and 12345 in targets and 67890 in targets
    admin_text = next(c.args[1] for c in _admin_msgs(bot))
    assert "Новая заявка" in admin_text and "Иван" in admin_text and "Пётр" in admin_text
    # waiting screen offers Cancel (manat_cancel), not Back
    kb = cb.message.edit_text.await_args.kwargs["reply_markup"]
    assert [b.callback_data for row in kb.inline_keyboard for b in row] == ["manat_cancel:123"]


async def test_double_tap_on_pay_manat_creates_only_one_request(billing):
    import asyncio
    gate = asyncio.Event()

    async def slow(**kw):
        await gate.wait()
        return {"request_id": 1, "amount_manat": 1.0, "agent_phone_shown": "p",
                "assigned_agent_telegram_id": 5}
    billing.create_manat_request.side_effect = slow
    bot, st = _bot(), _state(777)
    t1 = asyncio.create_task(mh.cb_pay_manat(_cb("pay_manat:new:0:1"), bot, st, "ru"))
    await asyncio.sleep(0)
    await mh.cb_pay_manat(_cb("pay_manat:new:0:1"), bot, st, "ru")  # second tap, first still running
    gate.set()
    await t1
    assert billing.create_manat_request.await_count == 1


async def test_agent_decline_notifies_admins_with_agent_and_client(billing):
    billing.decline_manat_request.return_value = {
        "ok": True, "request_id": 123, "reassigned": False, "telegram_id": 123456789,
        "amount_manat": 1000.0, "status": "expired",
        "declined_by": {"telegram_id": 555, "display_name": "Decliner", "username": "dec"}}
    billing.admin_get_manat_request.return_value = {**DETAILS, "status": "expired", "agent": None}
    bot, cb = _bot(), _cb("manat_notready:123", user_id=555)
    await mh.cb_manat_agent_not_ready(cb, bot, "ru")

    texts = [c.args[1] for c in _admin_msgs(bot)]
    assert len(texts) == 2  # both admins
    assert "Агент отклонил заявку" in texts[0]
    for expected in ("Decliner", "@dec", "555", "Иван", "@ivan", "123456789", "#123", "1000.0"):
        assert expected in texts[0], expected
    assert "закрыта" in texts[0]  # outcome: nobody left


async def test_decline_409_does_not_notify_admins(billing):
    billing.decline_manat_request.side_effect = _status_error(409)
    bot, cb = _bot(), _cb("manat_notready:123", user_id=555)
    await mh.cb_manat_agent_not_ready(cb, bot, "ru")
    assert _admin_msgs(bot) == []
    cb.message.edit_text.assert_not_awaited()  # stale tap must not overwrite the message


async def test_report_yes_sends_review_screen_with_details_and_buttons(billing):
    billing.report_manat_payment.return_value = {
        "ok": True, "request_id": 123, "telegram_id": 123456789, "amount_manat": 1000.0,
        "status": "admin_review", "reported_by": DETAILS["agent"]}
    bot, cb = _bot(), _cb("manat_report_yes:123", user_id=987654321)
    await mh.cb_manat_agent_report_yes(cb, bot, "ru")

    calls = _admin_msgs(bot)
    assert len(calls) == 2
    text = calls[0].args[1]
    for expected in ("Новая оплата", "Иван", "@ivan", "123456789", "Пётр", "@agent", "987654321",
                     "#123", "1000.0 TMT", "Ожидает подтверждения администратора"):
        assert expected in text, expected
    kb = calls[0].kwargs["reply_markup"]
    assert [b.callback_data for row in kb.inline_keyboard for b in row] == [
        "manat_admin_approve:123", "manat_admin_reject:123"]


async def test_one_unreachable_admin_does_not_block_the_others(billing):
    billing.report_manat_payment.return_value = {
        "ok": True, "request_id": 123, "telegram_id": 1, "amount_manat": 1.0,
        "status": "admin_review", "reported_by": DETAILS["agent"]}
    bot, cb = _bot(), _cb("manat_report_yes:123", user_id=987654321)

    async def flaky(chat_id, *a, **k):
        if chat_id == 12345:
            raise RuntimeError("blocked")
        return SimpleNamespace(message_id=1)
    bot.send_message.side_effect = flaky
    await mh.cb_manat_agent_report_yes(cb, bot, "ru")
    assert 67890 in [c.args[0] for c in bot.send_message.await_args_list]


async def test_details_lookup_failure_still_notifies_admins(billing):
    billing.admin_get_manat_request.side_effect = RuntimeError("down")
    billing.report_manat_payment.return_value = {
        "ok": True, "request_id": 123, "telegram_id": 321, "amount_manat": 40.0,
        "status": "admin_review", "reported_by": DETAILS["agent"]}
    bot, cb = _bot(), _cb("manat_report_yes:123", user_id=987654321)
    await mh.cb_manat_agent_report_yes(cb, bot, "ru")
    texts = [c.args[1] for c in _admin_msgs(bot)]
    assert len(texts) == 2 and "#123" in texts[0] and "987654321" in texts[0] and "321" in texts[0]


async def test_payer_paid_notifies_agent_and_admins_once(billing):
    billing.manat_payer_paid.return_value = {
        "ok": True, "status": "awaiting_payment", "amount_manat": 1000.0,
        "assigned_agent_telegram_id": 987654321}
    bot, cb, st = _bot(), _cb("manat_paid:123"), _state(777)
    await mh.cb_manat_payer_paid(cb, bot, st, "ru")
    targets = [c.args[0] for c in bot.send_message.await_args_list]
    assert targets.count(987654321) == 1 and 12345 in targets
    kb = cb.message.edit_text.await_args.kwargs["reply_markup"]
    assert [b.callback_data for row in kb.inline_keyboard for b in row] == ["start"]  # no Cancel after paying


async def test_repeated_payer_paid_tap_is_ignored(billing):
    billing.manat_payer_paid.side_effect = _status_error(409)
    billing.get_manat_request_status.return_value = {"status": "awaiting_payment", "payer_paid": True}
    bot, cb, st = _bot(), _cb("manat_paid:123"), _state(777)
    await mh.cb_manat_payer_paid(cb, bot, st, "ru")
    bot.send_message.assert_not_awaited()
    cb.answer.assert_awaited()


async def test_cancel_resets_state_and_notifies_agent_and_admins(billing):
    billing.cancel_manat_request.return_value = {
        "ok": True, "status": "cancelled", "amount_manat": 1000.0,
        "assigned_agent_telegram_id": 987654321}
    billing.admin_get_manat_request.return_value = {**DETAILS, "status": "cancelled"}
    bot, cb, st = _bot(), _cb("manat_cancel:123", user_id=123456789), _state(123456789)
    await navigation.reset(st)
    await navigation.push(st, "manat_pay", request_id=123, amount=1000.0, phone="p")

    await mh.cb_manat_cancel(cb, bot, st, "ru")

    assert (await navigation.current(st))["screen"] == "main"
    assert "отменена" in cb.message.edit_text.await_args.args[0]
    targets = [c.args[0] for c in bot.send_message.await_args_list]
    assert 987654321 in targets and 12345 in targets and 67890 in targets
    admin_text = next(c.args[1] for c in _admin_msgs(bot))
    assert "Клиент отменил заявку" in admin_text and "Отменена клиентом" in admin_text


async def test_cancel_after_paid_is_refused_with_clear_message(billing):
    billing.cancel_manat_request.side_effect = _status_error(409)
    billing.get_manat_request_status.return_value = {"status": "awaiting_payment", "payer_paid": True}
    bot, cb, st = _bot(), _cb("manat_cancel:123"), _state(777)
    await mh.cb_manat_cancel(cb, bot, st, "ru")
    assert "нельзя" in cb.answer.await_args.args[0]
    bot.send_message.assert_not_awaited()


async def test_agent_accept_edits_payers_waiting_screen_with_paid_and_cancel(billing):
    billing.accept_manat_request.return_value = {
        "ok": True, "telegram_id": 321, "amount_manat": 40.0, "agent_phone_shown": "+993 9"}
    bot, st = _bot(), _state(555)
    payer_state = FSMContext(storage=st.storage, key=StorageKey(bot_id=1, chat_id=321, user_id=321))
    await navigation.reset(payer_state)
    await navigation.push(payer_state, "manat_pending", request_id=123)
    await navigation.set_ui_message(payer_state, 42)

    await mh.cb_manat_agent_ready(_cb("manat_ready:123", user_id=555), bot, st, "ru")

    bot.edit_message_text.assert_awaited()
    kw = bot.edit_message_text.await_args.kwargs
    assert kw["chat_id"] == 321 and kw["message_id"] == 42
    assert [b.callback_data for row in kw["reply_markup"].inline_keyboard for b in row] == [
        "manat_paid:123", "manat_cancel:123"]
    assert (await navigation.current(payer_state))["screen"] == "manat_pay"
    # payer was NOT sent a second message
    assert 321 not in [c.args[0] for c in bot.send_message.await_args_list]


async def test_admin_buttons_reject_non_admins(billing):
    cb = _cb("manat_admin_approve:123", user_id=999)
    await mh.cb_manat_admin_approve(cb, _bot(), "ru")
    billing.admin_approve_manat_request.assert_not_awaited()
    cb2 = _cb("manat_admin_reject:123", user_id=999)
    await mh.cb_manat_admin_reject(cb2, _bot(), "ru")
    billing.admin_reject_manat_request.assert_not_awaited()


async def test_admin_decision_notifies_other_admins_only(billing):
    billing.admin_approve_manat_request.return_value = {
        "ok": True, "subscription_id": 5, "telegram_id": 123456789, "expires_at": "2026-11-01T00:00:00",
        "config_url": "vpn://x"}
    bot, cb = _bot(), _cb("manat_admin_approve:123", user_id=12345)
    await mh.cb_manat_admin_approve(cb, bot, "ru")
    admin_targets = [c.args[0] for c in _admin_msgs(bot)]
    assert admin_targets == [67890]  # acting admin (12345) excluded
    assert "подтверждена администратором" in _admin_msgs(bot)[0].args[1]
    assert 123456789 in [c.args[0] for c in bot.send_message.await_args_list]  # payer got the key screen


async def test_stale_admin_tap_does_not_overwrite_message(billing):
    billing.admin_approve_manat_request.side_effect = _status_error(409)
    bot, cb = _bot(), _cb("manat_admin_approve:123", user_id=12345)
    await mh.cb_manat_admin_approve(cb, bot, "ru")
    cb.message.edit_text.assert_not_awaited()
    assert _admin_msgs(bot) == []


# ---------------------------------------------------------- key / QR screens

async def test_key_screen_edits_in_place_and_back_returns_to_card(billing):
    st = _state(777)
    await navigation.reset(st)
    await navigation.push(st, "devices")
    await navigation.push(st, "device_card", subscription_id=5)

    cb = _cb("show_key:5")
    await mh.cb_show_key(cb, st, "ru")
    assert "vpn://abc" in cb.message.edit_text.await_args.args[0]
    kb = cb.message.edit_text.await_args.kwargs["reply_markup"]
    assert [b.callback_data for row in kb.inline_keyboard for b in row] == ["nav:back"]

    # double tap on a stale copy of the same button: stack must not grow
    await mh.cb_show_key(_cb("show_key:5"), st, "ru")
    stack = (await st.get_data())[navigation.STACK_KEY]
    assert [e["screen"] for e in stack] == ["main", "devices", "device_card", "device_key"]

    back = _cb("nav:back")
    await mh.cb_back(back, st, "ru")
    assert (await navigation.current(st))["screen"] == "device_card"
    # repeated Back is harmless
    await mh.cb_back(_cb("nav:back"), st, "ru")
    await mh.cb_back(_cb("nav:back"), st, "ru")
    assert (await navigation.current(st))["screen"] == "main"


async def test_qr_screen_replaces_card_and_back_restores_it(billing):
    st = _state(777)
    await navigation.reset(st)
    await navigation.push(st, "devices")
    await navigation.push(st, "device_card", subscription_id=5)

    cb = _cb("show_qr:5")
    await mh.cb_show_qr(cb, cb.bot, st, "ru")
    cb.bot.send_photo.assert_awaited_once()
    kb = cb.bot.send_photo.await_args.kwargs["reply_markup"]
    assert [b.callback_data for row in kb.inline_keyboard for b in row] == ["nav:back"]
    cb.message.delete.assert_awaited_once()          # card replaced, not duplicated
    assert await navigation.get_ui_message_id(st) == 98
    assert (await navigation.current(st))["screen"] == "device_qr"

    # Back from the photo message: new text screen sent, photo removed
    photo_msg = _cb("nav:back", photo=True)
    await mh.cb_back(photo_msg, st, "ru")
    photo_msg.bot.send_message.assert_awaited_once()
    photo_msg.message.delete.assert_awaited_once()
    photo_msg.message.edit_text.assert_not_awaited()  # would be rejected by Telegram on a photo
    assert (await navigation.current(st))["screen"] == "device_card"
    assert await navigation.get_ui_message_id(st) == 99


async def test_key_from_foreign_stack_still_returns_to_the_device_card(billing):
    """The Connect button also arrives on 'payment approved' messages sent
    outside the user's own navigation; Back must not land on an unrelated screen."""
    st = _state(777)
    await navigation.reset(st)
    await navigation.push(st, "manat_pending", request_id=1)  # unrelated leftover context
    await mh.cb_show_key(_cb("show_key:5"), st, "ru")
    await mh.cb_back(_cb("nav:back"), st, "ru")
    assert (await navigation.current(st))["screen"] == "device_card"


async def test_qr_unavailable_leaves_screen_untouched(billing):
    billing.get_devices.return_value = []
    st = _state(777)
    await navigation.reset(st)
    cb = _cb("show_qr:5")
    await mh.cb_show_qr(cb, cb.bot, st, "ru")
    cb.message.delete.assert_not_awaited()
    cb.bot.send_photo.assert_not_awaited()
    assert (await navigation.current(st))["screen"] == "main"
