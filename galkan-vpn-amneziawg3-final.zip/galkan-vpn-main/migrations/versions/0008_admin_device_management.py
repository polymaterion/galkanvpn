"""Add admin-issued subscription support (/add_device, /delete_device) and
fix missing Postgres enum values that were causing manat admin/agent
actions to fail with unhandled 500s.

Changes:
  - paymentprovider: add 'admin_grant' — used by
    BillingService.admin_grant_subscription (/add_device) to record a
    zero-amount Payment through the exact same idempotent
    order/payment/subscription/provisioning path as every paid provider.
  - auditaction: add 'subscription_deleted' and 'subscription_admin_granted'
    for the new admin_delete_subscription / admin_grant_subscription
    methods.
  - manat_payment_requests: drop the "manat payment is 1-month-plan-only"
    restriction — the plan_id column and its FK are unrestricted already
    (the restriction lived entirely in application code, now removed), so
    there is no schema change needed for that part; noted here for
    completeness since it's part of the same request.

Revision ID: 0008_admin_device_management
Revises: 0007_manat_admin_review
Create Date: 2026-09-27
"""
from alembic import op

revision = "0008_admin_device_management"
down_revision = "0007_manat_admin_review"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ALTER TYPE ... ADD VALUE cannot run inside the same transaction as a
    # later statement that might use the new value on some Postgres
    # versions — autocommit_block() runs each statement in its own
    # implicitly-committed block, sidestepping that restriction. Also see
    # 0007_manat_admin_review, which fixes the same class of bug for the
    # manat_* audit actions that were introduced there but never added to
    # the DB-level enum.
    with op.get_context().autocommit_block():
        op.execute("ALTER TYPE paymentprovider ADD VALUE IF NOT EXISTS 'admin_grant'")
        op.execute("ALTER TYPE auditaction ADD VALUE IF NOT EXISTS 'subscription_deleted'")
        op.execute("ALTER TYPE auditaction ADD VALUE IF NOT EXISTS 'subscription_admin_granted'")


def downgrade() -> None:
    # Postgres has no ALTER TYPE ... DROP VALUE — removing an enum value
    # requires rebuilding the type from a new one and repointing every
    # column that uses it. Not implemented here since doing so would
    # destroy any row that came to use 'admin_grant', 'subscription_deleted'
    # or 'subscription_admin_granted' in the meantime; roll back to a DB
    # snapshot taken before this migration if you need to undo it.
    pass
