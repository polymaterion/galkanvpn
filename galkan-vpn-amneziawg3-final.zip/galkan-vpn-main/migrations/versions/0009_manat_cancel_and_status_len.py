"""Manat payer-cancel support + widen manat_payment_requests.status.

Changes (both additive / non-destructive — no data is touched):
  - manat_payment_requests.payer_paid_at (nullable timestamptz): set
    atomically when the payer taps "Я перевёл". Lets the service (a) make a
    repeated tap idempotent and (b) refuse a payer-side cancel once the
    payer has claimed a transfer (money may already be on the way), without
    adding a new request status.
  - manat_payment_requests.status: VARCHAR(16) -> VARCHAR(32). The column
    was created as VARCHAR(16) in 0004, but ManatRequestStatus has values
    longer than that ("provisioning_failed" is 19 characters), so on
    PostgreSQL the failure branch of approve_manat_request could not
    persist its own status ("value too long for type character varying").
    Widening a VARCHAR never rewrites or invalidates existing rows, and the
    CHECK constraint from 0007 stays valid unchanged.

Revision ID: 0009_manat_cancel_and_status_len
Revises: 0008_admin_device_management
Create Date: 2026-10-02
"""
from alembic import op
import sqlalchemy as sa

revision = "0009_manat_cancel_and_status_len"
down_revision = "0008_admin_device_management"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "manat_payment_requests",
        sa.Column("payer_paid_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.alter_column(
        "manat_payment_requests",
        "status",
        existing_type=sa.String(length=16),
        type_=sa.String(length=32),
        existing_nullable=False,
        existing_server_default="awaiting_agent",
    )


def downgrade() -> None:
    op.drop_column("manat_payment_requests", "payer_paid_at")
    # The status column is intentionally NOT narrowed back to VARCHAR(16):
    # rows may legitimately hold "provisioning_failed" (19 chars) by now,
    # and shrinking would either fail or truncate real data. The wider
    # column is harmless to older code.
