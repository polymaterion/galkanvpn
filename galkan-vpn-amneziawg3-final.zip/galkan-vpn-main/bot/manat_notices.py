"""
Admin-facing text for manat payment requests.

Pure formatting only — deliberately free of aiogram/Telegram imports so it can
be used both by the bot process (bot/handlers/main_handlers.py) and by the
billing worker (billing/workers/scheduler.py, which runs from the billing image
that has no aiogram installed and talks to Telegram over raw HTTP).

Every notice has the same shape — title, then the same Client / Agent / Request
blocks — so an admin reading any status change can tell at a glance WHICH
client and WHICH agent it concerns. The data comes from
billing.services.manat_details.build_manat_request_details (agent resolved
from the request's own DB link), passed in here as a plain dict.

All user-controlled strings (names, usernames) are HTML-escaped: the bot and the
worker both send with parse_mode=HTML, and a name containing "<" would
otherwise make Telegram reject the whole notification.
"""
from __future__ import annotations

import html
from datetime import datetime, timezone
from typing import Any, Optional

from bot.locales import t

# Notice kinds. Each maps to locale key manat_notice_title_<kind>.
KINDS = (
    "created",
    "agent_accepted",
    "payer_paid",
    "review",
    "agent_declined",
    "agent_money_not_received",
    "payer_cancelled",
    "admin_approved",
    "admin_rejected",
    "timeout_reassigned",
    "expired_no_agent",
    "expired_payment_window",
)


def format_dt(value: Optional[str]) -> str:
    """ISO timestamp -> 'DD.MM.YYYY HH:MM UTC' (naive values are treated as
    UTC, which is what the DB stores)."""
    if not value:
        return "—"
    try:
        dt = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return str(value)[:16]
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).strftime("%d.%m.%Y %H:%M UTC")


def _full_name(first: Optional[str], last: Optional[str]) -> str:
    return " ".join(p for p in (first, last) if p).strip()


def _person_block(lang: str, header_key: str, person: Optional[dict[str, Any]], *, prefer_display: bool) -> str:
    """Name / Username / Telegram ID. Username line is omitted when the person
    has none (spec: 'username, если он существует')."""
    header = f"<b>{t(header_key, lang)}</b>"
    if not person:
        return f"{header}\n{t('manat_agent_none', lang)}"
    name = ""
    if prefer_display:
        name = (person.get("display_name") or "").strip()
    if not name:
        name = _full_name(person.get("first_name"), person.get("last_name"))
    lines = [header, f"{t('manat_lbl_name', lang)}: {html.escape(name) if name else '—'}"]
    if person.get("username"):
        lines.append(f"{t('manat_lbl_username', lang)}: @{html.escape(person['username'])}")
    lines.append(f"{t('manat_lbl_tgid', lang)}: <code>{person.get('telegram_id')}</code>")
    return "\n".join(lines)


def _request_block(lang: str, d: dict[str, Any]) -> str:
    status = d.get("status") or ""
    status_label = t(f"manat_status_{status}", lang) if status else "—"
    lines = [
        f"<b>{t('manat_lbl_request', lang)}:</b> #{d['request_id']}",
        f"{t('manat_lbl_amount', lang)}: {d.get('amount_manat')} TMT",
        f"{t('manat_lbl_status', lang)}: {status_label}",
    ]
    if d.get("plan_duration_days"):
        lines.append(
            f"{t('manat_lbl_plan', lang)}: {t('manat_unit_days', lang, days=d['plan_duration_days'])}"
        )
    lines.append(f"{t('manat_lbl_created', lang)}: {format_dt(d.get('created_at'))}")
    if d.get("payer_paid_at"):
        lines.append(f"{t('manat_lbl_paid', lang)}: {format_dt(d['payer_paid_at'])}")
    if d.get("reported_at"):
        lines.append(f"{t('manat_lbl_reported', lang)}: {format_dt(d['reported_at'])}")
    if d.get("resolved_at"):
        lines.append(f"{t('manat_lbl_resolved', lang)}: {format_dt(d['resolved_at'])}")
    if d.get("rejection_reason"):
        lines.append(f"{t('manat_lbl_reason', lang)}: {html.escape(str(d['rejection_reason']))}")
    return "\n".join(lines)


def render_admin_notice(
    kind: str,
    lang: str,
    details: dict[str, Any],
    *,
    agent: Optional[dict[str, Any]] = None,
    prev_agent: Optional[dict[str, Any]] = None,
    actor: Optional[dict[str, Any]] = None,
    outcome: Optional[str] = None,
) -> str:
    """
    kind        one of KINDS
    details     build_manat_request_details() dict (client, agent, request)
    agent       overrides details["agent"] — used when the agent concerned has
                already been detached from the request row (an agent who just
                declined / reported "money not received")
    prev_agent  agent who failed to answer in time (timeout reassignment)
    actor       the admin who made the decision, {"telegram_id", "username",
                "first_name", "last_name"} — for admin_approved/admin_rejected
    outcome     'reassigned' | 'no_agent' — what happened to the request after
                an agent declined / reported no money
    """
    parts = [t(f"manat_notice_title_{kind}", lang)]
    parts.append(_person_block(lang, "manat_hdr_client", details.get("client"), prefer_display=False))
    parts.append(
        _person_block(lang, "manat_hdr_agent", agent if agent is not None else details.get("agent"), prefer_display=True)
    )
    if prev_agent:
        parts.append(_person_block(lang, "manat_hdr_prev_agent", prev_agent, prefer_display=True))
    parts.append(_request_block(lang, details))
    if actor:
        actor_name = _full_name(actor.get("first_name"), actor.get("last_name"))
        label = f"@{html.escape(actor['username'])}" if actor.get("username") else html.escape(actor_name or "—")
        parts.append(
            t("manat_notice_actor", lang, admin=f"{label} (<code>{actor.get('telegram_id')}</code>)")
        )
    if outcome:
        parts.append(t(f"manat_notice_outcome_{outcome}", lang))
    if kind == "review":
        parts.append(t("manat_notice_footer_review", lang))
    return "\n\n".join(parts)


def minimal_details(
    request_id: int,
    *,
    amount: Any = None,
    status: Optional[str] = None,
    client_telegram_id: Optional[int] = None,
) -> dict[str, Any]:
    """Fallback when the details endpoint is unreachable: still a valid
    `details` dict (with just what the triggering call returned) so a failed
    lookup degrades the notice instead of dropping it."""
    return {
        "request_id": request_id,
        "status": status or "",
        "amount_manat": amount,
        "client": {"telegram_id": client_telegram_id} if client_telegram_id else None,
        "agent": None,
    }
