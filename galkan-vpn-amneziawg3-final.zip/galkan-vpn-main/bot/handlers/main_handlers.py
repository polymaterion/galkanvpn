"""Customer-facing Telegram screens.

The bot keeps one UI message per conversation. Callback handlers push a
screen into the FSM navigation stack and render it by editing that message.
The only intentional extra Telegram messages are payment invoices and QR
images, both of which Telegram requires to be separate message types.
"""
from __future__ import annotations

import html
import logging
from typing import Any

import httpx
from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.base import BaseStorage, StorageKey
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    SuccessfulPayment,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot import navigation
from bot.billing_client import billing_client
from bot.config import settings
from bot.keyboards.keyboards import (
    agent_phones_keyboard,
    back_keyboard,
    check_usdt_payment,
    config_ready_keyboard,
    device_card_keyboard,
    devices_keyboard,
    download_vpn_keyboard,
    info_keyboard,
    invoice_keyboard,
    language_picker,
    main_menu,
    manat_agent_accept_keyboard,
    manat_agent_confirm_keyboard,
    manat_admin_review_keyboard,
    manat_payer_paid_keyboard,
    manat_waiting_keyboard,
    payment_method_menu,
    tariff_select_keyboard,
    to_menu_keyboard,
)
from bot.locales import t
from bot.notify import fetch_details, notify_admins, send_safe, user_lang
from bot.payments.crypto_pay import crypto_pay
from bot.utils import generate_qr

logger = logging.getLogger(__name__)
router = Router()

STATUS_EMOJI = {
    "active": "✅",
    "expired": "❌",
    "pending_provisioning": "⏳",
    "error": "⚠️",
    "disabled": "🔒",
    "pending_payment": "💸",
}


async def _edit_view(
    message: Message,
    state: FSMContext,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs: Any,
) -> None:
    try:
        await message.edit_text(text, reply_markup=reply_markup, **kwargs)
    except TelegramBadRequest as exc:
        # Telegram returns this for a repeated tap on an already rendered
        # screen. It is safe to acknowledge and keep the current view.
        if "message is not modified" not in str(exc).lower():
            raise
    await navigation.set_ui_message(state, message.message_id)


async def _edit_ui_message(
    bot: Bot,
    chat_id: int,
    state: FSMContext,
    text: str,
    reply_markup: InlineKeyboardMarkup | None = None,
    **kwargs: Any,
) -> bool:
    message_id = await navigation.get_ui_message_id(state)
    if not message_id:
        return False
    try:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
            **kwargs,
        )
        return True
    except TelegramBadRequest as exc:
        if "message is not modified" in str(exc).lower():
            return True
        logger.warning("Unable to edit navigation message %s: %s", message_id, exc)
        return False


async def _main_view(lang: str) -> tuple[str, InlineKeyboardMarkup]:
    return t("welcome", lang), main_menu(lang, settings.SUPPORT_LINK)


async def _devices_view(
    telegram_id: int, lang: str
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        devices = await billing_client.get_devices(telegram_id)
    except Exception as exc:
        logger.error("get_devices failed: %s", exc)
        devices = []

    if not devices:
        return t("devices_empty", lang), back_keyboard(lang)

    lines = [t("devices_title", lang), ""]
    for number, device in enumerate(devices, start=1):
        emoji = STATUS_EMOJI.get(device["status"], "❔")
        lines.append(t("device_line", lang, emoji=emoji, n=number))
    return "\n".join(lines), devices_keyboard(lang, devices)


async def _device_view(
    telegram_id: int, lang: str, subscription_id: int
) -> tuple[str, InlineKeyboardMarkup | None]:
    try:
        devices = await billing_client.get_devices(telegram_id)
    except Exception as exc:
        logger.error("get_devices failed: %s", exc)
        devices = []
    device_number = next(
        (number for number, item in enumerate(devices, start=1) if item["id"] == subscription_id),
        None,
    )
    if device_number is None:
        return t("no_active_device", lang), back_keyboard(lang)

    device = devices[device_number - 1]
    status = t(f"status_{device['status']}", lang)
    expires = (device.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
    text = t(
        "device_card",
        lang,
        n=device_number,
        status=status,
        expires=expires,
    )
    return text, device_card_keyboard(lang, device, device_number)


async def _tariff_select_view(
    lang: str, mode: str, target_id: int | None = None
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        plans = await billing_client.get_plans()
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plans = []
    if not plans:
        return t("plan_unavailable", lang), back_keyboard(lang)
    text = t("tariff_select_title", lang)
    return text, tariff_select_keyboard(lang, plans, mode, target_id)


async def _plan_view(
    lang: str, mode: str, plan_id: int, target_id: int | None = None
) -> tuple[str, InlineKeyboardMarkup]:
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plan = None
    if not plan:
        return t("plan_unavailable", lang), back_keyboard(lang)

    if mode == "renew":
        number = target_id or 0
        # The number is only cosmetic; the subscription id remains the source
        # of truth for the payment payload.
        text = t("renew_card", lang, n=number, duration_days=plan["duration_days"])
    else:
        text = t(
            "plan_card",
            lang,
            name=t("plan_name_text", lang, duration_days=plan["duration_days"]),
            duration_days=plan["duration_days"],
        )
    return text, payment_method_menu(lang, plan, mode, target_id)


async def _resolve_screen(
    message: Message, state: FSMContext, lang: str, entry: dict[str, Any]
) -> tuple[str, InlineKeyboardMarkup | None]:
    screen = entry.get("screen", "main")
    params = entry.get("params", {})
    if screen == "main":
        text, markup = await _main_view(lang)
    elif screen == "devices":
        text, markup = await _devices_view(message.chat.id, lang)
    elif screen == "device_card":
        text, markup = await _device_view(message.chat.id, lang, int(params["subscription_id"]))
    elif screen == "purchase_new":
        text, markup = await _tariff_select_view(lang, "new")
    elif screen == "renew":
        text, markup = await _tariff_select_view(lang, "renew", int(params["subscription_id"]))
    elif screen == "plan_confirm":
        text, markup = await _plan_view(
            lang,
            params["mode"],
            int(params["plan_id"]),
            params.get("target_id"),
        )
    elif screen == "support":
        text, markup = t("support_text", lang, support_link=settings.SUPPORT_LINK), back_keyboard(lang)
    elif screen == "download_vpn":
        text = t("download_vpn_text", lang)
        markup = download_vpn_keyboard(
            lang, settings.GOOGLE_PLAY_LINK, settings.APP_STORE_LINK, settings.ANDROID_APK_LINK
        )
    elif screen == "info":
        text = t("info_text", lang)
        markup = info_keyboard(
            lang, settings.PRIVACY_POLICY_LINK, settings.TERMS_OF_SERVICE_LINK, settings.CHANNEL_LINK
        )
    elif screen == "language":
        text, markup = t("language_prompt", lang), language_picker(lang, include_back=True)
    elif screen == "config_ready":
        text = t("config_ready", lang, expires=params.get("expires") or t("unknown_expiry", lang))
        markup = config_ready_keyboard(
            lang, bool(params.get("config_url")), int(params["subscription_id"])
        )
    elif screen == "provisioning":
        text, markup = t("provisioning_pending", lang), back_keyboard(lang)
    elif screen == "device_key":
        sub_id = int(params["subscription_id"])
        config_url = await _get_device_config_url(message.chat.id, sub_id)
        if config_url:
            text = t("config_key_message", lang, config_url=html.escape(config_url))
            markup = back_keyboard(lang)
        else:
            text, markup = await _device_view(message.chat.id, lang, sub_id)
    elif screen == "device_qr":
        # A QR screen is a photo message and can't be re-rendered as text;
        # its parent (the device card) is the closest valid screen.
        text, markup = await _device_view(message.chat.id, lang, int(params["subscription_id"]))
    elif screen == "manat_pending":
        text = t("manat_awaiting_agent", lang)
        markup = manat_waiting_keyboard(lang, int(params["request_id"]))
    elif screen == "manat_pay":
        text = t("manat_request_created", lang, amount=params["amount"], phone=params["phone"])
        markup = manat_payer_paid_keyboard(lang, int(params["request_id"]), params["amount"])
    else:
        text, markup = await _main_view(lang)
        await navigation.reset(state)
    return text, markup


async def _render_entry(
    message: Message, state: FSMContext, lang: str, entry: dict[str, Any]
) -> None:
    text, markup = await _resolve_screen(message, state, lang, entry)
    await _edit_view(message, state, text, markup, disable_web_page_preview=True)


async def _deliver_result(
    bot: Bot,
    chat_id: int,
    lang: str,
    state: FSMContext,
    result: dict,
    fallback_message: Message | None = None,
) -> None:
    config_url = result.get("config_url")
    sub_id = result["subscription_id"]
    expires = (result.get("expires_at") or "")[:10] or t("unknown_expiry", lang)
    if not config_url:
        await navigation.replace(state, "provisioning")
        text, markup = t("provisioning_pending", lang), back_keyboard(lang)
    else:
        await navigation.replace(
            state,
            "config_ready",
            subscription_id=sub_id,
            config_url=config_url,
            expires=expires,
        )
        text = t("config_ready", lang, expires=expires)
        markup = config_ready_keyboard(lang, True, sub_id)

    edited = await _edit_ui_message(bot, chat_id, state, text, markup, disable_web_page_preview=True)
    if edited or fallback_message is None:
        return
    await fallback_message.answer(text, reply_markup=markup, disable_web_page_preview=True)


async def _get_device_config_url(telegram_id: int, sub_id: int) -> str | None:
    try:
        devices = await billing_client.get_devices(telegram_id)
        device = next((item for item in devices if item["id"] == sub_id), None)
        return device.get("config_url") if device else None
    except Exception as exc:
        logger.warning("Failed to fetch device %s: %s", sub_id, exc)
        return None


# In-flight guard: a second tap on the same button while the first is still
# being processed (the handlers await HTTP calls, so Telegram can deliver both
# before the screen is edited) is ignored instead of creating a duplicate
# request / a duplicate QR message. Per-process, which matches the bot's
# single-process polling deployment.
_inflight: set[tuple[int, str]] = set()


def _tg_actor(user) -> dict[str, Any]:
    """Telegram-side identity of whoever tapped a button, in the same shape
    the billing API uses for clients/agents/admins."""
    return {
        "telegram_id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
    }


async def _ensure_device_context(state: FSMContext, subscription_id: int) -> None:
    """Make sure the screen being left is this device's own screen, so that
    "Назад" from a key / QR screen always lands on it. The Connect / QR
    buttons also arrive on messages the bot sent outside the user's own
    navigation (e.g. the "payment approved" message after a manat payment),
    where the stored stack belongs to some unrelated screen."""
    cur = await navigation.current(state)
    params = cur.get("params", {})
    # device_key / device_qr count too: a stale copy of the Connect / QR button
    # tapped while that screen is already on top must not rebuild the stack
    # (push() then de-duplicates the repeated screen).
    if (
        cur.get("screen") in ("device_card", "config_ready", "device_key", "device_qr")
        and params.get("subscription_id") == subscription_id
    ):
        return
    await navigation.reset(state, "main")
    await navigation.push(state, "device_card", subscription_id=subscription_id)


PENDING_DEEP_LINK_KEY = "pending_deep_link"


async def _grant_trial_and_notify(bot: Bot, chat_id: int, telegram_id: int, lang: str, *, silent_if_used: bool = False) -> None:
    """
    Attempts to grant the free trial device and sends the user a message
    either way. Shared by the auto-grant-on-first-/start path and the
    trial deep-link path — both end up wanting the same "grant, then tell
    the user what happened" behavior.

    silent_if_used=True is for the auto-grant path: a brand-new user can
    never actually hit the 409 (they can't have used a trial before this
    exact moment), so getting one there would only mean a genuine bug —
    log it, but don't show a confusing "already used" message for
    something the user didn't do. silent_if_used=False (deep-link path) is
    the opposite: hitting 409 there is the expected, common case (someone
    tapping the link a second time) and the user should be told plainly.
    """
    try:
        await billing_client.grant_trial(telegram_id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            if not silent_if_used:
                await bot.send_message(chat_id, t("trial_already_used", lang))
            else:
                logger.error(
                    "Trial 409 on auto-grant for brand-new user %s — should be impossible",
                    telegram_id,
                )
            return
        logger.error("grant_trial failed for %s: %s", telegram_id, exc)
        await bot.send_message(chat_id, t("trial_error", lang))
        return
    except Exception as exc:
        logger.error("grant_trial failed for %s: %s", telegram_id, exc)
        await bot.send_message(chat_id, t("trial_error", lang))
        return
    await bot.send_message(chat_id, t("trial_granted", lang, days=settings.TRIAL_DURATION_DAYS))


# --- Root and stack navigation ------------------------------------------------

@router.message(Command("start"))
async def cmd_start(msg: Message, state: FSMContext, lang: str, is_new_user: bool, command: CommandObject):
    deep_link = (command.args or "").strip()

    if not lang:
        # Language not chosen yet. Two distinct cases land here:
        #  - is_new_user=True: this really is the very first /start ever.
        #  - is_new_user=False: an existing user who never finished picking
        #    a language on some earlier /start. They *could* already have
        #    used the trial via some other path, so silent_if_used must
        #    reflect their real is_new_user, not be assumed True — stash it
        #    alongside the deep-link payload rather than hardcoding it in
        #    cb_set_language below.
        if deep_link == "trial":
            await state.update_data(**{PENDING_DEEP_LINK_KEY: deep_link, "pending_deep_link_is_new": is_new_user})
        await msg.answer(t("language_prompt"), reply_markup=language_picker())
        return

    await navigation.reset(state)
    text, markup = await _main_view(lang)
    ui_message = await msg.answer(text, reply_markup=markup)
    await navigation.set_ui_message(state, ui_message.message_id)

    if is_new_user:
        # New signups get the trial automatically — no link needed. Fires
        # after the main menu is already shown so the trial confirmation
        # reads as "welcome, and by the way" rather than blocking entry.
        await _grant_trial_and_notify(msg.bot, msg.chat.id, msg.from_user.id, lang, silent_if_used=True)
    elif deep_link == "trial":
        # Existing user following the trial link with a language already
        # on file (the /start=trial → language-not-chosen-yet case is
        # handled above via the pending-deep-link stash instead).
        await _grant_trial_and_notify(msg.bot, msg.chat.id, msg.from_user.id, lang, silent_if_used=False)


@router.callback_query(F.data == "start")
async def cb_start(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.reset(state)
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:back")
async def cb_back(cb: CallbackQuery, state: FSMContext, lang: str):
    entry = await navigation.back(state)
    if entry["screen"].startswith("admin_"):
        # Admin handlers use the same stack primitive; the admin root is the
        # only admin target needed when going one level back.
        #
        # Re-check admin status here even though every push onto an admin_*
        # screen already required it: an admin removed from ADMIN_IDS
        # mid-session still has that entry sitting in their FSM stack (it
        # isn't tied to the admin list and isn't invalidated when the config
        # changes), and an ordinary back-tap would otherwise render the
        # admin panel for them with no further gate.
        if cb.from_user.id not in settings.admin_ids_list:
            await navigation.reset(state, "main")
            text, markup = await _main_view(lang)
            await _edit_view(cb.message, state, text, markup)
            await cb.answer(t("adm_no_access", lang), show_alert=True)
            return

        from bot.keyboards.keyboards import admin_menu

        await _edit_view(cb.message, state, t("adm_panel_title", lang), admin_menu(lang))
    elif cb.message.invoice or cb.message.photo:
        # An invoice or a photo (QR) is a distinct Telegram message type; it
        # can never be turned into a normal text message via edit_text
        # (Telegram rejects that), so going back from it means sending the
        # previous screen as a new message and removing the old one. The new
        # message goes out first: if sending fails, the user keeps a working
        # screen instead of an empty chat.
        text, markup = await _resolve_screen(cb.message, state, lang, entry)
        sent = await cb.bot.send_message(
            cb.message.chat.id, text, reply_markup=markup, disable_web_page_preview=True
        )
        await navigation.set_ui_message(state, sent.message_id)
        try:
            await cb.message.delete()
        except TelegramBadRequest as exc:
            # Too old to delete — at least take the dead keyboard away so a
            # second tap on it can't do anything.
            logger.info("Could not delete message on back: %s", exc)
            try:
                await cb.message.edit_reply_markup(reply_markup=None)
            except TelegramBadRequest:
                pass
    else:
        await _render_entry(cb.message, state, lang, entry)
    await cb.answer()


@router.callback_query(F.data == "nav:language")
async def cb_language_menu(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "language")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("lang:"))
async def cb_set_language(cb: CallbackQuery, state: FSMContext):
    new_lang = cb.data.split(":", 1)[1]
    try:
        await billing_client.set_user_language(cb.from_user.id, new_lang)
    except Exception as exc:
        logger.error("Failed to save language for %s: %s", cb.from_user.id, exc)
    await navigation.reset(state)
    await _render_entry(cb.message, state, new_lang, await navigation.current(state))
    await cb.answer(t("language_saved", new_lang))

    # Only present if cmd_start stashed it — i.e. this was the very first
    # /start=trial, before a language existed to notify in. An ordinary
    # language change from settings never has this key, so this is a no-op
    # for that path.
    data = await state.get_data()
    if data.get(PENDING_DEEP_LINK_KEY) == "trial":
        was_new = bool(data.get("pending_deep_link_is_new"))
        await state.update_data(**{PENDING_DEEP_LINK_KEY: None, "pending_deep_link_is_new": None})
        await _grant_trial_and_notify(
            cb.bot, cb.from_user.id, cb.from_user.id, new_lang, silent_if_used=was_new
        )


@router.callback_query(F.data == "nav:devices")
async def cb_devices(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "devices")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:device:"))
async def cb_device(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "device_card", subscription_id=int(cb.data.rsplit(":", 1)[1]))
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:buy_new")
async def cb_buy_new(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "purchase_new")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:renew:"))
async def cb_renew(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "renew", subscription_id=int(cb.data.rsplit(":", 1)[1]))
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data.startswith("nav:tariff:"))
async def cb_tariff_selected(cb: CallbackQuery, state: FSMContext, lang: str):
    _, _, plan_id_s, mode, target_s = cb.data.split(":")
    target_id = int(target_s) if int(target_s) != 0 else None
    await navigation.push(state, "plan_confirm", plan_id=int(plan_id_s), mode=mode, target_id=target_id)
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:support")
async def cb_support(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "support")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:download_vpn")
async def cb_download_vpn(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "download_vpn")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


@router.callback_query(F.data == "nav:info")
async def cb_info(cb: CallbackQuery, state: FSMContext, lang: str):
    await navigation.push(state, "info")
    await _render_entry(cb.message, state, lang, await navigation.current(state))
    await cb.answer()


# --- Payments -----------------------------------------------------------------

@router.callback_query(F.data.startswith("pay_stars:"))
async def cb_pay_stars(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    _, mode, target, plan_id_s = cb.data.split(":")
    target_id = int(target) if target != "0" else 0
    plan_id = int(plan_id_s)
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception as exc:
        logger.error("get_plans failed: %s", exc)
        plan = None
    if not plan:
        await cb.answer(t("plan_load_error", lang), show_alert=True)
        return
    plan_name = t("plan_name_text", lang, duration_days=plan["duration_days"])

    # Replace the payment-method screen with the invoice: the invoice is
    # always a separate Telegram-rendered message (it can't be embedded
    # into a normal text message), so "one screen at a time" here means
    # deleting the previous bot message rather than editing it in place.
    # Deletion can fail (message too old, already gone, etc.) — that's not
    # fatal, we still want the invoice to go out either way.
    try:
        await cb.message.delete()
    except TelegramBadRequest as exc:
        logger.info("Could not delete pre-invoice message: %s", exc)

    try:
        await bot.send_invoice(
            chat_id=cb.from_user.id,
            title=plan_name,
            description=t("plan_description_text", lang, duration_days=plan["duration_days"]),
            payload=f"stars:{mode}:{target_id}:{plan['id']}",
            currency="XTR",
            prices=[LabeledPrice(label=plan_name, amount=plan["price_stars"])],
            provider_token="",
            reply_markup=invoice_keyboard(lang, plan["price_stars"]),
        )
    except Exception as exc:
        # The payment-method screen was already deleted above, so a failed
        # invoice would leave the user with an empty chat and no way forward
        # except /start. Put the screen back (as a new message) and say why.
        logger.error("send_invoice failed: %s", exc)
        text, markup = await _plan_view(lang, mode, plan_id, target_id or None)
        sent = await bot.send_message(cb.from_user.id, text, reply_markup=markup)
        await navigation.set_ui_message(state, sent.message_id)
        await cb.answer(t("payment_error", lang), show_alert=True)
        return
    # Pushed only once the invoice really exists, so a failed send never
    # leaves a phantom "invoice" entry on the stack.
    await navigation.push(state, "invoice", mode=mode, target_id=target_id)
    await cb.answer()


@router.pre_checkout_query()
async def pre_checkout(pq: PreCheckoutQuery):
    await pq.answer(ok=True)


@router.message(F.successful_payment)
async def on_successful_payment(msg: Message, state: FSMContext, lang: str):
    payment: SuccessfulPayment = msg.successful_payment
    parts = payment.invoice_payload.split(":")
    mode = parts[1] if len(parts) > 1 else "new"
    target = int(parts[2]) if len(parts) > 2 and parts[2] != "0" else None
    plan_id = int(parts[3]) if len(parts) > 3 else None
    action_key = "payment_processing_renew" if mode == "renew" else "payment_processing_new"
    await _edit_ui_message(
        msg.bot,
        msg.chat.id,
        state,
        t("payment_processing", lang, action=t(action_key, lang)),
        back_keyboard(lang),
    )
    try:
        result = await billing_client.handle_stars_payment(
            telegram_id=msg.from_user.id,
            username=msg.from_user.username,
            first_name=msg.from_user.first_name,
            last_name=msg.from_user.last_name,
            charge_id=payment.telegram_payment_charge_id,
            total_amount=payment.total_amount,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target,
        )
    except Exception as exc:
        logger.error("Stars payment processing failed: %s", exc)
        await navigation.replace(state, "support")
        await _edit_ui_message(msg.bot, msg.chat.id, state, t("payment_error", lang), back_keyboard(lang))
        return
    await _deliver_result(msg.bot, msg.chat.id, lang, state, result, msg)


@router.callback_query(F.data.startswith("pay_usdt:"))
async def cb_pay_usdt(cb: CallbackQuery, state: FSMContext, lang: str):
    _, mode, target, plan_id_s = cb.data.split(":")
    target_id = int(target) if target != "0" else None
    plan_id = int(plan_id_s)
    try:
        plans = await billing_client.get_plans()
        plan = next((p for p in plans if p["id"] == plan_id), None)
    except Exception:
        plan = None
    if not plan or not settings.CRYPTOPAY_TOKEN:
        await cb.answer(t("usdt_unavailable", lang), show_alert=True)
        return
    try:
        invoice = await crypto_pay.create_invoice(
            amount=float(plan["price_usdt"]),
            asset="USDT",
            description=t("plan_name_text", lang, duration_days=plan["duration_days"]),
            payload=f"{cb.from_user.id}:{plan['id']}:{mode}:{target_id or 0}",
        )
    except Exception as exc:
        logger.error("CryptoPay invoice creation failed: %s", exc)
        await cb.answer(t("usdt_invoice_error", lang), show_alert=True)
        return
    await navigation.push(state, "payment_usdt", invoice_id=invoice.get("invoice_id"), mode=mode, target_id=target_id)
    await _edit_view(
        cb.message,
        state,
        t("usdt_invoice_card", lang, amount=plan["price_usdt"]),
        check_usdt_payment(lang, str(invoice.get("invoice_id")), mode, target_id, invoice.get("pay_url", "")),
        disable_web_page_preview=True,
    )
    await cb.answer()


@router.callback_query(F.data.startswith("check_usdt:"))
async def cb_check_usdt(cb: CallbackQuery, state: FSMContext, lang: str):
    _, invoice_id_s, mode, target_s = cb.data.split(":")
    invoice_id = int(invoice_id_s)
    target_id = int(target_s) if target_s != "0" else None
    try:
        paid = await crypto_pay.is_paid(invoice_id)
    except Exception as exc:
        logger.error("CryptoPay check failed: %s", exc)
        await cb.answer(t("usdt_check_error", lang), show_alert=True)
        return
    if not paid:
        await cb.answer(t("usdt_not_paid_yet", lang), show_alert=True)
        return
    try:
        invoice = await crypto_pay.get_invoice(invoice_id)
    except Exception:
        invoice = {}
    parts = (invoice or {}).get("payload", "").split(":")
    plan_id = int(parts[1]) if len(parts) > 1 else None
    amount = (invoice or {}).get("amount")
    if amount is None and plan_id:
        try:
            plans = await billing_client.get_plans()
            plan = next((p for p in plans if p["id"] == plan_id), None)
            amount = plan["price_usdt"] if plan else None
        except Exception:
            amount = None
    if amount is None:
        logger.error("Could not resolve USDT amount for invoice %s (plan_id=%s)", invoice_id, plan_id)
        await cb.answer(t("usdt_check_error", lang), show_alert=True)
        return
    amount = float(amount)
    action_key = "payment_processing_renew" if mode == "renew" else "payment_processing_new"
    await _edit_view(cb.message, state, t("usdt_confirmed", lang, action=t(action_key, lang)), back_keyboard(lang))
    try:
        result = await billing_client.handle_usdt_payment(
            telegram_id=cb.from_user.id,
            username=cb.from_user.username,
            first_name=cb.from_user.first_name,
            last_name=cb.from_user.last_name,
            invoice_id=str(invoice_id),
            amount=amount,
            plan_id=plan_id,
            mode=mode,
            target_subscription_id=target_id,
        )
    except Exception as exc:
        logger.error("USDT activation failed: %s", exc)
        await navigation.replace(state, "support")
        await _edit_view(cb.message, state, t("usdt_activation_error", lang), back_keyboard(lang))
        await cb.answer()
        return
    await _deliver_result(cb.bot, cb.from_user.id, lang, state, result, cb.message)
    await cb.answer()


# --- Key / QR screens ----------------------------------------------------------
#
# Both are real screens in the navigation stack ("device_key" / "device_qr"),
# so "Назад" returns to the screen they were opened from instead of leaving a
# loose message behind. The key screen is a normal text message and is edited in
# place. A QR code is a photo, which Telegram cannot produce by editing a text
# message: it is sent as the new single UI message and the screen it replaces is
# deleted (cb_back does the reverse on the way back).

@router.callback_query(F.data.startswith("show_key:"))
async def cb_show_key(cb: CallbackQuery, state: FSMContext, lang: str):
    sub_id = int(cb.data.split(":")[1])
    config_url = await _get_device_config_url(cb.from_user.id, sub_id)
    if not config_url:
        await cb.answer(t("qr_unavailable", lang), show_alert=True)
        return
    await _ensure_device_context(state, sub_id)
    await navigation.push(state, "device_key", subscription_id=sub_id)
    await _edit_view(
        cb.message,
        state,
        t("config_key_message", lang, config_url=html.escape(config_url)),
        back_keyboard(lang),
        disable_web_page_preview=True,
    )
    await cb.answer()


@router.callback_query(F.data.startswith("show_qr:"))
async def cb_show_qr(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    sub_id = int(cb.data.split(":")[1])
    guard = (cb.from_user.id, f"qr:{sub_id}")
    if guard in _inflight:
        await cb.answer()
        return
    _inflight.add(guard)
    try:
        config_url = await _get_device_config_url(cb.from_user.id, sub_id)
        if not config_url:
            await cb.answer(t("qr_unavailable", lang), show_alert=True)
            return
        try:
            png = generate_qr(config_url)
        except Exception as exc:
            logger.warning("QR generation failed: %s", exc)
            await cb.answer(t("qr_unavailable", lang), show_alert=True)
            return

        await _ensure_device_context(state, sub_id)
        await navigation.push(state, "device_qr", subscription_id=sub_id)
        try:
            sent = await bot.send_photo(
                cb.message.chat.id,
                photo=BufferedInputFile(png, filename="vpn_qr.png"),
                caption=t("qr_caption", lang),
                reply_markup=back_keyboard(lang),
            )
        except Exception as exc:
            logger.warning("Sending QR failed: %s", exc)
            await navigation.back(state)  # undo the push — we never left the screen
            await cb.answer(t("qr_unavailable", lang), show_alert=True)
            return
        await navigation.set_ui_message(state, sent.message_id)
        try:
            await cb.message.delete()
        except TelegramBadRequest as exc:
            logger.info("Could not delete screen replaced by QR: %s", exc)
            try:
                await cb.message.edit_reply_markup(reply_markup=None)
            except TelegramBadRequest:
                pass
        await cb.answer()
    finally:
        _inflight.discard(guard)


# --- Manat (manual bank transfer via agent queue) ---------------------------
#
# Flow: payer picks any plan and the manat payment method -> pay_manat
# creates a request already assigned to one agent (round-robin, on-shift,
# see BillingService._pick_agent_and_phone) -> that agent has 5 minutes to tap
# "Принять заявку" (manat_ready) or "Не могу принять" (manat_notready); a
# timeout or explicit decline hands the request to the next agent (see
# billing/workers/scheduler.py's timeout sweep for the timeout side —
# manat_notready handles the explicit-decline side here) -> once accepted,
# the payer sees the phone number and has 15 minutes to transfer and tap "Я
# перевёл" (manat_paid) or "Отмена" (manat_cancel; refused once "Я перевёл" was
# tapped) -> the agent can only REPORT receipt
# (manat_report_yes/manat_report_no — ТЗ p.5/p.7, a claim, never a
# confirmation) -> a "money received" report hands the request to the MAIN
# ADMIN's review queue, where manat_admin_approve/manat_admin_reject (ТЗ
# p.6/p.14) is the ONLY path that provisions the subscription or ends the
# request with nothing charged.
#
# Admin visibility: every admin (settings.admin_ids_list) is notified of the
# request being created and of every later change of state — see
# bot/notify.py and bot/manat_notices.py. A notification is sent only after
# the corresponding API call WON its atomic transition, so a repeated tap
# (which gets 409) can never produce a duplicate notice.

def _outcome_from_status(status: str | None) -> str | None:
    """What happened to a request after an agent gave it back: handed to the
    next agent (status 'assigned') or closed because nobody was left
    ('expired')."""
    return {"assigned": "reassigned", "expired": "no_agent"}.get(status or "")


async def _stale_manat_action(cb: CallbackQuery, lang: str, key: str = "manat_already_resolved") -> None:
    """A button on a request that has moved on (already accepted elsewhere,
    re-assigned, resolved...). Take the dead keyboard away and say so in an
    alert — without overwriting the message text, because when two taps race
    the first one's result is what the message should keep showing."""
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass
    await cb.answer(t(key, lang), show_alert=True)


async def _present_to_payer(
    bot: Bot,
    storage: BaseStorage,
    payer_id: int,
    request_id: int,
    amount: float,
    phone: str,
    payer_lang: str,
) -> None:
    """Show the payer the "transfer money here" screen (phone, "Я перевёл",
    "Отмена").

    If the payer is still on the "waiting for an agent" screen of THIS request,
    that very message is edited — one live screen, no stale "waiting" message
    with a leftover button. Otherwise (they moved on, /start, bot restarted) a
    new message is sent, as before. Reads the payer's own FSM data through the
    shared storage; changes only their navigation stack."""
    text = t("manat_request_created", payer_lang, amount=amount, phone=phone)
    markup = manat_payer_paid_keyboard(payer_lang, request_id, amount)
    payer_state = FSMContext(
        storage=storage, key=StorageKey(bot_id=bot.id, chat_id=payer_id, user_id=payer_id)
    )
    cur = await navigation.current(payer_state)
    ui_id = await navigation.get_ui_message_id(payer_state)
    if (
        cur.get("screen") == "manat_pending"
        and cur.get("params", {}).get("request_id") == request_id
        and ui_id
    ):
        try:
            await bot.edit_message_text(
                chat_id=payer_id, message_id=ui_id, text=text, reply_markup=markup
            )
            await navigation.replace(
                payer_state, "manat_pay", request_id=request_id, amount=amount, phone=phone
            )
            return
        except TelegramBadRequest as exc:
            logger.info("Could not edit payer's waiting screen (%s); sending a new message", exc)
    try:
        sent = await bot.send_message(payer_id, text, reply_markup=markup)
    except Exception as exc:
        logger.warning("Failed to notify manat payer %s: %s", payer_id, exc)
        return
    await navigation.set_ui_message(payer_state, sent.message_id)
    await navigation.replace(
        payer_state, "manat_pay", request_id=request_id, amount=amount, phone=phone
    )


async def _notify_agent_new_request(
    bot: Bot, agent_telegram_id: int, request_id: int, payer_label: str, amount: Any
) -> None:
    agent_lang = await user_lang(agent_telegram_id)
    await send_safe(
        bot,
        agent_telegram_id,
        t("manat_agent_new_request", agent_lang, request_id=request_id, payer=payer_label, amount=amount),
        manat_agent_accept_keyboard(agent_lang, request_id),
    )


@router.callback_query(F.data.startswith("pay_manat:"))
async def cb_pay_manat(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    guard = (cb.from_user.id, "pay_manat")
    if guard in _inflight:
        # Double tap while the first request is still being created: without
        # this both taps would create a request and notify an agent each.
        await cb.answer()
        return
    _inflight.add(guard)
    try:
        _, mode, target, plan_id_s = cb.data.split(":")
        target_id = int(target) if target != "0" else None
        plan_id = int(plan_id_s)

        try:
            request = await billing_client.create_manat_request(
                telegram_id=cb.from_user.id,
                username=cb.from_user.username,
                first_name=cb.from_user.first_name,
                last_name=cb.from_user.last_name,
                plan_id=plan_id,
                mode=mode,
                target_subscription_id=target_id,
            )
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 503:
                await cb.answer(t("manat_no_agent_available", lang), show_alert=True)
            else:
                logger.error("create_manat_request failed: %s", exc)
                await cb.answer(t("manat_request_error", lang), show_alert=True)
            return
        except Exception as exc:
            logger.error("create_manat_request failed: %s", exc)
            await cb.answer(t("manat_request_error", lang), show_alert=True)
            return

        request_id = request["request_id"]
        amount = request["amount_manat"]
        agent_telegram_id = request["assigned_agent_telegram_id"]

        # The request is now live. Its waiting screen is an in-flight
        # operation, so it is rooted at the main menu and offers "Отмена"
        # (which really cancels the request), not "Назад" (which would leave
        # an active request — and a reserved agent phone — behind).
        await navigation.reset(state, "main")
        await navigation.push(state, "manat_pending", request_id=request_id)
        await _edit_view(
            cb.message, state, t("manat_awaiting_agent", lang), manat_waiting_keyboard(lang, request_id)
        )
        await cb.answer()

        payer_label = f"@{cb.from_user.username}" if cb.from_user.username else str(cb.from_user.id)
        await _notify_agent_new_request(bot, agent_telegram_id, request_id, payer_label, amount)

        details = await fetch_details(
            request_id, amount=amount, status="assigned", client_telegram_id=cb.from_user.id
        )
        await notify_admins(bot, "created", details)
    finally:
        _inflight.discard(guard)


@router.callback_query(F.data.startswith("manat_ready:"))
async def cb_manat_agent_ready(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    """Assigned agent taps "Ready to accept" within the 5-minute window."""
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.accept_manat_request(request_id, agent_id=cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang)
            return
        logger.error("manat accept failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat accept failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    amount = result["amount_manat"]
    phone = result["agent_phone_shown"]
    payer_telegram_id = result.get("telegram_id")

    await cb.message.edit_text(
        t("manat_agent_awaiting_payment", lang, request_id=request_id, payer=payer_telegram_id or "?", amount=amount, phone=phone)
    )
    await cb.answer()

    if payer_telegram_id:
        payer_lang = await user_lang(payer_telegram_id)
        await _present_to_payer(bot, state.storage, payer_telegram_id, request_id, amount, phone, payer_lang)
    else:
        logger.warning("accept_manat_request response missing telegram_id, cannot notify payer")

    details = await fetch_details(
        request_id, amount=amount, status="awaiting_payment", client_telegram_id=payer_telegram_id
    )
    await notify_admins(bot, "agent_accepted", details)


@router.callback_query(F.data.startswith("manat_notready:"))
async def cb_manat_agent_not_ready(cb: CallbackQuery, bot: Bot, lang: str):
    """Assigned agent taps "Can't accept" — immediately hands the request
    to the next agent in the queue rather than waiting out the timeout.
    The admins are told which agent declined, for which client."""
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.decline_manat_request(request_id, agent_id=cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang)
            return
        logger.error("manat decline failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat decline failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await cb.message.edit_text(t("manat_declined_by_you", lang, request_id=request_id))
    await cb.answer()

    payer_telegram_id = result.get("telegram_id")
    payer_lang = await user_lang(payer_telegram_id)
    if result.get("reassigned"):
        new_agent_telegram_id = result.get("new_agent_telegram_id")
        amount = result.get("amount_manat")
        if payer_telegram_id:
            await send_safe(bot, payer_telegram_id, t("manat_reassigned_to_payer", payer_lang))
        if new_agent_telegram_id:
            await _notify_agent_new_request(
                bot, new_agent_telegram_id, request_id,
                str(payer_telegram_id) if payer_telegram_id else "?", amount,
            )
    else:
        # No other agent had capacity — the service already expired the
        # request (see BillingService.decline_manat_request).
        if payer_telegram_id:
            await send_safe(bot, payer_telegram_id, t("manat_expired_no_agent", payer_lang))

    details = await fetch_details(
        request_id,
        amount=result.get("amount_manat"),
        status=result.get("status"),
        client_telegram_id=payer_telegram_id,
    )
    await notify_admins(
        bot,
        "agent_declined",
        details,
        # The declining agent is no longer attached to the request row, so the
        # API names them explicitly (looked up by the telegram_id that the
        # service already verified held this request).
        agent=result.get("declined_by") or _tg_actor(cb.from_user),
        outcome=_outcome_from_status(details.get("status")),
    )


async def _close_payer_screen(cb: CallbackQuery, state: FSMContext, lang: str, key: str) -> None:
    """The payer's screen belongs to a request that is no longer active: show
    why, with a way out to the main menu, instead of leaving a live-looking
    button behind."""
    await navigation.reset(state, "main")
    await _edit_view(cb.message, state, t(key, lang), to_menu_keyboard(lang))


@router.callback_query(F.data.startswith("manat_paid:"))
async def cb_manat_payer_paid(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    """Payer taps "I paid". The tap is recorded server-side first (atomically,
    first tap wins) and only then is the agent — and the admin — told, so a
    double tap or a tap on a stale screen can't notify anyone twice or
    announce a request that was already closed. Does not resolve the request;
    only the agent's own confirm/reject does that."""
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.manat_payer_paid(request_id, cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        code = exc.response.status_code
        if code == 409:
            try:
                status = await billing_client.get_manat_request_status(request_id)
            except Exception:
                status = {}
            if status.get("status") == "awaiting_payment" and status.get("payer_paid"):
                # Repeated tap — the first one already did everything.
                await cb.answer(t("manat_already_reported", lang), show_alert=True)
            else:
                await cb.answer(t("manat_request_not_active", lang), show_alert=True)
                await _close_payer_screen(cb, state, lang, "manat_request_not_active")
            return
        if code == 404:
            await cb.answer(t("manat_request_not_active", lang), show_alert=True)
            await _close_payer_screen(cb, state, lang, "manat_request_not_active")
            return
        logger.error("manat payer-paid failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat payer-paid failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    # After this tap the payer can no longer cancel (the server refuses), so
    # the screen offers only the way out to the menu.
    await navigation.reset(state, "main")
    await _edit_view(cb.message, state, t("manat_i_paid_notice", lang), to_menu_keyboard(lang))
    await cb.answer()

    amount = result["amount_manat"]
    agent_telegram_id = result.get("assigned_agent_telegram_id")
    if agent_telegram_id:
        agent_lang = await user_lang(agent_telegram_id)
        await send_safe(
            bot,
            agent_telegram_id,
            t("manat_agent_payer_paid", agent_lang, request_id=request_id, amount=amount),
            manat_agent_confirm_keyboard(agent_lang, request_id),
        )
    else:
        logger.warning("manat request %s has no assigned agent to notify of payment", request_id)

    details = await fetch_details(
        request_id, amount=amount, status=result.get("status"), client_telegram_id=cb.from_user.id
    )
    await notify_admins(bot, "payer_paid", details)


@router.callback_query(F.data.startswith("manat_cancel:"))
async def cb_manat_cancel(cb: CallbackQuery, bot: Bot, state: FSMContext, lang: str):
    """Payer taps "Отмена" on the waiting screen or on the "transfer money"
    screen. A real cancellation: the request becomes `cancelled` in the DB (so
    it stops reserving the agent's phone capacity and can no longer be
    accepted/reported), the navigation stack is reset (no FSM state is used by
    this flow, so nothing else needs clearing), the agent who held it and the
    admins are told, and the payer can create a new request right away.
    Refused once the payer has tapped "Я перевёл" — the transfer may already
    be on its way."""
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.cancel_manat_request(request_id, cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        code = exc.response.status_code
        if code == 409:
            try:
                status = await billing_client.get_manat_request_status(request_id)
            except Exception:
                status = {}
            if status.get("status") == "cancelled":
                # Repeated tap — already cancelled; show the same result.
                await navigation.reset(state, "main")
                await _edit_view(cb.message, state, t("manat_cancelled_by_you", lang), to_menu_keyboard(lang))
                await cb.answer()
            elif status.get("status") == "awaiting_payment" and status.get("payer_paid"):
                await cb.answer(t("manat_cancel_too_late", lang), show_alert=True)
            else:
                await cb.answer(t("manat_request_not_active", lang), show_alert=True)
                await _close_payer_screen(cb, state, lang, "manat_request_not_active")
            return
        if code == 404:
            await cb.answer(t("manat_request_not_active", lang), show_alert=True)
            await _close_payer_screen(cb, state, lang, "manat_request_not_active")
            return
        logger.error("manat cancel failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat cancel failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await navigation.reset(state, "main")
    await _edit_view(cb.message, state, t("manat_cancelled_by_you", lang), to_menu_keyboard(lang))
    await cb.answer()

    agent_telegram_id = result.get("assigned_agent_telegram_id")
    if agent_telegram_id:
        agent_lang = await user_lang(agent_telegram_id)
        await send_safe(bot, agent_telegram_id, t("manat_agent_request_cancelled", agent_lang, request_id=request_id))

    details = await fetch_details(
        request_id, amount=result.get("amount_manat"), status="cancelled", client_telegram_id=cb.from_user.id
    )
    await notify_admins(bot, "payer_cancelled", details)


@router.callback_query(F.data.startswith("manat_report_yes:"))
async def cb_manat_agent_report_yes(cb: CallbackQuery, bot: Bot, lang: str):
    """
    Agent taps "Деньги получены". Per ТЗ p.5/p.7 this is ONLY a claim, not
    a confirmation — it never creates a subscription. The request moves
    into the main admin's review queue, and every configured admin
    (settings.admin_ids_list) is notified with an approve/reject keyboard and
    the full picture: which client, which agent (taken from the request's own
    DB link, not guessed), amount, status, time.
    """
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.report_manat_payment(
            request_id, agent_id=cb.from_user.id, received=True
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang)
            return
        logger.error("manat report(received=True) failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat report(received=True) failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await cb.message.edit_text(t("manat_reported_by_you", lang, request_id=request_id))
    await cb.answer()

    amount = result.get("amount_manat")
    payer_telegram_id = result.get("telegram_id")
    if payer_telegram_id:
        payer_lang = await user_lang(payer_telegram_id)
        await send_safe(bot, payer_telegram_id, t("manat_payment_under_review", payer_lang))

    details = await fetch_details(
        request_id, amount=amount, status="admin_review", client_telegram_id=payer_telegram_id
    )
    await notify_admins(
        bot,
        "review",
        details,
        markup_for=lambda admin_lang: manat_admin_review_keyboard(admin_lang, request_id),
        # If the details lookup failed, still say which agent reported.
        agent=details.get("agent") or result.get("reported_by") or _tg_actor(cb.from_user),
    )


@router.callback_query(F.data.startswith("manat_report_no:"))
async def cb_manat_agent_report_no(cb: CallbackQuery, bot: Bot, lang: str):
    """Agent taps "Деньги не получены" — no transfer seen. Same as
    declining: re-queued to the next available agent. The payer is told what
    actually happened, the NEXT agent is notified that the request is now
    theirs (previously nobody told them, so it sat until the 5-minute timeout),
    and the admins are told which agent reported no money for which client."""
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.report_manat_payment(
            request_id, agent_id=cb.from_user.id, received=False
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang)
            return
        logger.error("manat report(received=False) failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat report(received=False) failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await cb.message.edit_text(t("manat_rejected_by_you", lang, request_id=request_id))
    await cb.answer()

    payer_telegram_id = result.get("telegram_id")
    payer_lang = await user_lang(payer_telegram_id)
    if result.get("reassigned"):
        if payer_telegram_id:
            await send_safe(bot, payer_telegram_id, t("manat_money_not_received_notice", payer_lang))
        new_agent_telegram_id = result.get("new_agent_telegram_id")
        if new_agent_telegram_id:
            await _notify_agent_new_request(
                bot, new_agent_telegram_id, request_id,
                str(payer_telegram_id) if payer_telegram_id else "?", result.get("amount_manat"),
            )
    elif payer_telegram_id:
        # Nobody else is available — the service expired the request.
        await send_safe(bot, payer_telegram_id, t("manat_expired_no_agent", payer_lang))

    details = await fetch_details(
        request_id,
        amount=result.get("amount_manat"),
        status=result.get("status"),
        client_telegram_id=payer_telegram_id,
    )
    await notify_admins(
        bot,
        "agent_money_not_received",
        details,
        agent=result.get("reported_by") or _tg_actor(cb.from_user),
        outcome=_outcome_from_status(details.get("status")),
    )


def _is_admin_user(user_id: int) -> bool:
    return user_id in settings.admin_ids_list


@router.callback_query(F.data.startswith("manat_admin_approve:"))
async def cb_manat_admin_approve(cb: CallbackQuery, bot: Bot, lang: str):
    """
    Main admin taps "✅ Подтвердить оплату" (ТЗ p.6). THE ONLY action that
    creates the subscription and triggers VPN provisioning. The tapping user
    must be in ADMIN_IDS: the callback_data alone is not an authorization (a
    message with this keyboard can be forwarded), and the API trusts the
    admin_telegram_id it is given. The other admins are told who decided.
    """
    if not _is_admin_user(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    request_id = int(cb.data.split(":")[1])
    try:
        result = await billing_client.admin_approve_manat_request(
            request_id, admin_telegram_id=cb.from_user.id
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang, "manat_admin_already_resolved")
            return
        logger.error("manat admin approve failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat admin approve failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await cb.message.edit_text(t("manat_admin_approved_by_you", lang, request_id=request_id))
    await cb.answer()

    payer_telegram_id = result.get("telegram_id")
    if not payer_telegram_id:
        logger.warning("admin_approve_manat_request response missing telegram_id, cannot notify payer")
    else:
        payer_lang = await user_lang(payer_telegram_id)
        expires = (result.get("expires_at") or "")[:10] or t("unknown_expiry", payer_lang)
        if result.get("config_url"):
            await send_safe(
                bot,
                payer_telegram_id,
                t("config_ready", payer_lang, expires=expires),
                config_ready_keyboard(payer_lang, True, result["subscription_id"]),
            )
        else:
            await send_safe(bot, payer_telegram_id, t("provisioning_pending", payer_lang))

    details = await fetch_details(request_id, status="completed", client_telegram_id=payer_telegram_id)
    await notify_admins(
        bot, "admin_approved", details, exclude={cb.from_user.id}, actor=_tg_actor(cb.from_user)
    )


@router.callback_query(F.data.startswith("manat_admin_reject:"))
async def cb_manat_admin_reject(cb: CallbackQuery, bot: Bot, lang: str):
    """Main admin taps "❌ Отклонить оплату" (ТЗ p.6). Same ADMIN_IDS check as
    approve; the other admins are told who decided."""
    if not _is_admin_user(cb.from_user.id):
        await cb.answer(t("adm_no_access", lang), show_alert=True)
        return
    request_id = int(cb.data.split(":")[1])
    try:
        await billing_client.admin_reject_manat_request(
            request_id, admin_telegram_id=cb.from_user.id
        )
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 409:
            await _stale_manat_action(cb, lang, "manat_admin_already_resolved")
            return
        logger.error("manat admin reject failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return
    except Exception as exc:
        logger.error("manat admin reject failed for request %s: %s", request_id, exc)
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    await cb.message.edit_text(t("manat_admin_rejected_by_you", lang, request_id=request_id))
    await cb.answer()

    details = await fetch_details(request_id, status="rejected")
    payer_telegram_id = ((details.get("client") or {}).get("telegram_id"))
    if payer_telegram_id:
        payer_lang = await user_lang(payer_telegram_id)
        await send_safe(bot, payer_telegram_id, t("manat_admin_rejected_notice", payer_lang))
    await notify_admins(
        bot, "admin_rejected", details, exclude={cb.from_user.id}, actor=_tg_actor(cb.from_user)
    )


# --- Manat agent self-service: manage own phone numbers ---------------------

@router.message(Command("my_numbers"))
async def cmd_my_numbers(msg: Message, lang: str):
    """Lets a registered manat agent view and toggle their own phone
    numbers on/off. Adding/removing numbers stays admin-only
    (/add_agent_phone) — this command only flips is_enabled."""
    try:
        agent = await billing_client.get_agent_by_telegram_id(msg.from_user.id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            await msg.answer(t("agent_not_registered", lang))
            return
        raise

    phones = agent.get("phones", [])
    lines = [t("agent_my_numbers_header", lang)]
    for phone in phones:
        status_icon = "🟢" if phone["is_enabled"] else "🔴"
        limit = phone.get("daily_limit_manat")
        limit_display = limit if limit is not None else t("agent_limit_unlimited", lang)
        lines.append(
            t(
                "agent_phone_line",
                lang,
                status_icon=status_icon,
                phone=phone["phone_number"],
                received=phone["received_last_24h"],
                limit=limit_display,
            )
        )
    await msg.answer("\n".join(lines), reply_markup=agent_phones_keyboard(lang, phones))


@router.callback_query(F.data.startswith("agentphone_toggle:"))
async def cb_agent_phone_toggle(cb: CallbackQuery, lang: str):
    phone_id = int(cb.data.split(":")[1])
    try:
        agent = await billing_client.get_agent_by_telegram_id(cb.from_user.id)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            await cb.answer(t("agent_not_registered", lang), show_alert=True)
            return
        raise

    phone = next((p for p in agent.get("phones", []) if p["id"] == phone_id), None)
    if phone is None:
        await cb.answer(t("manat_action_error", lang), show_alert=True)
        return

    new_state = not phone["is_enabled"]
    await billing_client.set_agent_phone_enabled(phone_id, new_state)
    await cb.answer(t("agent_phone_toggled", lang))

    # Re-render the list with the updated state.
    agent = await billing_client.get_agent_by_telegram_id(cb.from_user.id)
    phones = agent.get("phones", [])
    lines = [t("agent_my_numbers_header", lang)]
    for p in phones:
        status_icon = "🟢" if p["is_enabled"] else "🔴"
        limit = p.get("daily_limit_manat")
        limit_display = limit if limit is not None else t("agent_limit_unlimited", lang)
        lines.append(
            t(
                "agent_phone_line",
                lang,
                status_icon=status_icon,
                phone=p["phone_number"],
                received=p["received_last_24h"],
                limit=limit_display,
            )
        )
    await cb.message.edit_text("\n".join(lines), reply_markup=agent_phones_keyboard(lang, phones))
