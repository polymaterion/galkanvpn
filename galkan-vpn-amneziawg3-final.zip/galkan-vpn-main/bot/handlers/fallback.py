"""
Last-resort handler for callback buttons nobody else claims.

Included LAST in bot/main.py, after every other router, so it only ever sees
callbacks that no real handler matched — e.g. a button on a message from an
older version of the bot or from before a restart. Without it Telegram keeps
the button's loading spinner running for the user and nothing tells them the
button is dead. It deliberately does not touch the message or its keyboard:
the message may be the user's current screen.
"""
from aiogram import Router
from aiogram.types import CallbackQuery

from bot.locales import t

router = Router()


@router.callback_query()
async def cb_stale_button(cb: CallbackQuery, lang: str):
    await cb.answer(t("stale_button", lang), show_alert=True)
