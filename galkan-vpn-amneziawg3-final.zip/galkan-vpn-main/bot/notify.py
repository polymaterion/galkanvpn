"""
Telegram-side helpers for notifying people about manat requests (bot process).

Kept in one place so every handler sends admin notifications the same way:
  - to EVERY configured admin (settings.admin_ids_list — the existing
    "main administrator" concept of this project, no parallel list),
  - in each admin's own language,
  - with each send isolated, so one admin who blocked the bot (or a transient
    Telegram error) never prevents the others from being notified and never
    breaks the handler that triggered the notification.

Callers invoke these only AFTER a state transition has been won (the API
returned 200). A repeated tap loses the atomic UPDATE in the billing service,
gets a 409, and therefore never reaches this code — that is what prevents the
same event from being announced twice.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Iterable, Optional

from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup

from bot.billing_client import billing_client
from bot.config import settings
from bot.locales import DEFAULT_LANG
from bot.manat_notices import minimal_details, render_admin_notice

logger = logging.getLogger(__name__)


async def user_lang(telegram_id: int | None) -> str:
    """Saved language of an arbitrary user (recipient of a notification), so
    a message to another person is written in THEIR language rather than in
    the language of whoever tapped the button. Falls back to Russian."""
    if not telegram_id:
        return DEFAULT_LANG
    try:
        me = await billing_client.get_me(telegram_id)
        return me.get("language") or DEFAULT_LANG
    except Exception as exc:
        logger.warning("Could not read language of %s: %s", telegram_id, exc)
        return DEFAULT_LANG


async def send_safe(
    bot: Bot,
    chat_id: int,
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
) -> bool:
    """Send one message; failure is logged, never raised."""
    try:
        await bot.send_message(chat_id, text, reply_markup=reply_markup)
        return True
    except Exception as exc:
        logger.warning("Failed to send message to %s: %s", chat_id, exc)
        return False


async def fetch_details(
    request_id: int,
    *,
    amount: Any = None,
    status: Optional[str] = None,
    client_telegram_id: Optional[int] = None,
) -> dict[str, Any]:
    """Fresh request details from the billing API; on failure a minimal dict
    so the notification is still sent (with less data) instead of dropped."""
    try:
        return await billing_client.admin_get_manat_request(request_id)
    except Exception as exc:
        logger.warning("Could not load details of manat request %s: %s", request_id, exc)
        return minimal_details(
            request_id, amount=amount, status=status, client_telegram_id=client_telegram_id
        )


async def notify_admins(
    bot: Bot,
    kind: str,
    details: dict[str, Any],
    *,
    markup_for: Optional[Callable[[str], InlineKeyboardMarkup]] = None,
    exclude: Iterable[int] = (),
    **render_kwargs: Any,
) -> int:
    """Send a manat-request notice to every admin (minus `exclude`, e.g. the
    admin who just made the decision and already sees the result on their own
    screen). `markup_for(lang)` builds the keyboard in each admin's own
    language. Returns how many admins were reached."""
    skipped = set(exclude)
    reached = 0
    for admin_id in settings.admin_ids_list:
        if admin_id in skipped:
            continue
        lang = await user_lang(admin_id)
        text = render_admin_notice(kind, lang, details, **render_kwargs)
        markup = markup_for(lang) if markup_for else None
        if await send_safe(bot, admin_id, text, markup):
            reached += 1
    return reached
