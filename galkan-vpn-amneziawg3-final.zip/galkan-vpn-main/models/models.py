"""
All SQLAlchemy ORM models.
Import order matters for Alembic to detect all tables.
"""
import enum
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Enum, Float, ForeignKey,
    Index, Integer, Numeric, String, Text, UniqueConstraint, func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models import Base, TimestampMixin
from models.settings import default_phone_daily_limit


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SubscriptionStatus(str, enum.Enum):
    pending_payment = "pending_payment"
    pending_provisioning = "pending_provisioning"
    active = "active"
    expired = "expired"
    disabled = "disabled"
    error = "error"


class PaymentStatus(str, enum.Enum):
    pending = "pending"
    paid = "paid"
    failed = "failed"
    refunded = "refunded"


class PaymentProvider(str, enum.Enum):
    stars = "stars"
    usdt = "usdt"
    manat = "manat"
    # A subscription granted directly by the main admin (e.g. /add_device),
    # with no real payment behind it — still recorded as a Payment row
    # (amount=0) so it goes through the exact same idempotent
    # order/payment/subscription/provisioning path as every paid provider,
    # and shows up in Payments/audit history for traceability.
    admin_grant = "admin_grant"


class ManatRequestStatus(str, enum.Enum):
    """
    Full lifecycle per ТЗ "новая архитектура оплаты манатами через агентов":
    an agent may only report that money arrived (payment_reported); only
    the main admin's approval (admin_review -> approved) is allowed to
    trigger Payment/Order/Subscription/VPN provisioning. No agent-facing
    action can ever move a request past payment_reported.

        created -> awaiting_agent -> assigned -> awaiting_payment
                -> payment_reported -> admin_review
                -> approved -> provisioning -> completed
                -> rejected (from admin_review)

    Side branches: declined (agent tapped "can't accept"; request is
    re-queued/re-assigned, not terminal), expired (no agent accepted in
    time, or payer never transferred in time), cancelled (payer/admin
    cancelled before resolution), provisioning_failed (admin approved but
    VPN provisioning itself failed — see BillingService.approve_manat_request).
    """
    created = "created"
    awaiting_agent = "awaiting_agent"      # searching for / (re)assigning to an agent
    assigned = "assigned"                  # agent notified, has not yet tapped "Ready"
    awaiting_payment = "awaiting_payment"  # agent accepted, phone shown to payer, waiting
                                            # for payer to transfer + agent to report receipt
    payment_reported = "payment_reported"  # agent tapped "money received" — NOT a
                                            # confirmation, just a claim awaiting admin review
    admin_review = "admin_review"          # sitting in the main admin's review queue
    approved = "approved"        # admin approved — provisioning about to run/ran
    provisioning = "provisioning"  # admin approved, VPN provisioning in progress
    completed = "completed"      # Payment/Order/Subscription/VpnClient all created
    declined = "declined"        # agent tapped "can't accept" — transient, see decline_manat_request
    expired = "expired"          # no agent accepted in time, or payer missed payment window
    rejected = "rejected"        # admin rejected the reported payment
    cancelled = "cancelled"      # cancelled before resolution
    provisioning_failed = "provisioning_failed"  # admin approved but VPN provisioning failed
    # Legacy values kept only so pre-rework rows still deserialize; never
    # set on new rows.
    pending = "pending"
    confirmed = "confirmed"


class OrderStatus(str, enum.Enum):
    pending = "pending"
    completed = "completed"
    failed = "failed"


class VpnServerStatus(str, enum.Enum):
    active = "active"
    disabled = "disabled"
    maintenance = "maintenance"


class VpnClientStatus(str, enum.Enum):
    active = "active"
    disabled = "disabled"
    deleted = "deleted"


class AuditAction(str, enum.Enum):
    subscription_created = "subscription_created"
    subscription_renewed = "subscription_renewed"
    subscription_expired = "subscription_expired"
    subscription_disabled = "subscription_disabled"
    subscription_enabled = "subscription_enabled"
    subscription_deleted = "subscription_deleted"
    subscription_admin_granted = "subscription_admin_granted"
    vpn_client_created = "vpn_client_created"
    vpn_client_disabled = "vpn_client_disabled"
    vpn_client_enabled = "vpn_client_enabled"
    vpn_client_deleted = "vpn_client_deleted"
    payment_received = "payment_received"
    provisioning_failed = "provisioning_failed"
    provisioning_retried = "provisioning_retried"
    manat_agent_assigned = "manat_agent_assigned"
    manat_agent_reported_payment = "manat_agent_reported_payment"
    manat_admin_approved = "manat_admin_approved"
    manat_admin_rejected = "manat_admin_rejected"


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------

class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    # None = language not chosen yet (bot shows the picker on /start).
    # "ru" or "tk" once chosen.
    language: Mapped[Optional[str]] = mapped_column(String(8), nullable=True)

    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="user")
    orders: Mapped[list["Order"]] = relationship(back_populates="user")
    payments: Mapped[list["Payment"]] = relationship(back_populates="user")


class Plan(Base, TimestampMixin):
    __tablename__ = "plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)
    price_stars: Mapped[int] = mapped_column(Integer, nullable=False)     # XTR
    price_usdt: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    price_manat: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False, server_default="0")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # True only for the single free trial plan (see grant_trial()). Excluded
    # from get_active_plan()'s query regardless of is_active, so an admin
    # mistake (e.g. accidentally flipping is_active on it) can't make a
    # regular purchase silently resolve to the free trial.
    is_trial: Mapped[bool] = mapped_column(Boolean, default=False)

    orders: Mapped[list["Order"]] = relationship(back_populates="plan")
    subscriptions: Mapped[list["Subscription"]] = relationship(back_populates="plan")


class VpnServer(Base, TimestampMixin):
    __tablename__ = "vpn_servers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    base_url: Mapped[str] = mapped_column(String(512), nullable=False)
    api_key: Mapped[str] = mapped_column(String(512), nullable=False)
    region: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    weight: Mapped[int] = mapped_column(Integer, default=100)
    status: Mapped[VpnServerStatus] = mapped_column(
        Enum(VpnServerStatus), default=VpnServerStatus.active
    )
    max_clients: Mapped[int] = mapped_column(Integer, default=500)
    current_clients: Mapped[int] = mapped_column(Integer, default=0)
    # Which AmneziaWG protocol this server has installed/enabled, as
    # resolved (not guessed) via AmneziaClient.resolve_amneziawg_protocol
    # when the server was added (see BillingService.add_server) — never a
    # hardcoded default. No server-side or Python default value here on
    # purpose: a server row must always carry the protocol amnezia-api
    # itself confirmed it supports, so a missing/wrong value is a bug to
    # surface immediately rather than something that silently falls back
    # to an old protocol version.
    protocol: Mapped[str] = mapped_column(String(32))

    vpn_clients: Mapped[list["VpnClient"]] = relationship(back_populates="server")


class Order(Base, TimestampMixin):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    status: Mapped[OrderStatus] = mapped_column(
        Enum(OrderStatus), default=OrderStatus.pending, nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="orders")
    plan: Mapped["Plan"] = relationship(back_populates="orders")
    payments: Mapped[list["Payment"]] = relationship(back_populates="order")


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), nullable=False, index=True)
    # Which subscription (device) this payment ultimately provisioned/renewed.
    # Set right after the subscription is created/extended. Used to resolve
    # duplicate/replayed payment events to the exact right device instead of
    # guessing "latest subscription for user" (unreliable once a user can
    # have several concurrent devices).
    subscription_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("subscriptions.id"), nullable=True, index=True
    )
    provider: Mapped[PaymentProvider] = mapped_column(Enum(PaymentProvider), nullable=False)
    external_id: Mapped[str] = mapped_column(String(512), nullable=False)
    status: Mapped[PaymentStatus] = mapped_column(
        Enum(PaymentStatus), default=PaymentStatus.pending
    )
    amount: Mapped[float] = mapped_column(Numeric(14, 4), nullable=False)
    currency: Mapped[str] = mapped_column(String(16), nullable=False)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="payments")
    order: Mapped["Order"] = relationship(back_populates="payments")

    __table_args__ = (
        UniqueConstraint("provider", "external_id", name="uq_payment_provider_external"),
        Index("ix_payment_external_id", "external_id"),
    )


class Agent(Base, TimestampMixin):
    """
    A manat payment agent — a person who receives transfers from payers and
    reports receipt. An agent can have multiple phone numbers (AgentPhone);
    which one is shown to a given payer rotates based on each phone's
    trailing-24h received total (see BillingService._pick_agent_phone).

    is_active is the agent's overall on/off switch, set by an admin (adding
    or removing an agent). manually_disabled is a SEPARATE switch the admin
    can also flip independently of the work schedule below — per ТЗ p.2,
    "Администратор должен иметь возможность вручную включить/выключить
    агента независимо от расписания". An agent is only ever a candidate for
    assignment when is_active is True, manually_disabled is False, AND the
    current time (converted to `timezone`) falls inside their schedule — see
    BillingService._agent_is_on_shift and _next_available_agent.
    """
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True, nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # IANA timezone name the agent's schedule below is interpreted in.
    # Defaults to Asia/Ashgabat per ТЗ p.2/p.10.
    timezone: Mapped[str] = mapped_column(String(64), default="Asia/Ashgabat", nullable=False)
    # Which weekdays the agent works, ISO weekday numbers 1 (Monday) - 7
    # (Sunday), stored as a comma-separated string (e.g. "1,2,3,4,5") for
    # portability across the DB backends this project targets. Empty/NULL
    # means "every day" — see BillingService._agent_is_on_shift.
    work_days: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    # Local start/end of the agent's shift, as HH:MM. NULL on both means
    # "no schedule restriction" (available all day whenever is_active and
    # not manually_disabled). A shift that crosses midnight (e.g. 22:00 ->
    # 02:00) is supported — see _agent_is_on_shift.
    work_start_time: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)
    work_end_time: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)
    # Admin-only kill switch, independent of the schedule above (ТЗ p.2).
    # An agent who is technically inside their shift window is still
    # skipped entirely while this is True.
    manually_disabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Updated every time this agent is picked by the round-robin assignment
    # queue (whether or not they end up accepting). Ordering candidates by
    # this ascending (NULLS FIRST) is what makes the rotation fair — the
    # agent who was assigned longest ago (or never) goes next.
    last_assigned_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    phones: Mapped[list["AgentPhone"]] = relationship(back_populates="agent")


class AgentPhone(Base, TimestampMixin):
    """
    One phone number belonging to an agent. Added/removed only by an admin;
    is_enabled is toggled by the agent themselves (temporarily taking a
    number out of rotation without deleting it). The trailing-24h received
    total for the daily limit is computed from ManatPaymentTransaction rows
    (confirmed) PLUS still-open ManatPaymentRequest rows reserved against
    this phone (reported-but-not-yet-approved, or still in flight before
    the payer transfers), not stored as a running counter here, since it's
    a rolling window rather than a resettable counter — see
    BillingService._phone_reserved_and_confirmed_total. This is what makes
    the limit check-and-reserve atomic under concurrent requests (ТЗ p.9):
    the reservation IS the ManatPaymentRequest row itself, created inside
    the same DB transaction that re-checks the limit.
    """
    __tablename__ = "agent_phones"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), nullable=False, index=True)
    phone_number: Mapped[str] = mapped_column(String(32), nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # Per-phone daily receiving limit in TMT, business-configurable per ТЗ
    # p.9 ("Существующий лимит телефона 350 TMT/24h... реализовать как
    # отдельную бизнес-настройку агента/номера"). NULL/0 means unlimited.
    daily_limit_manat: Mapped[Optional[float]] = mapped_column(
        Numeric(14, 2), nullable=True, default=default_phone_daily_limit
    )

    agent: Mapped["Agent"] = relationship(back_populates="phones")

    __table_args__ = (
        UniqueConstraint("agent_id", "phone_number", name="uq_agent_phone"),
    )


class ManatPaymentTransaction(Base, TimestampMixin):
    """
    One confirmed manat receipt against a specific agent phone, used solely
    to compute that phone's trailing-24h total against the 350 TMT daily
    limit (BillingService._phone_available_limit sums amount_manat for rows
    with created_at within the last 24h of a given phone_id). Written once,
    at the same time the ManatPaymentRequest is marked confirmed — never
    updated or deleted, so old rows simply age out of every future 24h
    window on their own rather than needing a reset job.
    """
    __tablename__ = "manat_payment_transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_phone_id: Mapped[int] = mapped_column(ForeignKey("agent_phones.id"), nullable=False, index=True)
    manat_request_id: Mapped[int] = mapped_column(
        ForeignKey("manat_payment_requests.id"), nullable=False, unique=True
    )
    amount_manat: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)

    agent_phone: Mapped["AgentPhone"] = relationship()


class ManatPaymentRequest(Base, TimestampMixin):
    """
    A pending manual-payment request moving through the agent queue, then
    the main admin's review queue. Deliberately NOT a Payment row —
    Payment/Order/Subscription are only created once the MAIN ADMIN approves
    (see BillingService.approve_manat_request), never by any agent action.
    All the "what should this become once approved" parameters that
    handle_payment() normally receives as call arguments have to be
    persisted here instead, since real time (and potentially a process
    restart) passes between request creation and approval.

    Lifecycle (see ManatRequestStatus for the full description of each
    value):
        awaiting_agent -> assigned -> awaiting_payment -> payment_reported
        -> admin_review -> approved -> provisioning -> completed
                                     -> rejected
    Side branches: declined (re-queued to next agent), expired, cancelled,
    provisioning_failed. See billing/workers/scheduler.py's
    task_sweep_manat_timeouts for how the acceptance/payment windows are
    enforced, and BillingService for every transition.
    """
    __tablename__ = "manat_payment_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    mode: Mapped[str] = mapped_column(String(16), nullable=False)  # "new" or "renew"
    target_subscription_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("subscriptions.id"), nullable=True
    )
    amount_manat: Mapped[float] = mapped_column(Numeric(14, 2), nullable=False)
    agent_phone_shown: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[ManatRequestStatus] = mapped_column(
        # length=32 matches migration 0009 — the longest value,
        # "provisioning_failed", is 19 chars (the column was created as
        # VARCHAR(16) in 0004 and widened there).
        Enum(ManatRequestStatus, native_enum=False, length=32),
        default=ManatRequestStatus.awaiting_agent,
        nullable=False,
    )
    # The agent currently holding this request (assigned by the round-robin
    # queue). Re-assigned to the next candidate on a 5-minute acceptance
    # timeout, or immediately on decline — see task_sweep_manat_timeouts and
    # BillingService.decline_manat_request. Distinct from
    # reported_by_agent_id below, which is set once the agent reports
    # receipt (payment_reported), and stays fixed after that even though
    # this field's underlying row keeps pointing at the same agent.
    assigned_agent_id: Mapped[Optional[int]] = mapped_column(ForeignKey("agents.id"), nullable=True)
    assigned_phone_id: Mapped[Optional[int]] = mapped_column(ForeignKey("agent_phones.id"), nullable=True)
    # When the current assignment was made — the 5-minute acceptance
    # deadline is this plus 5 minutes. Reset on every re-assignment.
    assigned_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    # When the agent tapped "Ready to accept" — the 15-minute payment
    # deadline is this plus 15 minutes. Set once, never reset.
    accepted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    # Which agent tapped "Деньги получены" — this is a CLAIM, not a
    # confirmation (see ТЗ p.7). Set when status -> payment_reported.
    reported_by_agent_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    reported_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    # When the PAYER tapped "Я перевёл" (their claim that the transfer was
    # made). Set atomically by ManatRequestRepository.try_mark_payer_paid;
    # once set, the payer can no longer cancel the request on their own and
    # a repeated tap is a no-op. Cleared again if the agent reports "money
    # not received" and the request is re-queued to the next agent.
    payer_paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    # Which ADMIN (telegram_id) approved/rejected, and when — the only
    # actor allowed to move a request past admin_review. Recorded here in
    # addition to AuditLog for quick display in the admin queue; AuditLog
    # remains the authoritative, append-only record (ТЗ p.7).
    resolved_by_admin_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    rejection_reason: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    # JSON list of {agent_id, phone_id, assigned_at, outcome} — one entry
    # per assignment attempt, appended to on every (re)assignment and
    # decline/timeout, so admins can see the full reassignment history for
    # a request (ТЗ p.4 "история переназначений", p.6, p.11).
    reassignment_history: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Populated only once approved and provisioning has run — the Payment
    # that resulted from this request, for audit/lookup ("which manat
    # request led to this payment").
    payment_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("payments.id"), nullable=True
    )

    user: Mapped["User"] = relationship()
    plan: Mapped["Plan"] = relationship()
    assigned_agent: Mapped[Optional["Agent"]] = relationship(foreign_keys=[assigned_agent_id])
    assigned_phone: Mapped[Optional["AgentPhone"]] = relationship(foreign_keys=[assigned_phone_id])


class Subscription(Base, TimestampMixin):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("plans.id"), nullable=False)
    server_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("vpn_servers.id"), nullable=True
    )
    status: Mapped[SubscriptionStatus] = mapped_column(
        Enum(SubscriptionStatus), default=SubscriptionStatus.pending_payment, nullable=False
    )
    starts_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_provisioned_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_extended_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    retry_count: Mapped[int] = mapped_column(Integer, default=0)

    user: Mapped["User"] = relationship(back_populates="subscriptions")
    plan: Mapped["Plan"] = relationship(back_populates="subscriptions")
    server: Mapped[Optional["VpnServer"]] = relationship()
    vpn_client: Mapped[Optional["VpnClient"]] = relationship(
        back_populates="subscription", uselist=False
    )


class VpnClient(Base, TimestampMixin):
    __tablename__ = "vpn_clients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    subscription_id: Mapped[int] = mapped_column(
        ForeignKey("subscriptions.id"), unique=True, nullable=False
    )
    server_id: Mapped[int] = mapped_column(ForeignKey("vpn_servers.id"), nullable=False)
    amnezia_client_id: Mapped[str] = mapped_column(String(512), nullable=False)
    client_name: Mapped[str] = mapped_column(String(256), nullable=False)
    config_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # vpn:// URL
    status: Mapped[VpnClientStatus] = mapped_column(
        Enum(VpnClientStatus), default=VpnClientStatus.active
    )
    # The protocol amnezia-api actually confirmed when THIS client was
    # created (copied from CreateClientResponse.client.protocol — see
    # BillingService._provision_subscription) — never a default or a
    # server-wide setting read at call time. Every subsequent
    # enable/disable/delete call for this client must reuse this exact
    # value (see AmneziaClient.disable_client/enable_client/delete_client),
    # since a client keeps whatever protocol it was created with even if
    # the server's default protocol changes later.
    protocol: Mapped[str] = mapped_column(String(32))
    # Opaque random token used in the public /connect/{token} redirect link
    # (see api/routers/connect.py). Never expose amnezia_client_id or api keys
    # in a public URL — this token is the only thing that travels there.
    public_token: Mapped[Optional[str]] = mapped_column(
        String(64), unique=True, nullable=True, index=True
    )

    subscription: Mapped["Subscription"] = relationship(back_populates="vpn_client")
    server: Mapped["VpnServer"] = relationship(back_populates="vpn_clients")

    __table_args__ = (
        UniqueConstraint("server_id", "amnezia_client_id", name="uq_vpnclient_server_client"),
    )


class ProcessedEvent(Base):
    """Idempotency table – store processed payment event IDs to prevent double-processing."""
    __tablename__ = "processed_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[str] = mapped_column(String(512), unique=True, nullable=False, index=True)
    processed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )
    action: Mapped[AuditAction] = mapped_column(Enum(AuditAction), nullable=False)
    entity_type: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    entity_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON string
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
