"""
Business settings read from the environment (.env) — the single source of
truth for values that used to be hardcoded literals in several places.
"""
import os
from typing import Optional


def default_phone_daily_limit() -> Optional[float]:
    """
    Default trailing-24h receiving limit (in TMT) applied to an agent phone
    when the admin doesn't specify one explicitly (/add_agent_phone without
    a limit argument, or POST /agents/{id}/phones without daily_limit_manat).

    Read from AGENT_PHONE_DAILY_LIMIT_MANAT. Unset -> 350, so existing
    deployments keep behaving exactly as before. A value of 0 (or negative)
    means "no limit", matching what the /add_agent_phone command already
    accepts. Evaluated on every call, not at import, so a restart of the
    service is the only thing needed to pick up a changed .env value.
    """
    raw = os.getenv("AGENT_PHONE_DAILY_LIMIT_MANAT", "350").strip()
    try:
        value = float(raw)
    except ValueError:
        value = 350.0
    return None if value <= 0 else value
