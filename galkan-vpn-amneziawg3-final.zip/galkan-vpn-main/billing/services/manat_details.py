"""
Single source of truth for "who is involved in this manat request".

Used by BOTH the admin API (GET /admin/manat/{id}, the review queue) and the
background worker's timeout notifications, so every admin-facing screen and
notification shows the same client / agent / payment data, always read from
the database relationships of the request itself — never guessed from a
display name.

The agent is resolved through the request's own foreign keys:
  - reported_by_agent_id (Agent.id of the agent who tapped "Деньги получены")
    when the payment has been reported — that is "the agent through whom the
    payment went";
  - otherwise assigned_agent_id (the agent currently holding the request).
Callers that need a specific agent regardless (an agent who just declined,
and was therefore already detached from the row) pass `agent` explicitly.
"""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from billing.repositories.other_repos import AgentRepository, PlanRepository
from billing.repositories.user_repo import UserRepository
from models.models import Agent, ManatPaymentRequest, User


def _iso(value) -> Optional[str]:
    return value.isoformat() if value else None


def client_info(user: Optional[User]) -> Optional[dict[str, Any]]:
    if user is None:
        return None
    return {
        "telegram_id": user.telegram_id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
    }


async def agent_info(session: AsyncSession, agent: Optional[Agent]) -> Optional[dict[str, Any]]:
    """Agent identity. `username` comes from the agent's own row in `users`
    (every agent has talked to the bot, so the language middleware already
    created it); it is None when unknown — callers must treat it as
    optional. display_name is the name the admin gave the agent."""
    if agent is None:
        return None
    user = await UserRepository(session).get_by_telegram_id(agent.telegram_id)
    return {
        "id": agent.id,
        "telegram_id": agent.telegram_id,
        "display_name": agent.display_name,
        "username": user.username if user else None,
        "first_name": user.first_name if user else None,
        "last_name": user.last_name if user else None,
    }


async def build_manat_request_details(
    session: AsyncSession,
    request: ManatPaymentRequest,
    *,
    agent: Optional[Agent] = None,
) -> dict[str, Any]:
    agent_repo = AgentRepository(session)
    if agent is None:
        agent_pk = request.reported_by_agent_id or request.assigned_agent_id
        agent = await agent_repo.get_by_id(agent_pk) if agent_pk else None

    payer = await UserRepository(session).get_by_id(request.user_id)
    plan = await PlanRepository(session).get_by_id(request.plan_id)

    return {
        "request_id": request.id,
        "status": request.status.value,
        "mode": request.mode,
        "amount_manat": float(request.amount_manat),
        "agent_phone_shown": request.agent_phone_shown,
        "plan_id": request.plan_id,
        "plan_name": plan.name if plan else None,
        "plan_duration_days": plan.duration_days if plan else None,
        "created_at": _iso(request.created_at),
        "reported_at": _iso(request.reported_at),
        "payer_paid_at": _iso(request.payer_paid_at),
        "resolved_at": _iso(request.resolved_at),
        "resolved_by_admin_id": request.resolved_by_admin_id,
        "rejection_reason": request.rejection_reason,
        "client": client_info(payer),
        "agent": await agent_info(session, agent),
    }
