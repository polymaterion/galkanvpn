"""
Bot configuration loaded from ENV.
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings


class BotSettings(BaseSettings):
    TELEGRAM_TOKEN: str
    BILLING_BASE_URL: str = "http://billing:8000"
    BILLING_SECRET_KEY: str = ""

    ADMIN_IDS: str = ""  # comma-separated

    CRYPTOPAY_TOKEN: str = ""
    CRYPTOPAY_NETWORK: str = "mainnet"

    # Display-only — the actual trial length lives in the trial Plan row
    # (billing/seeds/seed.py reads TRIAL_DURATION_DAYS at seed time to set
    # Plan.duration_days). Keep this in sync with that same env var so the
    # "N-day trial" message the bot shows matches what's actually granted.
    TRIAL_DURATION_DAYS: int = 3

    SUPPORT_LINK: str = "https://t.me/support"
    AMNEZIA_DOWNLOAD_LINK: str = "https://amnezia.org/downloads"
    AMNEZIA_INSTRUCTION_LINK: str = "https://docs.amnezia.org/documentation/instructions/connect-via-text-key"

    # Manat (manual bank transfer) payments now route through an agent
    # queue stored in the database (Agent/AgentPhone models) rather than a
    # static env-configured list — see /add_agent and /add_agent_phone in
    # bot/handlers/admin_handlers.py. No MANAT_* env vars remain here.

    @property
    def admin_ids_list(self) -> list[int]:
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = BotSettings()
